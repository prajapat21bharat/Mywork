import { Component, ViewChild } from '@angular/core';
import { Nav, Platform } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { HomePage } from '../pages/home/home';
import { ListPage } from '../pages/list/list';

import { LoginPage } from '../pages/login/login';
import { SignupPage } from '../pages/signup/signup';
import { WelcomePage } from '../pages/welcome/welcome';
import { GallaryPage } from '../pages/gallary/gallary';
import { GetstartPage } from '../pages/getstart/getstart';
import { CameraPage } from '../pages/camera/camera';

import { AuthServiceProvider } from '../providers/auth-service/auth-service';

@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  @ViewChild(Nav) nav: Nav;

  rootPage: any = WelcomePage;

  pages: Array<{title: string, component: any,color:any}>;

	//~ userDetails = {"name":"","email":""};
	//~ responseData: any;

  constructor(public platform: Platform, public statusBar: StatusBar, public splashScreen: SplashScreen, private authService: AuthServiceProvider) {
    this.initializeApp();

    // used for an example of ngFor and navigation
    this.pages = [
      { title: 'Home', component: HomePage, color:'light'},
      { title: 'List', component: ListPage, color:'light'},
      { title: 'Camera', component: CameraPage, color:'light'},
      { title: 'Gallary', component: GallaryPage, color:'light'},
      {title: 'Logout', component: null, color:'light'}
    ];

    //~ var data = JSON.parse(localStorage.getItem('userData'));
    //~ this.userDetails.name = data.userData.name;
    //~ this.userDetails.email = data.userData.email;
  }

  initializeApp() {
    this.platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
  }

  //~ openPage(page) {
    //~ // Reset the content nav to have just this page
    //~ // we wouldn't want the back button to show in this scenario
    //~ this.nav.setRoot(page.component);
  //~ }
  //~ 
	openPage(page) {
		if(page.component) {
			this.nav.setRoot(page.component);
			page.color='dark';
			for (let p of this.pages) {
			if(p.title==page.title)
				{
				  p.color='dark';
				}
				else
				{
				  p.color='light';
				}
			}
		} else {
			// Since the component is null, this is the logout option
			// ...

			// logout logic
			// ...

			// redirect to home

			//~ localStorage.setItem('userDetails', "");
			this.nav.setRoot(WelcomePage);
		}
	}
}
