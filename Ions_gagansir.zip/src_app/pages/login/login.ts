import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';import { AlertController } from 'ionic-angular';

import { LoadingController } from 'ionic-angular';
import { GetstartPage } from '../../pages/getstart/getstart';

import { AuthServiceProvider } from '../../providers/auth-service/auth-service';

/**
 * Generated class for the LoginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {

  
  responseData : any;
  userData = {"username": "","password": ""};
  constructor(public navCtrl: NavController, private authService: AuthServiceProvider, public alertCtrl: AlertController, public loadingCtrl: LoadingController) {

  }

  login(){
    //console.log("here",this.userData);
		 this.authService.postData(this.userData,"login").then((result) =>{
		  this.responseData = result;
		  console.log(this.responseData);
		  if(this.responseData.userData){
			let loader = this.loadingCtrl.create({
			  content: "Please wait...",
			  duration: 2000
			});
			loader.present();
			localStorage.setItem('userData', JSON.stringify(this.responseData) )
			this.navCtrl.push(GetstartPage);
		 }
		 else{ 
			let alert = this.alertCtrl.create({
				title: 'Login Failed!',
				subTitle: 'username and password Incorrect !',
				buttons: ['OK']
			});
			alert.present();
		}
		}, (err) => {
		  // Error log
		});
  }
  
}
