import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, , AlertController } from 'ionic-angular';

import { Camera, CameraOptions } from '@ionic-native/camera';

import { AuthServiceProvider } from '../../providers/auth-service/auth-service';

/**
 * Generated class for the CameraPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-camera',
  templateUrl: 'camera.html',
})
export class CameraPage {
	
	public photos: any;
	public base64Image: string;

	public fileImage: string;
	public responseData: any;
	userData = {user_id: "", token: "",imageB64: "" };

  constructor(public navCtrl: NavController, public navParams: NavParams, private camera: Camera, public alertCtrl: AlertController, private authService : AuthServiceProvider) {
  }

  ngOnInit(){
	this.photos =[];
	}

	takePhoto(){
		//~ alert("hello");
		const options: CameraOptions = {
		  quality: 50,
		  destinationType: this.camera.DestinationType.DATA_URL,
		  encodingType: this.camera.EncodingType.JPEG,
		  mediaType: this.camera.MediaType.PICTURE
		}

		this.camera.getPicture(options).then((imageData) => {
		 // imageData is either a base64 encoded string or a file URI
		 // If it's base64:
		 this.base64Image = 'data:image/jpeg;base64,' + imageData;
		 this.photos.push(this.base64Image);
		 this.sendImageData(this.base64Image);
		 this.photos.revesrse();
		 
		}, (err) => {
		 // Handle error
			console.log(err);
		});
	}
	
	sendImageData(base64Image){
	   
		   this.userData.user_id="1";
		   this.userData.token="xyz";
		   this.userData.imageB64=base64Image;
		   
		   this.authService.postData(this.userData,'userImage').then((result) => {
				   console.log(result);
			 }, (err) => {
		  // Error log
		});
	}

	deletePhoto(index){
		//~ this.photos.splice(index,1);
		let confirm = this.alertCtrl.create({
		  title: 'Sure you want to delete this picture?',
		  message: 'Do you agree to use this lightsaber to do good across the intergalactic galaxy?',
		  buttons: [
			{
			  text: 'No',
			  handler: () => {
				//~ console.log('Disagree clicked');
			  }
			},
			{
			  text: 'Yes',
			  handler: () => {
				 this.photos.splice(index,1);
				//~ console.log('Agree clicked');
			  }
			}
		  ]
		});
		confirm.present();
	}

}
