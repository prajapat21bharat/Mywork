import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

import { Diagnostic } from 'ionic-native';

/**
 * Generated class for the GallaryPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-gallary',
  templateUrl: 'gallary.html',
})
export class GallaryPage {
	
  gallary:any[];
  constructor(public navCtrl: NavController, public navParams: NavParams) {
		this.gallary=[
			{title:'Neture Wallpaper 1',body:'neture wallpapers',image:'assets/imgs/513167.jpg'},
			{title:'Neture Wallpaper 2',body:'neture wallpapers',image:'assets/imgs/597529.jpg'},
			{title:'Neture Wallpaper 3',body:'neture wallpapers',image:'assets/imgs/12278033.jpg'},
			{title:'Neture Wallpaper 4',body:'neture wallpapers',image:'assets/imgs/83416126.jpg'},
			{title:'Neture Wallpaper 5',body:'neture wallpapers',image:'assets/imgs/neture-wallpapers.jpg'},
			{title:'Neture Wallpaper 6',body:'neture wallpapers',image:'assets/imgs/crop_php.jpeg'},
			{title:'Neture Wallpaper 7',body:'neture wallpapers',image:'assets/imgs/Neture-Wallpapers.jpg'},
			{title:'Neture Wallpaper 8',body:'neture wallpapers',image:'assets/imgs/440845.jpg'},
			{title:'Neture Wallpaper 9',body:'neture wallpapers',image:'assets/imgs/neture_wallpapers_003.jpg'},
		];
  }
  
   ionViewDidLoad() {
    console.log('ionViewDidLoad GallaryPage');
  }
 
}
