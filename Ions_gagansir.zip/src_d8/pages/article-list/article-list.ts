import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

import { Http, Headers, RequestOptions} from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';

/**
 * Generated class for the ArticleListPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-article-list',
  templateUrl: 'article-list.html',
})
export class ArticleListPage {

  	articles: any;
	 
	constructor(public navCtrl: NavController, public navParams: NavParams, public http: Http) {
		this.http.get('http://115.166.142.238/d8appdev/article-node-rest').map(res => res.json()).subscribe(data => {
			this.articles = data;
				  },
		err => {
			console.log(err);
		}
	 );
	 //~ this.articles = this.http.get(this.'http://115.166.142.238/d8appdev/article-node-rest')
			//~ .map(this.extractData)
			//~ .do(this.logResponse)
			//~ .catch(this.catchError);
	}
	
	//~ private catchError(error: Response | any){
		//~ console.log(error);
		//~ return Observable.throw(error.json().error || "Server Error.");
	//~ }
	  //~ 
	//~ private logResponse(res:Response){
		//~ //console.log(res);
	//~ }
	  //~ 
	//~ private extractData(res:Response){
		//~ return res.json();
	//~ }

}
