import { Component } from '@angular/core';
import { NavController, ModalController } from 'ionic-angular';

import { ModalPage } from '../modal/modal';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
	
	originalData:any;
	modifiedData:any;
	
  constructor(public navCtrl: NavController, public modalCtrl : ModalController) {
	this.originalData=[
		{name:"Ajay",subscribers:"123", avtar:"https://t4.ftcdn.net/jpg/01/10/98/95/500_F_110989546_PHsON8fY4F5w3HYhwHq3TxQRasDuRyJg.jpg",channel_url:"https://www.youtube.com/watch?v=A-4CLa05tp0"},
		{name:"Gagan",subscribers:"120", avtar:"https://t4.ftcdn.net/jpg/01/10/98/95/500_F_110989546_PHsON8fY4F5w3HYhwHq3TxQRasDuRyJg.jpg",channel_url:"https://www.youtube.com/watch?v=A-4CLa05tp0"},
		{name:"milind",subscribers:"145", avtar:"https://t4.ftcdn.net/jpg/01/10/98/95/500_F_110989546_PHsON8fY4F5w3HYhwHq3TxQRasDuRyJg.jpg",channel_url:"https://www.youtube.com/watch?v=A-4CLa05tp0"},
		{name:"Om",subscribers:"201", avtar:"https://t4.ftcdn.net/jpg/01/10/98/95/500_F_110989546_PHsON8fY4F5w3HYhwHq3TxQRasDuRyJg.jpg",channel_url:"https://www.youtube.com/watch?v=A-4CLa05tp0"},
		{name:"Sonia",subscribers:"20", avtar:"https://t4.ftcdn.net/jpg/01/10/98/95/500_F_110989546_PHsON8fY4F5w3HYhwHq3TxQRasDuRyJg.jpg",channel_url:"https://www.youtube.com/watch?v=A-4CLa05tp0"},
		{name:"bharat",subscribers:"300", avtar:"https://t4.ftcdn.net/jpg/01/10/98/95/500_F_110989546_PHsON8fY4F5w3HYhwHq3TxQRasDuRyJg.jpg",channel_url:"https://www.youtube.com/watch?v=A-4CLa05tp0"},
	];
	this.modifiedData=JSON.parse(JSON.stringify(this.originalData));
  }
  
  resetData(){
	this.modifiedData=JSON.parse(JSON.stringify(this.originalData));
  }
  
  filterData(){
	this.modifiedData=this.originalData.filter((youtuber)=>{
		return youtuber.subscribers>200;
	});
  }
  
  mapData(){
	this.modifiedData=this.originalData.filter((youtuber)=>{
		youtuber.name=youtuber.name.toUpperCase();
		youtuber.subscribers=youtuber.subscribers*10;
		return youtuber;
	});
  }
  
  reduceData(){
	let sum=this.modifiedData.reduce((previous,current)=>{
		let prevResult=Number.isInteger(previous) ? previous : previous.subscribers;
		return prevResult + current.subscribers;
	})
	console.log(sum);
	
	let most=this.modifiedData.reduce((previous,current)=>{
		let prevResult=Number.isInteger(previous) ? previous : previous.subscribers;
		let max=Math.max(prevResult,current.subscribers)
		return max;
	})
	console.log(most);
  }
  
   openModal(){
	let  modalPage = this.modalCtrl.create('ModalPage'); 
	modalPage.present();
  }
  
  doLogin(){
	this.navCtrl.setRoot('MenuPage');
  }

}
