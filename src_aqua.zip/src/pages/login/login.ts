import { Component, ViewChild } from '@angular/core';
import { IonicPage, NavController, AlertController, NavParams } from 'ionic-angular';
import { AngularFireAuth } from 'angularfire2/auth';

/**
 * Generated class for the LoginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */
import { SignupPage } from '../signup/signup';
import { ListPage } from '../list/list';


@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {
	
	@ViewChild("email") email;
	@ViewChild("password") password;
	
  constructor(private fire: AngularFireAuth, public navCtrl: NavController, private alertCtrl: AlertController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad LoginPage');
  }
  
  alert(message: string){
	this.alertCtrl.create({
		title: 'Info!',
		subTitle: message,
		buttons: ['OK']
	}).present();
  }
  
  Login(){
  this.fire.auth.signInWithEmailAndPassword(this.email.value, this.password.value)
	.then(data=>{
		this.alert("Success! Your\'re logged in");
		this.navCtrl.setRoot(ListPage);
		console.log('After Fire Login',this.fire.auth.currentUser.displayName);
	})
	.catch(error=>{
		this.alert(error.message);
		console.log('Got an error',error);
	})
	console.log('Login Data', this.email.value, this.password.value);
  }
  
  Signup(){
	this.navCtrl.push(SignupPage);
  }

}
