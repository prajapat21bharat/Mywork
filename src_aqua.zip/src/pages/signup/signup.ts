import { Component, ViewChild } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { AngularFireAuth } from 'angularfire2/auth';

import { LoginPage } from '../login/login';

/**
 * Generated class for the SignupPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-signup',
  templateUrl: 'signup.html',
})
export class SignupPage {

	@ViewChild("fullname") fullname;
	@ViewChild("contactno") contactno;
	@ViewChild("email") email;
	@ViewChild("password") password;
	@ViewChild("re_password") re_password;

  constructor(private fire: AngularFireAuth, public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SignupPage');
  }
  
	Login(){
		this.navCtrl.push(LoginPage);
	}
  
  Signup(){
	this.fire.auth.createUserWithEmailAndPassword(this.email.value, this.password.value)
	.then(data=>{
		console.log('Signup Data',data);
	})
	.catch(error=>{
		console.log('Got an error',error);
	})
	
	console.log('SignupPage',this.fullname.value, this.contactno.value,this.email.value, this.password.value);
  }

}
