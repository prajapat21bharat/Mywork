import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Test2Page } from './test2';

@NgModule({
  declarations: [
    Test2Page,
  ],
  imports: [
    IonicPageModule.forChild(Test2Page),
  ],
})
export class Test2PageModule {}
