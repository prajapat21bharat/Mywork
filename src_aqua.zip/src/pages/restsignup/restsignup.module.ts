import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RestsignupPage } from './restsignup';

@NgModule({
  declarations: [
    RestsignupPage,
  ],
  imports: [
    IonicPageModule.forChild(RestsignupPage),
  ],
})
export class RestsignupPageModule {}
