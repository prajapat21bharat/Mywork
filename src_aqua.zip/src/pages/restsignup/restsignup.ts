import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { RestloginPage } from '../restlogin/restlogin';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';

import { HomePage } from '../home/home';
import { ResthomePage } from '../resthome/resthome';

/**
 * Generated class for the RestsignupPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-restsignup',
  templateUrl: 'restsignup.html',
})
export class RestsignupPage {
	
	responseData : any;
	userData={"fullname":"swati","contactno":"11s111c1s","email":"swastsci@gmail.com","password":"123456"};
    constructor(public navCtrl: NavController, public navParams: NavParams, public authServiceProvider: AuthServiceProvider) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad RestsignupPage');
  }
  
   Login(){
	this.navCtrl.push(RestloginPage);
  }
  
  Signup(){
	this.authServiceProvider.postData(this.userData,"signup.php").then((result)=>{
	this.responseData=result;
	localStorage.setItem("userData",JSON.stringify(this.responseData));
	console.log(this.responseData);
	this.navCtrl.push(ResthomePage);
	},(err)=>{
		 console.log(err);
	})
  }

}
