import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { RestsignupPage } from '../restsignup/restsignup';

/**
 * Generated class for the RestloginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-restlogin',
  templateUrl: 'restlogin.html',
})
export class RestloginPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad RestloginPage');
  }
  
  Login(){
	
  }
  
  Signup(){
	this.navCtrl.push(RestsignupPage);
  }

}
