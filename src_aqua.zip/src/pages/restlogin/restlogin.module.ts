import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RestloginPage } from './restlogin';

@NgModule({
  declarations: [
    RestloginPage,
  ],
  imports: [
    IonicPageModule.forChild(RestloginPage),
  ],
})
export class RestloginPageModule {}
