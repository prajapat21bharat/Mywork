import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, reorderArray } from 'ionic-angular';

/**
 * Generated class for the ReorderPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-reorder',
  templateUrl: 'reorder.html',
})
export class ReorderPage {
	animals:any;
  constructor(public navCtrl: NavController, public navParams: NavParams) {
	this.animals=["Rat","Dog","Cat","Pig","Cock","Hen","Sparrow","Elephant","Tiger"];
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ReorderPage');
  }
	
	reorderItem(indexs){
		this.animals=reorderArray(this.animals,indexs);
	}
}
