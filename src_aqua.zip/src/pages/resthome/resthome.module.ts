import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ResthomePage } from './resthome';

@NgModule({
  declarations: [
    ResthomePage,
  ],
  imports: [
    IonicPageModule.forChild(ResthomePage),
  ],
})
export class ResthomePageModule {}
