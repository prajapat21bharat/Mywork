import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { HttpModule } from '@angular/http';


import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { ListPage } from '../pages/list/list';
import { LoginPage } from '../pages/login/login';
import { SignupPage } from '../pages/signup/signup';
import { RestloginPage } from '../pages/restlogin/restlogin';
import { RestsignupPage } from '../pages/restsignup/restsignup';
import { ResthomePage } from '../pages/resthome/resthome';
import { ReorderPage } from '../pages/reorder/reorder';
import { CalendarPage } from '../pages/calendar/calendar';


import { NgCalendarModule } from 'ionic2-calendar';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { AngularFireModule } from 'angularfire2';
import { AngularFireAuthModule } from 'angularfire2/auth';
import { AuthServiceProvider } from '../providers/auth-service/auth-service';

const firebaseAuth = {
    apiKey: "AIzaSyAtiEYPieJPnVZTgQdkU5fduulgHMJRoE0",
    authDomain: "aqua-d3468.firebaseapp.com",
    databaseURL: "https://aqua-d3468.firebaseio.com",
    projectId: "aqua-d3468",
    storageBucket: "aqua-d3468.appspot.com",
    messagingSenderId: "663859268782"
  };



@NgModule({
  declarations: [
    MyApp,
    HomePage,
    ListPage,
    LoginPage,
    SignupPage,
    RestloginPage,
    RestsignupPage,
    ResthomePage,
    ReorderPage,
    CalendarPage
  ],
  imports: [
	NgCalendarModule,
    BrowserModule,
    IonicModule.forRoot(MyApp),
    HttpModule,
    AngularFireModule.initializeApp(firebaseAuth),
    AngularFireModule,
    AngularFireAuthModule
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    ListPage,
    LoginPage,
    SignupPage,
    RestloginPage,
    RestsignupPage,
    ResthomePage,
    ReorderPage,
    CalendarPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    AuthServiceProvider
  ]
})
export class AppModule {}
