import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { Accotest2Page } from '../pages/accotest2/accotest2';
import { AccotestPage } from '../pages/accotest/accotest';
import { CoutriesPage } from '../pages/coutries/coutries';
import { MessageServiceProvider } from '../providers/message-service/message-service';

import { HttpModule } from '@angular/http';

import { IonRangeSliderModule } from "ng2-ion-range-slider";

import { AccordianComponent } from '../components/accordian/accordian';
import { WorkComponent } from '../components/work/work';
import { RestProvider } from '../providers/rest/rest';

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    AccordianComponent,
    AccotestPage,
    Accotest2Page,
    CoutriesPage,
    WorkComponent
  ],
  imports: [
    BrowserModule,
    IonRangeSliderModule,
    IonicModule.forRoot(MyApp),
    HttpModule
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    AccotestPage,
    Accotest2Page,
    CoutriesPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    MessageServiceProvider,
    RestProvider
  ]
})
export class AppModule {}
