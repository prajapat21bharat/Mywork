import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CoutriesPage } from './coutries';

@NgModule({
  declarations: [
    CoutriesPage,
  ],
  imports: [
    IonicPageModule.forChild(CoutriesPage),
  ],
})
export class CoutriesPageModule {}
