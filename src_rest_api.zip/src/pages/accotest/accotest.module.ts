import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AccotestPage } from './accotest';

@NgModule({
  declarations: [
    AccotestPage,
  ],
  imports: [
    IonicPageModule.forChild(AccotestPage),
  ],
})
export class AccotestPageModule {}
