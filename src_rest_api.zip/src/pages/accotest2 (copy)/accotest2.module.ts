import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Accotest2Page } from './accotest2';

@NgModule({
  declarations: [
    Accotest2Page,
  ],
  imports: [
    IonicPageModule.forChild(Accotest2Page),
  ],
})
export class Accotest2PageModule {}
