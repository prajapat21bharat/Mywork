import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

import { MessageServiceProvider } from '../../providers/message-service/message-service';


@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

	messages=[];
	postList = [];
	selectedAll: any;
	
	date= new Date();
	rangeSettings: number = 20;
	
	structure: any = { lower: 7, upper: 15 };
	
	items=[
		{"title":"Sport & Mouvement","parent_id":0, "id": 1,checked: false},
		{"title":"Divertissement","parent_id":0, "id": 2,checked: false},
		{"title":"Bien-être & Personnalité","parent_id":0, "id": 3,checked: false},
		{"title":"Créativité & Arts","parent_id":0, "id": 4,checked: false},
		{"title":"Goût & Papilles","parent_id":0, "id": 5,checked: false},
		{"title":"Ipsum","parent_id":1, "id": 6,checked: false},
		{"title":"Lorem Ipsum","parent_id":1, "id": 7,checked: false},
		{"title":"sitis","parent_id":1, "id": 8,checked: false},
		{"title":"Dolor","parent_id":1, "id": 9,checked: false},
		{"title":"Dolor sitis","parent_id":1, "id": 10,checked: false},
		{"title":"Ipsum","parent_id":2, "id": 11,checked: false},
		{"title":"Lorem Ipsum","parent_id":2, "id": 12,checked: false},
		{"title":"sitis","parent_id":2, "id": 12,checked: false},
		{"title":"Dolor","parent_id":2, "id": 13,checked: false},
		{"title":"Dolor sitis","parent_id":2, "id": 13,checked: false},
	];

  constructor(public navCtrl: NavController, private messageServiceProvider: MessageServiceProvider) {
	this.getMessages();
  }
  
	getMessages(){
		this.messageServiceProvider.getMessages().subscribe(data=>console.log(data));
		this.messageServiceProvider.getMessages().subscribe((data)=>{
				this.postList = data;
			});
		//this.messageServiceProvider.getMessages().subscribe(data=>this.messages=data);
	}
	
	selectAll(element) {
    for (var i = 0; i < this.items.length; i++) {
		if(this.items[i].parent_id==element){
			this.items[i].checked = this.selectedAll;
		}
    }
  }
  checkIfAllSelected() {
    this.selectedAll = this.items.every(function(item:any) {
        return item.checked == true;
      })
  }

}
