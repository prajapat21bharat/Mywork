import { Component } from '@angular/core';
import { Http } from '@angular/http';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

import 'rxjs/add/operator/map';

/**
 * Generated class for the Accotest2Page page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-accotest2',
  templateUrl: 'accotest2.html',
})
export class Accotest2Page {

	information:any[];

  constructor(public navCtrl: NavController, public navParams: NavParams, private http: Http) {
	let localData = this.http.get('assets/information.json').map(res=>res.json().items);
	localData.subscribe(data =>{
		this.information = data;
	});
  }
  
  toggleSection(i){
	this.information[i].open= !this.information[i].open;
  }
  
  toggleItem(i,j){
	this.information[i].children[j].open= !this.information[i].children[j].open;
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad Accotest2Page');
  }

}
