import { Component } from '@angular/core';

/**
 * Generated class for the WorkComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'work',
  templateUrl: 'work.html'
})
export class WorkComponent {

  text: string;
  
  pinfo:any;

  constructor() {
    console.log('Hello WorkComponent Component');
    this.text = 'Hello World';
    this.pinfo=[
		{org:"ABC",exp:10},
		{org:"XYZ",exp:5},
		{org:"MNO",exp:15}
    ];
  }

}
