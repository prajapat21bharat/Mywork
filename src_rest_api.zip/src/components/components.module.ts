import { NgModule } from '@angular/core';
import { AccordianComponent } from './accordian/accordian';
import { WorkComponent } from './work/work';
@NgModule({
	declarations: [AccordianComponent,
    WorkComponent],
	imports: [],
	exports: [AccordianComponent,
    WorkComponent]
})
export class ComponentsModule {}
