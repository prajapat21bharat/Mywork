import { Pipe, PipeTransform } from '@angular/core';

/**
 * Generated class for the MyDataPipe pipe.
 *
 * See https://angular.io/api/core/Pipe for more info on Angular Pipes.
 */
@Pipe({
  name: 'FormatData',
})
export class MyDataPipe implements PipeTransform {
  /**
   * Takes a value and makes it lowercase.
   */
 transform(value, args:string[]) : any {
	let menu = [];
	
	Object.keys(value).forEach(
		key=> {
			if(value[key].parent_id == args){
				menu.push(value[key]);
			 }
		/*
			console.log("key: ",key)  ;     
			console.log("value: ",value)  ;     
			console.log("opt: ",value[key].parent_id)  ;     
			console.log("args: ",args)  ;   
			*/  
		}
	);
	return menu;
	}
	
}
