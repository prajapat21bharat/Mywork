import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RangecalendarPage } from './rangecalendar';

@NgModule({
  declarations: [
    RangecalendarPage,
  ],
  imports: [
    IonicPageModule.forChild(RangecalendarPage),
  ],
})
export class RangecalendarPageModule {}
