import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FilterdemoPage } from './filterdemo';

@NgModule({
  declarations: [
    FilterdemoPage,
  ],
  imports: [
    IonicPageModule.forChild(FilterdemoPage),
  ],
})
export class FilterdemoPageModule {}
