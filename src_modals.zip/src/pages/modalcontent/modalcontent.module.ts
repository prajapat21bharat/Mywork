import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ModalcontentPage } from './modalcontent';
import { CalendarModule } from "ion2-calendar";
import { MyDataPipe } from './../../pipes/my-data/my-data';


@NgModule({
  declarations: [
    ModalcontentPage,
  ],
  imports: [
    IonicPageModule.forChild(ModalcontentPage),
    CalendarModule,
  ],
})
export class ModalcontentPageModule {}
