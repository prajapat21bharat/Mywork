import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AccordianPage } from './accordian';

@NgModule({
  declarations: [
    AccordianPage,
  ],
  imports: [
    IonicPageModule.forChild(AccordianPage),
  ],
})
export class AccordianPageModule {}
