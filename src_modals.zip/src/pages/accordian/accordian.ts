import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the AccordianPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-accordian',
  templateUrl: 'accordian.html',
})
export class AccordianPage {

	
	shownGroup = null;
	
	diseases = [
		{ title: "ACTIVITY", description: "ACTIVITY Content" },
		{ title: "PERIOD", description: "PERIOD Content" },
		{ title: "BOOKING TYPE", description: "BOOKING TYPE Content" }
		
	];
	
	items=[
		{"title":"Sport & Mouvement"},
		{"title":"Divertissement"},
		{"title":"Bien-être & Personnalité"},
		{"title":"Créativité & Arts"},
		{"title":"Goût & Papilles"},
	];
	
	
	
  constructor(public navCtrl: NavController, public navParams: NavParams) {
	this.shownGroup=0;
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AccordianPage');
  }
  
	toggleGroup(group) {
		/*if (this.isGroupShown(group)) {
			this.shownGroup = null;
		} else {
			this.shownGroup = group;
		}*/
		this.shownGroup = group;
	};
	isGroupShown(group) {
		console.log(group);
		return this.shownGroup === group;
	};
	
}

