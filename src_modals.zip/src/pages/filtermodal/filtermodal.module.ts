import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FiltermodalPage } from './filtermodal';

@NgModule({
  declarations: [
    FiltermodalPage,
  ],
  imports: [
    IonicPageModule.forChild(FiltermodalPage),
  ],
})
export class FiltermodalPageModule {}
