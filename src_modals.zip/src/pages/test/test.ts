import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the TestPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-test',
  templateUrl: 'test.html',
})
export class TestPage {
	overlayHidden: boolean = true;
	buttonClicked: boolean = false;
	buttonClickednew: boolean = false;
	attendancebtn: boolean = false;
	checked: boolean = false;
	checkednew: boolean = false;
	checkednewvalue: boolean = false;
	constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad TestPage');
  }
	hideOverlay() {
		this.overlayHidden = true;
	}
	showOverlay() {
		this.overlayHidden = false;
	}
	onButtonClick() {
		this.buttonClicked = !this.buttonClicked;
    }
    onButtonClicknew(){
		this.buttonClickednew = !this.buttonClickednew;
    }
    onButtonClickattend(){
		this.attendancebtn = !this.attendancebtn; 
    }
    
    //code for show button	
	
	addValue(e): void {
    var isChecked = e.currentTarget.checked;
    //console.log(e.currentTarget);
    console.log(this.checked);
    if(this.checked == true || this.checkednew == true || this.checkednewvalue == true){
    this.attendancebtn = true;
    }else{
    this.attendancebtn = false;
    }
      }
}
