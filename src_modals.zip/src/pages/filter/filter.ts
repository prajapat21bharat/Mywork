import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the FilterPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-filter',
  templateUrl: 'filter.html',
})
export class FilterPage {
	players=[];
  constructor(public navCtrl: NavController, public navParams: NavParams) {
	this.players = [
					  {
						  "firstName": "Morgan",
						  "lastName": "Benton",
						  "username": "mbenton",
						  "age": "10",
						  "teamId": 1
					  },
					  {
						  "firstName": "Kelsey",
						  "lastName": "Banks",
						  "username": "kbanks",
						  "age": "5",
						  "teamId": 2
					  },
					  {
						  "firstName": "Jessica",
						  "lastName": "Martinez",
						  "username": "jmartinez",
						  "age": "1",
						  "teamId": 3
					  },
					  {
						  "firstName": "Maggie",
						  "lastName": "Walker",
						  "username": "mwalker",
						  "age": "10",
						  "teamId": 4
					  }
				];
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad FilterPage');
  }
  
  togglePage(){
	
  }


}
