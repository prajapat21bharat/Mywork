import { Component } from '@angular/core';

import { ModalController, NavController } from 'ionic-angular';

import { CalendarComponentOptions } from 'ion2-calendar';


import { ModalPage } from '../modal/modal';
import { MenuPage } from '../menu/menu';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
	
	items: any;
	itemExpanded : boolean;
	itemExpanHeight : number;

dateRange: { from: string; to: string; };
  type: 'string'; // 'string' | 'js-date' | 'moment' | 'time' | 'object'
  optionsRange: CalendarComponentOptions = {
    pickMode: 'range'
  };
  
  constructor(public navCtrl: NavController, public modalCtrl : ModalController) {
	this.items  = [
		{expanded:false},
		{expanded:false},
		{expanded:false},
		{expanded:false},
		{expanded:true},
		{expanded:false},
		{expanded:false},
		{expanded:false},
	];
	this.itemExpanded = true;;
	this.itemExpanHeight = 300;
  }
  
  expandItem(item){
	this.items.expanded=false;
	item.expanded=!item.expanded;
  }
  
  openModal(){
	let  modalPage = this.modalCtrl.create('ModalPage'); 
	modalPage.present();
  }
  
  doLogin(){
	this.navCtrl.setRoot('MenuPage');
  }

}
