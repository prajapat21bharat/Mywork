import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController } from 'ionic-angular';


/**
 * Generated class for the ModalPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-modal',
  templateUrl: 'modal.html',
})
export class ModalPage {

	shownGroup = null; 
	category: Array<any>;

	items=[
		{"title":"Sport & Mouvement"},
		{"title":"Divertissement"},
		{"title":"Bien-être & Personnalité"},
		{"title":"Créativité & Arts"},
		{"title":"Goût & Papilles"},
	];
	
	
	
	constructor(public navCtrl: NavController, public navParams: NavParams, public viewCtrl : ViewController) {
		this.shownGroup=0;
		this.category = [
				{"name": "A", "id": 1, "parent_id": 0},
				{"name": "B", "id": 2, "parent_id": 0},
				{"name": "A1", "id": 3, "parent_id": 1},
				{"name": "A2", "id": 4, "parent_id": 1},
				{"name": "B1", "id": 5, "parent_id": 2},
				{"name": "B2", "id": 6, "parent_id": 2},
			];
	}

  ionViewDidLoad() {
    console.log('ionViewDidLoad ModalPage');
    //console.log(this.shownGroup+"Hooo");
  }
  
	public closeModal(){
		this.viewCtrl.dismiss();
	}
	
	
	toggleGroup(group) {
		/*if (this.isGroupShown(group)) {
			this.shownGroup = null;
		} else {
			this.shownGroup = group;
		}*/
		this.shownGroup = group;
		console.log(this.shownGroup+"Hoii");
	};
	
	isGroupShown(group) {
		console.log(group);
		return this.shownGroup === group;
	};

}
