import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';

import { CalendarModule } from "ion2-calendar";
import { MyDataPipe } from '../pipes/my-data/my-data';
 
import { ExpandableComponent } from '../components/expandable/expandable';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { TestPage } from '../pages/test/test';
import { FilterPage } from '../pages/filter/filter';
import { LoopconditionPage } from '../pages/loopcondition/loopcondition';
import { SliderPage } from '../pages/slider/slider';
import { TabsPage } from '../pages/tabs/tabs';
import { AccordianPage } from '../pages/accordian/accordian';
import { RangecalendarPage } from '../pages/rangecalendar/rangecalendar';
import { FilterdemoPage } from '../pages/filterdemo/filterdemo';
import { FiltermodalPage } from '../pages/filtermodal/filtermodal';


@NgModule({
  declarations: [
    MyApp,
    HomePage,
    TestPage,
    FilterPage,
    LoopconditionPage,
    SliderPage,
    TabsPage,
    ExpandableComponent,
    AccordianPage,
    RangecalendarPage,
    FilterdemoPage ,
    MyDataPipe,
    FiltermodalPage 
  ],
  imports: [
    BrowserModule,
    CalendarModule,
    IonicModule.forRoot(MyApp)
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    TestPage,
    FilterPage,
    LoopconditionPage,
    SliderPage,
    TabsPage,
    AccordianPage,
    RangecalendarPage,
    FilterdemoPage,
    FiltermodalPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {}

