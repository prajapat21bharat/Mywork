	<!---------------------------------- Subscribe Block Start ------------------------------------>
	<div class="pull-left breadcrumb_admin clear_both padding_fix padding_top-fix">
		<div class="padding-S">
			<div class=" col-md-3 space-top"> 
				<p class="headingg">Stay in touch with Inhairent!</p> 
			</div>
			<div class=" col-md-3">
				<input type="text" placeholder="email address" class="form-control">
			</div>
			<div class="col-md-3 space-top">
				<label class="checkbox-inline">
					<input type="checkbox" value="option1" id="inlinecheckbox1">I am a stylist</label>
				<label class="checkbox-inline">
					<input type="checkbox" value="option2" id="inlinecheckbox2">I am a client</label>
			</div>
		<div class="col-md-3"><a class="btn-black" href="#">Sign me up!</a></div>
		</div>
	</div>

	<!---------------------------------- Subscribe Block Ends ------------------------------------>
