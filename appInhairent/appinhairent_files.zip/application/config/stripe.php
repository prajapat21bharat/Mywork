<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// Configuration options
$config['stripe_key_test_public']         = 'pk_test_u4gDKpRI7LO8qgx26y3IzLgl';
$config['stripe_key_test_secret']         = 'sk_test_yGkPDmjto0vywa5xYJSjMjkc';
$config['stripe_key_live_public']         = 'pk_live_UviGHUj2xEF21t2SfqCe6uqZ';
$config['stripe_key_live_secret']         = 'sk_live_CIjTysU0O8awiOytZHoj7vT3';
$config['stripe_test_mode']               = TRUE;
$config['stripe_verify_ssl']              = FALSE;
