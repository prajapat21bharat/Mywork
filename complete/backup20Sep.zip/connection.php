<?php
	$con=mysql_connect('208.91.199.11', 'can_grub', 'QAZ123');
	mysql_select_db('canoppwh_grubtracker',$con);
?>