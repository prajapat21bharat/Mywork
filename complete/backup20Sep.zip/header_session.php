 <?php
			   		$mail=$_SESSION['login'];
					$sql="select firstname,image,id from userregistration where emailid='$mail'";
					$result=mysql_query($sql,$con);
					while($data=mysql_fetch_array($result))
					{
						$firstname=$data[0];
						$image=$data[1];
						$id=$data[2];
					}
			   ?>
                  <ul id="user-options">
                     <li class="boldtext">Welcome: <?php echo'<h6 style=color:#ff8f0d>'.$firstname.'</h6>'.'<img class=sessinoimage src='.$image.' height="50px" width="50px" />'?></li>
                     <li class="boldtext">|</li>
                     <li><a id="logout-link" href="finallogin.php" alt="Logout"></a></li>
                  </ul>