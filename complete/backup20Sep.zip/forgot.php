﻿<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<link rel="shortcut icon" type="image/ico" href="/images/favicon.ico" />	
		<title>Grub Tracker</title>		
		<link href="styles.css" type="text/css" media="screen" rel="stylesheet" />		<style type="text/css">
		img, div { behavior: url("iepngfix.htc") }
		</style>	
	</head>
	<body id="login">
		<div id="wrappertop"></div>
			<div id="wrapper">
					<div id="content">
						<div id="header">
							<h2>Grub Tracker</h2>
						</div>
						<div id="darkbanner" class="banner320">
							<h2>Forgot Password</h2>
						</div>
						<div id="darkbannerwrap">						</div>
					<form name="form1" method="post" action="forgot.php">
						<fieldset class="form">
                        								<p>Can't remember your password? No problem. Enter your e-mail address below and we will e-mail you a password Reset link. You can create your new password.</p><br>
							<p>
								<label for="user_name">E-Mail:</label>
								<input name="user_name" id="user_name" type="text" />
							</p>
							<button type="submit" class="positive" name="Submit">
								<img src="images/key.png" alt="Announcement"/>Request New Password</button>
							</fieldset>
					</div>
				</div> 

<div id="wrapperbottom_branding"><div id="wrapperbottom_branding_text"><!--<a href="#" style='text-decoration:none'></a>--></div></div>

</body>
</html>