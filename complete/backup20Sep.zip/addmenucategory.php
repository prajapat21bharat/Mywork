<?php include 'checksession.php'?>
<!DOCTYPE html>
<html>
   <head>
   	<?php
		include("connection.php");
	?>
      <meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
      <link rel="shortcut icon" type="image/ico" href="../images/favicon.ico" />
      <title>Grub Tracker</title>
      <link href="styles.css" type="text/css" media="screen" rel="stylesheet" />
      <style type="text/css">
         img, div { behavior: url(../iepngfix.htc) }
      </style>
	<script>
		function valid()
		{
			var category=document.getElementsByName("category")[0].value;
			//var category_image=document.getElementsByName("category_image")[0].value;
			if(category=="")
			{
				document.getElementById("Scategory").innerHTML=" Please Enter Category name";
				return false;
			}
			/*if(category_image!=="")
			{
					//var imagetype=(".gif" || ".png" || ".bmp" || ".jpeg" || ".jpg" || ".GIF" || ".PNG" || ".JPEG" || ".JPG" || ".BMP");
					var imagetype=/^\S+\.(jpg|jpeg|png|JPG|JPEG|PNG)$/;
					if(!category_image.match(imagetype))
					{
					//		alert('Please Enter a Valid Image Type. Only JPEG, JPG, PNG, GIF, & BMP Is Allowed.');  
						document.getElementById("category_image").focus();				
						document.getElementById("Simage").innerHTML=" Please Enter a Valid Image Type. Only JPG, PNG Is Allowed";
						return false;
					}
					else
						{
							document.getElementById("Simage").innerHTML="";
						}
				}*/
		}
		</script>
   </head>

   <body class="staff">
<div id="wrapper">
         <div id="content">
         	<div id="header">
               <!--<div id="logo"><a href="index.php"><img src="/demo/staff/images/logo.png" alt="GrubTracker"></a></div>-->
               <?php
               include("header_session.php");
               ?>
            </div>
            <!--<ul id="staffmenu">
  </ul>-->	<?php 
					include("menu.php");
				?>
			<div id="darkbanner" class="banner320">
   <img src="../images/client.png">
   <h2>Add New Menu Category</h2>
</div>
<div id="darkbannerwrap">
</div>
<form name="form1" method="post" onSubmit="return valid()" enctype="multipart/form-data">
   <fieldset class="form">
      <legend>Provide Menu Category Details</legend>
      <p>
         <label for="category"><span id="SContact" style="color:#ff8f0d;font-size:14px;">* </span>Category Name:</label>
		 <input name="category" type="text" id="category"  /><span id="Scategory" style="color:red"></span>
      </p>
	   <p>
         <label for="image">Image:</label>
		 <input name="category_image" type="file" id="category_image" class="image" /><span id="Simage" style="color:red"></span>
      </p>
         <button type="Submit" class="positive" name="Submit" style="height:30px" >Submit</button>
        
   </fieldset>
</form>
<div id="footer"><a href="#" target='_blank'></a></div>
   </div>
   </div>
   <div id="wrapperbottom"></div>
		<?php 
			if(isset($_POST["Submit"]))
			{
				$category=$_POST["category"];
				//$imgname=$_FILES['category_image']['name'];
				//$imgtmp=$_FILES['category_image']['tmp_name'];
				
				$imgname=$_FILES['category_image']['name'];
				$imgtmp=$_FILES['category_image']['tmp_name'];
				
				if($imgname=="")
				{
					$imgname="http://grubtracker.canopussystems.com/images/53f2eecd43da8.png";
					$imgtmp="http://grubtracker.canopussystems.com/images/53f2eecd43da8.png";
				}
				move_uploaded_file('$imgname','upload/'.$imgname);
				
				
				//move_uploaded_file($imgtmp,"images/".$imgname) or die (mysql_error());
				//$path="images/".$imgname;
				
				
                 $sql1="SELECT * FROM menucategory WHERE vid='$id' AND name='$category'";		
						$result1=mysql_query($sql1);
						if($result1)
						{	
							if(mysql_num_rows($result1)<=0)
							{
									if(isset($_FILES['category_image']) || $_FILES['category_image']['size'] > 0)
									{
										//Do image stuff and query
										$sql="INSERT INTO menucategory(vid,name,image) values('$id','$category','$imgname')";
										$result=mysql_query($sql);
										if(($result)or die(mysql_error()))
										{
										echo"<script>alert('Menu Category Added Successful')</script>";
										}
									}
									else
									{
										//Do query without image.
										$sql="INSERT INTO menucategory(vid,name) values('$id','$category')";
										$result=mysql_query($sql);
										if(($result)or die(mysql_error()))
										{
										echo"<script>alert('Menu Category Added Successful')</script>";
										}
									}
									
							}
							else
									{
										echo"<script>alert('Error: Category Already Exists !')</script>";
									}
						}
			}
		?>
   </body>
   </html>