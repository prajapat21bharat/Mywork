			<div class="menu">
				<ul>
					<a href="#"><li>Home</li></a>
					<a href="addmenucategory.php"><li>Add Menu Category</li></a>
					<a href="addmenu.php"><li>Add Menu</li></a>
					<a href="vendors.php"><li>Vendors</li></a>
					<a href="managevendor.php"><li>Add User</li></a>
					<a href="seeorders.php"><li>View Order</li></a>
					<a href="viewvendorreview.php"><li>Vendor Reviews</li></a>
					<a href="newresetpassword.php"><li>Change Password</li></a>
				</ul>
			</div>
