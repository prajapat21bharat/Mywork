<html>
	<?php
		include("connection.php");
	?>
	
	<head>
		
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<link rel="shortcut icon" type="image/ico" href="/images/favicon.ico" />	
		<title>Grub Tracker</title>		
		<link href="styles.css" type="text/css" media="screen" rel="stylesheet" />		<style type="text/css">
		img, div { behavior: url("iepngfix.htc") }
		</style>
		<script>
		function valid()
		{
			var email=document.getElementsByName("user_name")[0].value;
			var password=document.getElementsByName("user_password")[0].value;
			if(email="" || password=="")
			{
				alert('Error Cannot Leave Blank !');
				return false;
			}
		}
		</script>
	</head>
	<body id="login">
		<div id="wrappertop"></div>
			<div id="wrapper">
					<div id="content">
						<div id="header">
                        <div style="width:218px;height:26px"><h2>Grub Tracker</h2></div>							
						</div>
						<div id="darkbanner" class="banner320">
							<h2>Login</h2>
						</div>
						<div id="darkbannerwrap">
						</div>
						<form name="form1" method="post" onsubmit="return valid()">
						<fieldset class="form">
                        	<p>
								<label for="user_name">E-Mail Id:</label>
								<input name="user_name" id="user_name" type="text" value="" style="height:30px" />
							</p>
							<p>
								<label for="user_password">Password:</label>
								<input name="user_password" id="user_password" type="password" style="height:30px" />
							</p>
							<button type="submit" class="positive" name="Submit" value="Login">Login
								<img src="images/key.png" alt="Announcement"/></button>
								<ul id="forgottenpassword">
								<li class="boldtext">|</li>
								<li><a href="forgot.php.htm">Forgotten it?</a></li>
							</ul>
                        </fieldset>
						
						
					</div>
				</div>   

<div id="wrapperbottom_branding"><div id="wrapperbottom_branding_text"><!--<a href="" style='text-decoration:none'></a>--></div></div>

	<?php
			if(isset($_POST["Submit"]))
			{
				$emailid=$_POST["user_name"];
				$password=$_POST["user_password"];
				
				$sql="SELECT password, emailid FROM userregistration WHERE emailid='$emailid' AND password='$password'";
				$result=mysql_query($sql);		
				if($result)
				{
					if(mysql_num_rows($result)>0)
					{	
						session_start();
						$_SESSION['login']=$emailid;
						header("location:managevendor.php?a='$emailid'");
					}
					else
					{
						echo"<script>alert('Error: Invalid Username & Password !')</script>";
					}
				}
			}
		?>
	</body>
</html>