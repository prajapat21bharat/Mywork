<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<title></title>
	<head>
	<meta name="viewport" content="width=device-width">
	<title>Grub Tracker</title>		
		<link href="styles.css" type="text/css" media="screen" rel="stylesheet" /><style type="text/css">
		img, div { behavior: url("iepngfix.htc") }
		</style>
	<script type="text/javascript">
		function validator()
			{
				var email=document.getElementsByName("email")[0].value;
				var password=document.getElementsByName("password")[0].value;
				var confirmpassword=document.getElementsByName("confirmpassword")[0].value;
				if(password!==confirmpassword)
				{
					alert('Password Does not Match');
					return false;
					document.getElementById("password").focus();
				}
				if(email=="")
				{
					alert('Error: Email Id cannot be blank!');
					return false;
					document.getElementById("email").focus();
				}
				if(password=="")
				{
					alert('Error: Password cannot be blank!');
					return false;
					document.getElementById("password").focus();
				}
				if(confirmpassword=="")
				{
					alert('Error: Confirm Password cannot be blank!');
					return false;
					document.getElementById("confirmpassword").focus();
				}
			}
	 </script>
	</head>
	<body id="login">
		<div id="wrappertop"></div>
			<div id="wrapper">
					<div id="content">
						<div id="header">
                        <div style="width:218px;height:26px"><h2>Grub Tracker</h2></div>
							<!--<h1></h1>-->
						</div>
						<div id="darkbanner" class="banner320">
							<h2>Reset Password</h2>
						</div>
						<div id="darkbannerwrap">
						</div>
						<form method="post" onsubmit="return validator()">
						<fieldset class="form">
                        	                                                                                       <p>
								<label style="float: left;text-align: right;width: 110px;font-weight: bold;margin-right: 10px;padding-top: 7px;" for="user_name">Enter E-Mail Id:</label>
								<input style="height: 20px;	width: 200px;_width: 237px;margin-bottom: 15px;padding: 3px;font: 16px 'Lucida Grande', arial, sans-serif;" name="email" id="email" type="text" value="" />
							</p>
							<p>
								<label style="float: left;text-align: right;width: 110px;font-weight: bold;margin-right: 10px;padding-top: 7px;" for="user_password">New Password:</label>
								<input style="height: 20px;	width: 200px;_width: 237px;margin-bottom: 15px;padding: 3px;font: 16px 'Lucida Grande', arial, sans-serif;" name="password" id="password" type="password" />
							</p>
                            <p>
								<label style="float: left;text-align: right;width: 110px;font-weight: bold;margin-right: 10px;padding-top: 7px;" for="user_password">Confirm Password:</label>
								<input style="height: 20px;	width: 200px;_width: 237px;margin-bottom: 15px;padding: 3px;font: 16px 'Lucida Grande', arial, sans-serif;" name="confirmpassword" id="confirmpassword" type="password" />
							</p>
 
							<button style="display:block;float:left;margin:0 3px 0 120px; _margin-left: 42px;" type="submit" class="positive" name="Submit">
								<img src="images/key.png" alt="Announcement"/>Request New Password</button>

								<!--<input type="submit" name="Submit" class="positive" value="Reset" />-->
                            						</fieldset>
						</form>
						
					</div>
				</div>   
	
</body>
		<?php
				if(isset($_POST["Submit"]))
				{
					$email=$_POST["email"];
					$password=$_POST["password"];
					$confirmpassword=$_POST["confirmpassword"];
					$sql="select * from userregistration where emailid='$email'";
					$result=mysql_query($sql);		
							if($result)
							{
								if(mysql_num_rows($result)>0)
								{	
								$sql="UPDATE userregistration SET password='$password' where emailid='$email'";
								$result=mysql_query($sql);
								if($result)
									{
										echo"<script>alert('Password Changed Successfully! Now Login With New Password') $result</script>";
										
									}
								else
									{
										echo"<script>alert('Try Again')</script>";
									}
								}
								else
									{				
									echo"<script>alert('User Does not Exist')</script>";
									}
							}
				}
			?>
</html>