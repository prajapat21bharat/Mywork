<?php include 'checksession.php'?>
<!DOCTYPE html>
<html>
   <head>
   	<?php
		include("connection.php");
	?>
      <meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
      <link rel="shortcut icon" type="image/ico" href="../images/favicon.ico" />
      <title>Grub Tracker</title>
      <link href="styles.css" type="text/css" media="screen" rel="stylesheet" />
      <style type="text/css">
         img, div { behavior: url(../iepngfix.htc) }
      </style>
	<script>
		function valid()
		{
			var category=document.getElementsByName("category")[0].value;
			var category_image=document.getElementsByName("category_image")[0].value;
			if(category=="")
			{
				document.getElementById("Scategory").innerHTML=" Please Enter Category name";
				return false;
			}
			if(category_image!=="")
			{
					//var imagetype=(".gif" || ".png" || ".bmp" || ".jpeg" || ".jpg" || ".GIF" || ".PNG" || ".JPEG" || ".JPG" || ".BMP");
					var imagetype=/^\S+\.(jpg|jpeg|png|JPG|JPEG|PNG)$/;
					if(!category_image.match(imagetype))
					{
					//		alert('Please Enter a Valid Image Type. Only JPEG, JPG, PNG, GIF, & BMP Is Allowed.');  
						document.getElementById("category_image").focus();				
						document.getElementById("Simage").innerHTML=" Please Enter a Valid Image Type. Only JPG, PNG Is Allowed";
						return false;
					}
					else
						{
							document.getElementById("Simage").innerHTML="";
						}
				}
		}
		</script>
   </head>

   <body class="staff">
      <div id="wrappertop"></div> 
      <!-- Show Search Results -->
			<!--<div id="search-results">
        	</div>-->
        <!-- End Search Results -->
<div id="wrapper">
         <div id="content">
         	<div id="header">
               <!--<div id="logo"><a href="index.php"><img src="/demo/staff/images/logo.png" alt="GrubTracker"></a></div>-->
               <div id="usercontainer">
			   <?php
			   		$mail=$_SESSION['login'];
					$sql="select firstname,image,id from userregistration where emailid='$mail'";
					$result=mysql_query($sql,$con);
					while($data=mysql_fetch_array($result))
					{
						$firstname=$data[0];
						$image=$data[1];
						$id=$data[2];
					}
			   ?>
                  <ul id="user-options">
                     <li class="boldtext">Welcome: <?php echo'<h6 style=color:blue>'.$firstname.'</h6>'.'<img src='.$image.' height="50px" width="50px" />'?></li>
                     <li class="boldtext">|</li>
                     <li><a id="logout-link" href="finallogin.php" alt="Logout"></a></li>
                  </ul>
               </div>
            </div>
        	<?php 
					include("menu.php");
				?>
			<div id="darkbanner" class="banner320">
   <img src="../images/client.png">
   <h2>Add New Menu Category</h2>
</div>
<div id="darkbannerwrap">
</div>
<form name="form1" method="post" onSubmit="return valid()" enctype="multipart/form-data">
   <fieldset class="form">
      <legend>Provide Menu Category Details</legend>
      <p>
         <label for="category"><span id="SContact" style="color:red;font-size:14px;">* </span>Category Name:</label>
		 <input name="category" type="text" id="category"  /><span id="Scategory" style="color:red"></span>
      </p>
	   <p>
         <label for="image">Image:</label>
		 <input name="category_image" type="file" id="category_image" class="image" /><span id="Simage" style="color:red"></span>
      </p>
      <button type="Submit" class="positive" name="Submit" style="height:30px" >Submit</button>
   </fieldset>
</form>
<div id="footer"><a href="#" target='_blank'></a></div>
   </div>
   </div>
   <div id="wrapperbottom"></div>
		<?php 
			if(isset($_POST["Submit"]))
			{
				$category=$_POST["category"];
				$imgname=$_FILES['category_image']['name'];
				$imgtmp=$_FILES['category_image']['tmp_name'];
				
				move_uploaded_file($imgtmp,"Imgs/".$imgname) or die (mysql_error());
				$path="Imgs/".$imgname;
				
                 $sql1="SELECT * FROM menucategory WHERE vid='$id' AND name='$category'";		
						$result1=mysql_query($sql1);
						if($result1)
						{	
							if(mysql_num_rows($result1)<=0)
							{
									$sql="INSERT INTO menucategory(vid,name,image) values('$id','$category','$path')";
									$result=mysql_query($sql);
									if(($result)or die(mysql_error()))
									{
									echo"<script>alert('Menu Category Added Successful')</script>";
									}
							}
							else
									{
										echo"<script>alert('Error: Category Already Exists !')</script>";
									}
						}
			}
		?>
   </body>
   </html>