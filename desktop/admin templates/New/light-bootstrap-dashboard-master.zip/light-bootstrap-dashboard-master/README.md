# light-bootstrap-dashboard

Live preview - http://demos.creative-tim.com/light-bootstrap-dashboard

Light Bootstrap Dashboard is an admin dashboard template designed to be beautiful and simple. 

Light Bootstrap Dashboard is an admin dashboard template designed to be beautiful and simple. It is built on top of Bootstrap 3 and it is fully responsive. It comes with a big collections of elements that will offer you multiple possibilities to create the app that best fits your needs. It can be used to create admin panels, project management systems, web applications backend, CMS or CRM.

The product represents a big suite of front-end developer tools that can help you jump start your project. We have created it thinking about things you actually need in a dashboard. Light Bootstrap Dashboard contains multiple handpicked and optimised plugins. Everything is designed to fit with one another. As you will be able to see, the dashboard you can access on Creative Tim is a customisation of this product.

It comes with 6 filter colors for the sidebar (“black”, “azure”,”green”,”orange”,”red”,”purple”) and an option to have a background image.

Special thanks go to:
Robert McIntosh for the notification system
Chartist for the wonderful charts
We are very excited to share this dashboard with you and we look forward to hearing your feedback!

V1.0 - 20 August 2015 initial release

V1.1 - 08 September 2015 - bug fixing [current version]
- added company name/logo inside the sidebar for small screens
- fixed bug for notification with close button on small screens
- fix live preview bug for download on small screens
- fix table responsive for small screens
- added new labels for chartist on small screens
