<?php $site_url = site_url() . 'admin/order/'; ?>
<div id="page-content">
    <div id='wrap'>

        <div id="page-heading">
            <ul class="breadcrumb">
                <li><a href="<?php echo $site_url; ?>">Dashboad</a></li>
                <li><a href="<?php echo $site_url . 'index'; ?>">Order</a></li>
                <li class="active">Assign Order</li>
            </ul>

            <h1>Assigned Order</h1>

        </div>
        <div class="container">
            <?php if (isset($success)) { ?>
                <div class="alert alert-dismissable alert-success">
                    <strong>Well done!</strong> Data Successfully Inserted.
                    <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                </div>
            <?php } ?>
            <div class="row">
                <div class="col-xs-12">

                    <div class="panel panel-sky">
                        <div class="panel-heading">
                            <h4>
                                <ul class="nav nav-tabs">
                                    <li class="active"><a href="#Orders_Assign_tab" data-toggle="tab">Orders Assign</a></li>
                                    <li><a href="#order_trace_tab" data-toggle="tab">Trace</a></li>
                                    <li><a href="#order_status_tab" data-toggle="tab">Status</a></li>
                                    <li><a href="#order_query_tab" data-toggle="tab">Query</a></li>
                                </ul>
                            </h4>
                            <div class="options">   
                                <a href="javascript:;" class="panel-collapse"><i class="icon-chevron-down"></i></a>
                            </div>
                        </div>

                        <div class="panel-body collapse in">
                            <div class="tab-content">

                                <!-- Its Order Assign Tab-->  
                                <div class="tab-pane active" id="Orders_Assign_tab">

                                    <?php
                                    $attr = array('class' => 'form-horizontal', 'id' => 'validate-form', 'data-validate' => 'parsley');
                                    echo form_open_multipart('', $attr);
                                    ?>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Client Name</label>
                                        <div class="col-sm-6">
                                            <input type="text" value="<?php echo $order[0]->order_client_name ?>"  class="form-control" disabled="">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Order Title</label>
                                        <div class="col-sm-6">
                                            <input type="text" value="<?php echo $order[0]->order_title ?>"  class="form-control" disabled="">

                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Order Process Type</label>
                                        <div class="col-sm-6">
                                            <input type="text" value="<?php echo $order[0]->process_name ?>"  class="form-control" disabled="">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Order Amount</label>
                                        <div class="col-sm-6">
                                            <input type="text" value="<?php echo $order[0]->order_amount ?>"  class="form-control" disabled="">

                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Order Details/Requirement</label>
                                        <div class="col-sm-6">
                                            <textarea   required="required" name="order[order_details]" class="form-control autosize"><?php echo $order[0]->order_details ?></textarea>
                                            <?php echo form_error("order[order_details]"); ?>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Order Cost</label>
                                        <div class="col-sm-6">
                                         <!--<div class="input-group">-->        
                                                <input type="text" value="<?php echo $order[0]->order_cost ?>"  class="form-control" disabled="">
                                            <!--<span class="input-group-addon"><i class="icon-usd"></i></span>
                                            </div>-->
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Order Date</label>
                                        <div class="col-sm-6">
                                            <div class="input-group">
                                                <input type="text" value="<?php echo $order[0]->order_date ?>"  class="form-control" disabled="">
                                                <span class="input-group-addon"><i class="icon-calendar" ></i></span>
                                            </div>

                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Order Delivery Date</label>
                                        <div class="col-sm-6">
                                            <div class="input-group">
                                                <input type="text"  name="order[order_delivery_date]" value="<?php echo $order[0]->order_delivery_date ?>" placeholder="DD-MM-YYYY"  required="required" class="form-control datepicker6" />
                                                <span class="input-group-addon"><i class="icon-calendar datepicker6"></i></span>
                                            </div>
                                            <?php echo form_error("order[order_delivery_date]"); ?>

                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-3 control-label">Select Worker</label>
                                        <div class="col-sm-6">
                                            <select name="order[worker_id]"  class="form-control">
                                                <option value="">Select Worker</option>
                                                <?php
                                                foreach ($worker as $worker) {
                                                    if (set_value("order[worker_id]") == $worker->p_u_id)
                                                        echo '<option selected="selected" value="' . $worker->p_u_id . '">' . $worker->p_fname . ' ' . $worker->p_lname . '</option>';

                                                    else if ($order[0]->worker_id == $worker->p_u_id)
                                                        echo '<option selected="selected" value="' . $worker->p_u_id . '">' . $worker->p_fname . ' ' . $worker->p_lname . '</option>';
                                                    else
                                                        echo '<option value="' . $worker->p_u_id . '">' . $worker->p_fname . ' ' . $worker->p_lname . '</option>';
                                                }
                                                ?>
                                            </select>
                                            <?php echo form_error("order[worker_id]"); ?>
                                        </div>
                                    </div>
                                    <div class="">
                                        <div class="row">
                                            <div class="col-sm-6 col-sm-offset-3">
                                                <div class="btn-toolbar">
                                                    <input class="btn-success btn" type="submit" value="Submit" onclick="javascript:$('#validate-form').parsley('validate');" />
                                                    <a class="btn-default btn" href="<?php echo $site_url . 'index'; ?>">Cancel</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    </form>
                                </div>

                                <!-- Its trace Tab-->
                                <div class="tab-pane" id="order_trace_tab">
                                    <h1><?php echo $order['0']->process_name; ?></h1>
                                    <div class="row">
                                        <div class="tab-pane active" id="Orders_Process_tab">



                                            <?php
                                            $j = 2;
                                            $k = 1;
                                            $i = 0;
                                            $row = 1;
                                            $count = count($sub_process);

                                            foreach ($sub_process as $sub_process) {
                                                $order_id = base64_decode($this->uri->segment('4'));

                                                $joins_process = array(array(
                                                        'table' => 'user_profile',
                                                        'condition' => 'order_process.worker_id=user_profile.p_u_id',
                                                        'jointype' => 'left'
                                                ));
                                                $where = array('process_id' => $sub_process->process_id,
                                                    'order_id' => $order_id);
                                                $column = array('p_fname', 'p_lname', 'status');
                                                $order_process = $this->user_model->get_joins('order_process', $where, $joins_process, $column, NULL, NULL, NULL, '1');

                                                if ($order_process['0']->status == 0) {
                                                    $class = "";
                                                    $status = 'Pending';
                                                    $value = '1';
                                                } elseif ($order_process['0']->status == 1) {
                                                    $class = "";
                                                    $status = 'In-process';
                                                    $value = '2';
                                                } elseif ($order_process['0']->status == 2) {
                                                    $status = 'Complete';
                                                    $value = '3';
                                                    $class = "tiles-complete";
                                                }

                                                $opacity = '';
                                                if ($i == 1)
                                                    $opacity = "opacity";


                                                if ($value != '3') {
                                                    if ($j == 2) {
                                                        $i = $i + 1;
                                                    }
                                                }

                                                $j = $order_process['0']->status;
                                                ?>
                                                <div class="col-sm-2 tile-block <?php echo $class; ?>">
                                                    <div class="shortcut-tiles tiles-success tiles-pending <?php echo $opacity ?>">
                                                        <div class="tiles-body">
                                                            <?php echo $sub_process->process_name ?>
                                                        </div>
                                                        <a id="click_<?php echo $sub_process->process_id ?>" class="shortcut-tiles tiles-midnightblue"  href="javascript:;">
                                                            <div class="tiles-heading" id="status_<?php echo $sub_process->process_id ?>">
                                                                <span><?php echo $status ?></span>
                                                            </div>
                                                        </a>
                                                        <div class="trace_worker">
                                                            <?php
                                                            if (isset($order_process['0']->p_fname))
                                                                echo $order_process['0']->p_fname . " " . $order_process['0']->p_lname
                                                                ?>
                                                        </div>
                                                    </div>

                                                </div>
                                                <?php if ($count != $k) { ?>
                                                    <div class="col-sm-1 arrow-lesser">
                                                        <img src="<?php echo base_url() ?>assets/img/arrow-lesser.png" alt="" border="0" />
                                                    </div>
                                                    <?php
                                                }
                                                $k++;
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>


                                <!-- Its Status Tab-->
                                <div class="tab-pane" id="order_status_tab">
                                    <h1>Status</h1>
                                    <div class="row_content" id="content">
                                        <?php foreach ($worker_status as $status) { ?>
                                            <div class="main_content">
                                                <p>
                                                    Posted by <b><?php echo $status->p_fname . ' ' . $status->p_lname; ?></b>
                                                    <span> <?php echo timeAgo($status->s_date); ?></span>
                                                </p>
                                                <div class="left_content">
                                                    <img class="img-circle img-thumbnail" src="<?php echo site_url() . 'uploads/profile/' . $status->p_image; ?>" />
                                                </div>

                                                <div class="right_content"><?php echo nl2br($status->s_status); ?></div>
                                            </div>
                                        <?php } ?>
                                    </div>
                                    
                                    <?php  if($worker_status){ ?>
                                    <!-- the input fields that will hold the variables we will use -->
                                    <input type='hidden' id='current_page' />
                                    <input type='hidden' id='show_per_page' />
                                    <div class="col-xs-6 pull-right">
                                        <div id="page_navigation" class="pull-right"></div>
                                    </div>
                                    <?php }else{echo 'No records found';}?>
                                </div>


                                <!-- Its Query Tab-->
                                <div class="tab-pane" id="order_query_tab">
                                    <h1>Query</h1>
                                    <div class="row_content" id="query_content">
                                        <?php foreach ($query as $query) { ?>
                                            <div class="main_content">
                                            <div class="query_content">
                                                <p>Posted by <b><?php echo $query->p_fname . ' ' . $query->p_lname; ?></b>
                                                    <span> <?php echo timeAgo($query->q_date); ?></span></p>
                                                <div class="left_content">
                                                    <img class="img-circle img-thumbnail" src="<?php echo site_url() . 'uploads/profile/' . $query->p_image; ?>" />
                                                </div>
                                                <div class="right_content"><?php echo nl2br($query->q_query); ?></div>
                                                </div>

                                                <div class="reply_content">
                                                    <div class="reply_discussion" id="reply_discussion_<?php echo $query->query_id ?>">


                                                        <?php
                                                        $joins_query_resp = array(array('table' => 'user_profile',
                                                                                        'condition' => 'query_response.r_worker_id=user_profile.p_u_id',
                                                                                        'jointype' => 'inner'));
                                                        $where_resp = array('r_query_id' => $query->query_id);
                                                        $column_resp = array('q_date', 'query_id', 'q_query', 'p_image', 'p_fname', 'p_lname');
                                                        $data = $this->user_model->get_joins('query_response', $where_resp, $joins_query_resp, NULL, NULL, NULL, 'response_id  ASC');
                                                        if ($data)
                                                            echo ' <p class="discussion-text">Discuss this message</p> <div class="reply_wrap_content">';
                                                        foreach ($data as $resp) {?>
                                                            <div class="reply_ans">
                                                                <div class="left_content">
                                                                    <img class="img-circle reply_img img-thumbnail" src="<?php echo site_url() . 'uploads/profile/' . $resp->p_image; ?>" />
                                                                </div>
                                                                <div class="right_content">
                                                                    <p><b><?php echo $resp->p_fname . ' ' . $resp->p_lname; ?></b><span class="pull-right"> <?php echo timeAgo($resp->r_date); ?></span></p>
                                                                    <?php echo nl2br($resp->r_response); ?>
                                                                    <!--<p><span> <?php //echo timeAgo($resp->r_date); ?></span></p>-->
                                                                </div>  
                                                            </div> 

                                                        <? } 
                                                        
                                                        if ($data) echo '</div>';
                                                        ?>
                                                        
                                                        <div id="new_reply_ans_<?php echo $query->query_id ?>"></div>
                                                        <p class="reply_btn" onclick="reply_div(<?php echo $query->query_id ?>)">Reply</p>

                                                        <div class="reply_textarea hidden" id="reply_textar_<?php echo $query->query_id ?>">
                                                            <div class="left_content">
                                                                
                                                               <?php  $img=$this->user_model->get_sql_select_data('user_profile', array('p_u_id' => $this->session->userdata('u_id')),array('p_image'), '1'); ?>
                                                                <img class="img-circle reply_img img-thumbnail" src="<?php echo site_url() . 'uploads/profile/' . $img[0]->p_image; ?>" />
                                                            </div>
                                                            <div class="right_content">
                                                                <textarea name="" id="reply_text_value_<?php echo $query->query_id ?>" class="form-control autosize reply_text_value"></textarea>
                                                                <p></p>
                                                                <input class="btn-success btn pull-right" type="submit" value="Submit" onclick="query_reply(<?php echo $query->query_id ?>)" />
                                                            </div> 
                                                           
                                                        </div>
                                                    </div>
                                                 </div>
                                            </div>
                                     <?php } ?>
                                    </div>

                                    <!-- the input fields that will hold the variables we will use -->
                                    <?php  if($query){ ?>
                                    <input type='hidden' id='query_current_page' />
                                    <input type='hidden' id='query_show_per_page' />
                                    <div class="col-xs-6 pull-right">
                                        <div id="query_page_navigation" class="pull-right"></div>
                                    </div>
                                    <?php }else{echo 'No records found';}?>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>
            </div>


        </div> <!-- container -->
    </div> <!--wrap -->
</div> <!-- page-content -->

<!-- Footer Contained -->
<?php echo $this->load->view('template/footer_admin'); ?> 

<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/jquery-1.10.2.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/jqueryui-1.10.3.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/bootstrap.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/enquire.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/jquery.cookie.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/jquery.touchSwipe.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/jquery.nicescroll.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/codeprettifier/prettify.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/easypiechart/jquery.easypiechart.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/sparklines/jquery.sparklines.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/form-toggle/toggle.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/form-parsley/parsley.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/demo/demo-formvalidation.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/form-multiselect/js/jquery.multi-select.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/quicksearch/jquery.quicksearch.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/form-typeahead/typeahead.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/form-select2/select2.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/form-autosize/jquery.autosize-min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/form-ckeditor/ckeditor.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/form-colorpicker/js/bootstrap-colorpicker.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/jqueryui-timepicker/jquery.ui.timepicker.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/form-daterangepicker/daterangepicker.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/form-daterangepicker/moment.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/demo/demo-formcomponents.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/datatables/jquery.dataTables.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/datatables/dataTables.bootstrap.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/demo/demo-datatables.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/placeholdr.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/application.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/demo/demo.js'></script> 

<script type="text/javascript">
var site_url="<?php echo $site_url ?>";
$(document).ready(function() {
    
    /*---Its function use to New Line------*/
    textarea = $('.reply_text_value');
    textarea.keyup(insertNewlines);  
});


</script>
<script type='text/javascript' src='<?php echo base_url(); ?>assets/demo/comman_ajax.js'></script>

</html>
</body>