<?php $site_url=site_url().'admin/order/'; ?>
<div id="page-content">
    <div id='wrap'>
        <div id="page-heading">
            <ol class="breadcrumb">
                <li><a href="<?php echo $site_url ?>">Dashboad</a></li>
                <li>Order</li>
                <li class="active">Orders</li>
            </ol>

            <h1>Orders</h1>

        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-sky">
                        <div class="panel-heading">
                            <h4>Orders Data</h4>
                            <div class="options">   
                                <a href="javascript:;" class="panel-collapse"><i class="icon-chevron-down"></i></a>
                                <a href="<?php echo $site_url.'add' ?>">Add Order</a>
                            </div>
                        </div>
                        <div class="panel-body table-responsive collapse in">
                            <table cellpadding="0" cellspacing="0" border="0" class="table table-striped datatables" id="example">
                                <thead>
                                    <tr>
                                        <th class="hidden">S.No</th>
                                        <th>Order Date</th>
                                        <th>Order Title</th>
                                        <th>Customer Name</th>
                                        <th>Process Type</th>
                                        <th class="hidden-sm">Cost</th>
                                        <th>Amount</th>
                                        <th>Delivery Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody id="list-data">

                                    <?php
                                    foreach ($order as $order) {
                                        ?>

                                        <tr id="<?php echo 'delete_' . $order->order_id; ?>">
                                            <td class="hidden"><?php echo $order->order_id ?></td>
                                            <td><?php echo $order->order_date ?></td>
                                            <td><?php echo $order->order_title ?></td>
                                            <td><?php echo $order->order_client_name ?></td>
                                            <td><?php echo $order->process_name ?></td>
                                            <td class="hidden-sm"><!--<span class="icon-usd"></span>--><?php echo $order->order_cost ?></td>
                                            <td><?php echo $order->order_amount ?></td>
                                            <td><?php echo $order->order_delivery_date ?></td>
                                            
                                            <td>
                                                <span id='order_<?php echo $order->order_id; ?>'>
                                                 <?php
                                                    if ($order->order_process_status == 0) {
                                                        $class = 'btn-primary ';
                                                        $status = "Assigned";
                                                    } else if($order->order_process_status == 1) {
                                                        $class = 'btn-info';
                                                        $status = "In-process";
                                                    }else if($order->order_process_status ==2) {
                                                        $class = 'btn-success';
                                                        $status = "Complete";
                                                    }
                                                    

                                                    echo "<a class='btn " . $class . "' href='".$site_url.'assign/'.base64_encode($order->order_id)."'>" . $status . "</a>";
                                                    
                                                    ?>
                                                </span>
                                               <!--<span class='btn btn-danger' onclick='order_delete(<?php echo $order->order_id ?>)'>
                                                    <i class="icon-trash"></i>
                                                </span>-->
                                            </td>

                                        </tr>
                              <?php } ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>

        </div> <!-- container -->
    </div> <!--wrap -->
</div> <!-- page-content -->

<!-- Footer Contained -->
<?php echo $this->load->view('template/footer_admin'); ?> 

<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/jquery-1.10.2.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/jqueryui-1.10.3.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/bootstrap.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/enquire.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/jquery.cookie.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/jquery.touchSwipe.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/jquery.nicescroll.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/codeprettifier/prettify.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/easypiechart/jquery.easypiechart.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/sparklines/jquery.sparklines.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/form-toggle/toggle.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/datatables/jquery.dataTables.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/datatables/dataTables.bootstrap.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/demo/demo-datatables.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/placeholdr.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/application.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/demo/demo.js'></script> 
<script>
        $(function() {
            /*----its using for first column show Desc Order*/
            var oTable = $('#example').dataTable();
            oTable.fnSort([[0, 'desc']]);
        });// This function use to first column show to descnding order

            
        /*----its function use for Delete order-------*/
        function order_delete(id) {
            if (confirm("Delete This Order/Product")) {
                var form_data = {
                    order_id: id};

                $.ajax({
                    url: '<?php echo $site_url.'order_delete'; ?>',
                    data: form_data,
                    type: 'post',
                    datatype: 'json',
                    success: function(data) {
                        $("#delete_" + id).remove();
                    }
                });
            }
        }
</script>
</body></html>