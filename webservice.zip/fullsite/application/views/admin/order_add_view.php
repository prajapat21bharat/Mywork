<?php $site_url = site_url() . "admin/order/" ?>
<div id="page-content">
    <div id='wrap'>

        <div id="page-heading">
            <ul class="breadcrumb">
                <li><a href="<?php echo $site_url; ?>">Dashboad</a></li>
                <li>Order</li>
                <li class="active">Add Order Form</li>
            </ul>

            <h1>Add Order</h1>

        </div>
        <div class="container">
            <?php if (isset($success)) { ?>
                <div class="alert alert-dismissable alert-success">
                    <strong>Well done!</strong> Data Successfully Inserted.
                    <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                </div>
            <?php } ?>
            <div class="row">
                <div class="col-xs-12">
                    <div class="panel panel-sky">
                        <div class="panel-heading"><h4>Add Order </h4></div>
                        <div class="panel-body">
                            <?php
                            $attr = array('class' => 'form-horizontal row-border', 'id' => 'validate-form', 'data-validate' => 'parsley');
                            echo form_open_multipart($site_url . 'add', $attr);
                            ?>
                            <div class="form-group">
                                <label class="col-sm-3 control-label">Hospital Name</label>
                                <div class="col-sm-6">
                                    <select name="order[h_id]"  class="form-control" required="required">
                                        <option value="">Select Hospital</option>
                                        <?php
                                        foreach ($hospital as $hospital) {
                                            echo '<option value="' . $hospital->h_id . '" ' . set_select('order[h_id]', $hospital->h_id) . '>' . $hospital->h_name . '</option>';
                                        }
                                        ?>
                                    </select>
                                    <?php echo form_error("order[h_id]"); ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label">Patient Name</label>
                                <div class="col-sm-6">
                                    <input type="text"  name="order[patient_name]" value="<?php echo set_value("order[patient_name]"); ?>" placeholder="Enter Patient Name" required="required" class="form-control" />
                                    <?php echo form_error("order[patient_name]"); ?>
                                </div>
                            </div>
                           
                            <div class="form-group">
                                <label class="col-sm-3 control-label">Enter Order No.</label>
                                <div class="col-sm-6">
                                    <input  required="required" class="form-control"  type="text" name="order[order_pdf_no]" id="category" value="<?php echo set_value("order[order_pdf_no]"); ?>" />
                                    <ul id="categorymenu" class="mcdropdown_menu">
                                        <?php
                                        $dir = 'footlabs_pdf';
                                        $array = scandir($dir, 1);
                                        foreach ($array as $index => $data) {
                                            if ($data['value'] == '..' || $data['value'] == '.') {
                                                unset($array[$index]);
                                            }
                                        }
                                        foreach ($array as $val) {
                                            ?>
                                        <li rel='<?php echo $val ?>'><span class="file-name" ><?php echo $val; ?></span> &nbsp;&nbsp;&nbsp;&nbsp; <a  class="fancybox" href="javascript:;" onclick="pdf('<?php echo $val; ?>')">Preview</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;   Attached </li>
                                        <? }
                                        ?>

                                    </ul>
                                     <?php echo form_error("order[order_pdf_no]"); ?>
                                </div> 
                            </div>


                            <div class="form-group">
                                <label class="col-sm-3 control-label">Customer Name</label>
                                <div class="col-sm-6">
                                    <input type="text"  name="order[order_client_name]" value="<?php echo set_value("order[order_client_name]"); ?>" placeholder="order client name" required="required" class="form-control" />
                                    <?php echo form_error("order[order_client_name]"); ?>
                                   
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-3 control-label">Order Title</label>
                                <div class="col-sm-6">
                                    <input type="text"  name="order[order_title]" value="<?php echo set_value("order[order_title]"); ?>" placeholder="Order Title" required="required" class="form-control" />
                                    <?php echo form_error("order[order_title]"); ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-3 control-label">Order Type</label>
                                <div class="col-sm-6">
                                    <select name="order[order_process_type]"  class="form-control" required="required">
                                        <option value="">Select Order Type</option>
                                        <?php
                                        foreach ($process as $process) {
                                            echo '<option value="' . $process->process_id . '"  ' . set_select('order[order_process_type]', $process->process_id) . '>' . $process->process_name . '</option>';
                                        }
                                        ?>
                                    </select>
                                    <?php echo form_error("order[order_process_type]"); ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-3 control-label">Order Amount</label>
                                <div class="col-sm-6">
                                    <input type="text" data-type="digits" name="order[order_amount]" value="<?php echo set_value("order[order_amount]"); ?>" placeholder="Order Amount" required="required" class="form-control" />
                                    <?php echo form_error("order[order_amount]"); ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-3 control-label">Order Details/Requirement</label>
                                <div class="col-sm-6">

                                    <textarea required="required" name="order[order_details]" class="form-control autosize"><?php echo set_value("order[order_details]"); ?></textarea>
                                    <?php echo form_error("order[order_details]"); ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-3 control-label">Order Cost</label>
                                <div class="col-sm-6">
                                    <!--<div class="input-group">-->                                  
                                    <input type="text" data-type="digits" name="order[order_cost]" value="<?php echo set_value("order[order_cost]"); ?>" placeholder="Order Cost" required="required" class="form-control" />
                                    <!--<span class="input-group-addon"><i class="icon-usd"></i></span>
                                    </div>-->
                                    <?php echo form_error("order[order_cost]"); ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-3 control-label">Order Date</label>
                                <div class="col-sm-6">
                                    <div class="input-group">
                                        <input type="text" readonly="" name="order[order_date]"  value="<?php echo set_value("order[order_date]"); ?>" placeholder="DD-MM-YYYY"   required="required" class="form-control datepicker5" />
                                        <span class="input-group-addon"><i class="icon-calendar datepicker5" ></i></span>
                                    </div>
                                    <?php echo form_error("order[order_date]"); ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-3 control-label">Order Delivery Date</label>
                                <div class="col-sm-6">
                                    <div class="input-group">
                                        <input type="text" readonly=""   name="order[order_delivery_date]" value="<?php echo set_value("order[order_delivery_date]"); ?>" placeholder="DD-MM-YYYY"  required="required" class="form-control datepicker6" />
                                        <span class="input-group-addon"><i class="icon-calendar datepicker6"></i></span>
                                    </div>
                                    <?php echo form_error("order[order_delivery_date]"); ?>
                                </div>
                            </div>
                            <div class="panel-footer">
                                <div class="row">
                                    <div class="col-sm-6 col-sm-offset-3">
                                        <div class="btn-toolbar">
                                            <input class="btn-success btn" type="submit" value="Submit" onclick="javascript:$('#validate-form').parsley('validate');" />
                                            <button type="reset" class="btn-default btn">Reset</button>
                                            <a class="btn-default btn" href="<?php echo $site_url . 'index' ?>">Cancel</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div> <!-- container -->
    </div> <!--wrap -->
</div> <!-- page-content -->

<!-- Footer Contained -->
<?php echo $this->load->view('template/footer_admin'); ?> 

<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/jquery-1.10.2.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/jqueryui-1.10.3.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/bootstrap.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/enquire.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/jquery.cookie.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/jquery.touchSwipe.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/jquery.nicescroll.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/codeprettifier/prettify.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/easypiechart/jquery.easypiechart.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/sparklines/jquery.sparklines.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/form-toggle/toggle.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/form-parsley/parsley.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/demo/demo-formvalidation.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/form-multiselect/js/jquery.multi-select.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/quicksearch/jquery.quicksearch.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/form-typeahead/typeahead.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/form-select2/select2.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/form-autosize/jquery.autosize-min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/form-ckeditor/ckeditor.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/form-colorpicker/js/bootstrap-colorpicker.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/jqueryui-timepicker/jquery.ui.timepicker.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/form-daterangepicker/daterangepicker.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/form-daterangepicker/moment.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/demo/demo-formcomponents.js'></script>
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/placeholdr.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/application.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/demo/demo.js'></script> 
<!-- Add fancyBox main JS and CSS files -->
<script type="text/javascript" src='<?php echo base_url(); ?>assets/js/jquery.fancybox.js'></script>
<link rel="stylesheet" type="text/css" href='<?php echo base_url(); ?>assets/css/jquery.fancybox.css' media="screen" />

<script type="text/javascript">
function pdf(name){
$.fancybox({ 
        type: 'html',
        autoSize: false,
        content: '<embed src="<?php echo  base_url().'footlabs_pdf/' ?>'+name+'#nameddest=self&page=1&view=FitH,0&zoom=80,0,0" type="application/pdf" height="99%" width="100%" />',
      beforeClose: function() {
        $(".fancybox-inner").unwrap();
        },
      helpers: {
            overlay: {
            opacity: 0.3
             } // overlay
         }
    });
}
</script>
<link type="text/css" href="<?php echo base_url(); ?>assets/new/docs.css" rel="stylesheet" media="all" />
<link type="text/css" href="<?php echo base_url(); ?>assets/new/jquery.mcdropdown.min.css" rel="stylesheet" media="all" />
 <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/new/jquery.bgiframe.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/new/jquery.mcdropdown.min.js"></script>
<script type="text/javascript">
// on DOM ready
   var $j = jQuery.noConflict();
    $j(document).ready(function() {        
       $j("#category").mcDropdown("#categorymenu");
    });
    
</script>



