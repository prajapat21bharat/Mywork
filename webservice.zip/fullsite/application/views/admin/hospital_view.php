<div id="page-content">
    <div id='wrap'>
        <div id="page-heading">
            <ul class="breadcrumb">
                <li><a href="<?php echo site_url() . 'admin/order'; ?>">Dashboad</a></li>
                <li>Hospital</li>
                <li class="active">Hospital</li>
            </ul>
            <h1>Hospital</h1>
        </div>


        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-sky">
                        <div class="panel-heading">
                            <h4>Hospital Data</h4>
                            <div class="options">   

                                <a href="javascript:;" class="panel-collapse"><i class="icon-chevron-down"></i></a>
                                <a href="<?php echo site_url() . 'admin/hospital/add' ?>">Add Hospitals</a>
                            </div>
                        </div>
                        <div class="panel-body collapse in">
                            <table cellpadding="0" cellspacing="0" border="0" class="table table-striped datatables" id="example">
                                <thead>
                                    <tr>
                                        <th>Hospitals Name</th>                                        
                                        <th>Action</th>

                                    </tr>
                                </thead>
                                <tbody id="list-data">

                                    <?php
                                    foreach ($hospital as $hospital) {
                                        ?>
                                        <tr id='hospital_tr_<?php echo $hospital->h_id; ?>'>
                                            <td>                                                
                                                <?php echo $hospital->h_name ?>
                                            </td>

                                            <td class="center worker-btn" id='hospital_<?php echo $hospital->h_id; ?>'>
                                                <?php
                                                if ($hospital->h_status == 1) {
                                                    $class = 'btn-success';
                                                    $status = "Inactive";
                                                    $onclick = "hospital_action(" . $hospital->h_id . ",0)";
                                                } else {
                                                    $class = 'btn-danger';
                                                    $status = "Active";
                                                    $onclick = "hospital_action(" . $hospital->h_id . ",1)";
                                                }

                                                echo "<a  class='btn " . $class . "' href='javascript:;' onclick='" . $onclick . "'>" . $status . "</a>";
                                                ?>
                                                <!--<a  class='btn btn-midnightblue' onclick='hospital_delete("<?php echo $hospital->h_id; ?>")'>Delete</a>-->
                                            </td>
                                        </tr>
                                    <?php }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </div> <!-- container -->
    </div> <!--wrap -->
</div> <!-- page-content -->


<!-- Footer Contained -->
<?php echo $this->load->view('template/footer_admin'); ?> 

<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/jquery-1.10.2.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/jqueryui-1.10.3.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/bootstrap.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/enquire.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/jquery.cookie.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/jquery.touchSwipe.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/jquery.nicescroll.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/codeprettifier/prettify.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/easypiechart/jquery.easypiechart.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/sparklines/jquery.sparklines.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/form-toggle/toggle.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/datatables/jquery.dataTables.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/datatables/dataTables.bootstrap.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/demo/demo-datatables.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/placeholdr.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/application.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/demo/demo.js'></script> 
<script>
    function hospital_action(id, val) {
        var form_data = {
            h_id: id,
            value: val};
        $.ajax({
            url: '<?php echo site_url() . 'admin/hospital/hospital_active'; ?>',
            data: form_data,
            type: 'post',
            datatype: 'json',
            success: function(data) {
                if (data == "1") {
                    if (val == "1") {
                        var sclass = 'btn-success';
                        var status = "Inactive";
                        var onclick = "hospital_action(" + id + ",0)";
                    } else {
                        var sclass = 'btn-danger';
                        var status = "Active";
                        var onclick = "hospital_action(" + id + ",1)";
                    }
                    $("#hospital_" + id).html("<a  class='btn " + sclass + "' href='javascript:;' onclick='" + onclick + "'>" + status + "</a>");
                }
            }
        });
    }
</script>
<?php /*function hospital_delete(id) {
   var form_data = {h_id: id};
   if(confirm("Delete This Hospital")){
   $.ajax({
       url: '<?php echo site_url() . 'admin/hospital/hospital_delete'; ?>',
       data: form_data,
       type: 'post',
       datatype: 'json',
       success: function(data) {
           if (data == "1") {
               $("#hospital_tr_"+id).remove();
           }
         }
       });
       }
 }*/?>

</html>
</body>