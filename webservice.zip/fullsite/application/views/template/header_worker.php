<!DOCTYPE html>
<html lang="en">
    <head>
        <?php $base_url = base_url();
        $site_url = site_url() . 'home/';
        ?>
        <meta charset="utf-8" />
        <title>Footlabs</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta name="description" content="Footlabs" />
        <meta name="author" content="The Red Team" />

        <link href="<?php echo $base_url ?>assets/css/styles.min.css" rel="stylesheet" type='text/css' media="all" />
        <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600' rel='stylesheet' type='text/css' />


        <link href='<?php echo $base_url ?>assets/demo/variations/default.css' rel='stylesheet' type='text/css' media='all' id='styleswitcher' /> 
        <link href='<?php echo $base_url ?>assets/demo/variations/default.css' rel='stylesheet' type='text/css' media='all' id='headerswitcher' /> 
        <link rel='stylesheet' type='text/css' href='<?php echo $base_url ?>assets/plugins/codeprettifier/prettify.css' /> 
        <link rel='stylesheet' type='text/css' href='<?php echo $base_url ?>assets/plugins/form-toggle/toggles.css' /> 
        <link rel='stylesheet' type='text/css' href='<?php echo $base_url ?>assets/plugins/form-select2/select2.css' /> 
        <link rel='stylesheet' type='text/css' href='<?php echo $base_url ?>assets/plugins/form-multiselect/css/multi-select.css' /> 
        <link rel='stylesheet' type='text/css' href='<?php echo $base_url ?>assets/plugins/jqueryui-timepicker/jquery.ui.timepicker.css' /> 
        <link rel='stylesheet' type='text/css' href='<?php echo $base_url ?>assets/plugins/form-daterangepicker/daterangepicker-bs3.css' /> 
        <link rel='stylesheet' type='text/css' href='<?php echo $base_url ?>assets/js/jqueryui.css' /> 
        <link rel='stylesheet' type='text/css' href='<?php echo $base_url ?>assets/plugins/codeprettifier/prettify.css' /> 
        <link rel='stylesheet' type='text/css' href='<?php echo $base_url ?>assets/plugins/form-toggle/toggles.css' /> 
        <link rel='stylesheet' type='text/css' href='<?php echo $base_url ?>assets/plugins/datatables/dataTables.css' /> 
        <link rel='stylesheet' type='text/css' href='<?php echo $base_url ?>assets/plugins/codeprettifier/prettify.css' /> 
        <link rel='stylesheet' type='text/css' href='<?php echo $base_url ?>assets/plugins/form-toggle/toggles.css' /> 

        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head>

    <script>
        (function(i, s, o, g, r, a, m) {
            i['GoogleAnalyticsObject'] = r;
            i[r] = i[r] || function() {
                (i[r].q = i[r].q || []).push(arguments)
            }, i[r].l = 1 * new Date();
            a = s.createElement(o),
                    m = s.getElementsByTagName(o)[0];
            a.async = 1;
            a.src = g;
            m.parentNode.insertBefore(a, m)
        })(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');

        ga('create', 'UA-44426473-2', 'hmelius.com');
        ga('send', 'pageview');
    </script>


    <header class="navbar navbar-inverse navbar-fixed-top" role="banner">
        <a id="leftmenu-trigger" class="pull-left" data-toggle="tooltip" data-placement="bottom" title="Toggle Left Sidebar"></a>
        <!--<a id="rightmenu-trigger" class="pull-right" data-toggle="tooltip" data-placement="bottom" title="Toggle Right Sidebar"></a>-->

        <div class="navbar-header pull-left">
            <a class="navbar-brand" href="<?php echo $site_url; ?>">Footlabs</a>
        </div>

        <ul class="nav navbar-nav pull-right toolbar">
            <?php
            $user_data = $this->user_model->get_sql_select_data('user_profile', array('p_u_id' => $this->session->userdata('u_id')), NULL, '1');
            ?>

            <li class="dropdown">
                <a href="#" class="dropdown-toggle username" data-toggle="dropdown">
                    <span class="hidden-xs"><?php echo $this->session->userdata('u_username'); ?> <i class="icon-caret-down icon-scale"></i>
                    </span>
                    <img src="<?php echo $base_url . 'uploads/profile/' . $user_data[0]->p_image ?>"  />
                </a>
                <ul class="dropdown-menu userinfo arrow">
                    <li class="username">
                        <a href="#">
                            <div class="pull-left"><img class="userimg" src="<?php echo $base_url . 'uploads/profile/' . $user_data[0]->p_image ?>" /></div>
                            <div class="pull-right"><h5><?php echo $user_data[0]->p_fname . " " . $user_data[0]->p_lname ?> </h5>
                                <small>Logged in as <br><span><?php echo $this->session->userdata('u_email') ?></span></small>
                            </div>
                        </a>
                    </li>
                    <li class="userlinks">
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo $site_url . 'profile_edit' ?>">Edit Profile <i class="pull-right icon-pencil"></i></a></li>

                            <li class="divider"></li>
                            <li><a href="<?php echo site_url() . "user/logout" ?>" class="text-right">Sign Out</a></li>
                        </ul>
                    </li>
                </ul>
            </li>
            <li class="dropdown">
             <?php
                $joins = array(array('table' => 'query',
                                     'condition' => 'query_response.r_query_id=query.query_id',
                                     'jointype' => 'inner'),
                              array('table' => 'order',
                                    'condition' => 'query.q_order_id=order.order_id',
                                    'jointype' => 'inner'),
                                 );
                $where=array('query.q_worker_id'=>$this->session->userdata('u_id'),'r_status'=>'1');
                $column = array('q_query','query_id','order_title','count(response_id) as count');
                $reply_data= $this->user_model->get_joins('query_response',$where, $joins,$column, NULL,array('query_id'), 'response_id  DESC');
               
                           
             ?>
                <a href="#" class="hasnotifications dropdown-toggle" data-toggle='dropdown'><i class="icon-envelope"></i><span class="badge"><?php if(count($reply_data)!='0')echo count($reply_data); ?></span></a>
                <ul class="dropdown-menu messeges arrow">
                    <li>
                        <span>You have <?php echo count($reply_data); ?> new message(s)</span>
                        <span></span>
                     </li>
                     <?php foreach ($reply_data as $reply_data) {
                           $href=site_url().'order/query_alert/'.base64_encode($reply_data->query_id);
                           $words = explode(" ",$reply_data->q_query);
                           $responce=implode(" ",array_splice($words,0,15));
                       ?>
                         <li>
                            <a href="<?php echo $href; ?>" class="notification-user active">
                                <span class="time"><?php echo $reply_data->count; ?> Query Reply</span>
                               <div>
                                   <span class="name"><?php echo $reply_data->order_title; ?></span>
                                   <span class="msg"><?php echo $responce.'....'; ?></span>
                               </div>
                            </a>
                        </li>
                    <?}?>
                     
                </ul>

            </li>
             <?php 
                     $i=0;
                     foreach ($order_count as $count) {
                         if($count->order_alert==1)
                          $i++;
                     }?>
            <li class="dropdown">
                <a href="#" class="hasnotifications dropdown-toggle" data-toggle='dropdown'><i class="icon-bell-alt"></i><span class="badge"><?php if($i!='0')echo $i; ?></span></a>
                <ul class="dropdown-menu notifications arrow">
                    <li>
                        <span>You have <?php echo $i; ?> new notification Assined New order</span>
                        <span></span>
                    </li>

                   <?php foreach ($order_count as $order_count) {
                       
                       if($order_count->order_process_status!=2){
                       $href=site_url().'order/details/'.base64_encode($order_count->order_id);
                       ?>
                        <li>
                            <a href="<?php echo $href; ?>" class="notification-user active">
                                <span class="time">
                                    <?php if($order_count->order_alert==1)echo 'New Order'; ?> 
                                </span>
                                <i class="icon-plus-sign "></i>
                                <span class="msg">
                                  <?php echo $order_count->order_title ; ?>
                                </span>
                            </a>
                        </li>
                    <? } 
                   }?>
                </ul>

            </li>


        </ul>
    </header>
    <div id="page-container">
        <!-- BEGIN SIDEBAR -->
        <nav id="page-leftbar" role="navigation">
            <!-- BEGIN SIDEBAR MENU -->
            <ul class="acc-menu" id="sidebar">
                <li id="search">
                    <a href="javascript:;"><i class="icon-search opacity-control"></i></a>
                    <form />
                    <input type="text" class="search-query" placeholder="Search..." />
                    <button type="submit"><i class="icon-search"></i></button>
                    </form>
                </li>
                <li class="divider"></li>
                <li><a href="<?php echo $site_url; ?>"><i class="icon-home"></i> <span>Dashboard</span></a></li>
                <li>
                    <a href="javascript:;"><i class="icon-reorder"></i> <span>Orders</span> 
                    </a>
                    <ul class="acc-menu">
                        <li><a href="<?php echo $site_url . 'index'; ?>"><span>Orders</span></a>

                    </ul>
                </li>

                <li> 
                    <a href="javascript:;"><i class="icon-group"></i> <span>Status</span></a>
                    <ul class="acc-menu">
                        <li><a href="<?php echo site_url() . 'home/status'; ?>"><span>Status</span></a></li>
<!--                        <li><a href="<?php echo site_url() . 'home/query'; ?>"><span>Query</span></a></li>-->


                    </ul>
                </li>
            </ul>
            <!-- END SIDEBAR MENU -->
        </nav>




