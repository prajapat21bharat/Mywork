<?php echo $this->load->view('template/header_admin');
        $base_url=base_url();
        ?>
<?php echo $content_for_layout; ?> 
</body>
</html>