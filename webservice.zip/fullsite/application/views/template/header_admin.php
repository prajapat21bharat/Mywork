<!DOCTYPE html>
<html lang="en">
    <head>
        <?php $base_url = base_url(); ?>
        <meta charset="utf-8" />
        <title>Webservice</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta name="description" content="Webservice" />
        <meta name="author" content="The Red Team" />

        <link href="<?php echo $base_url ?>assets/css/styles.min.css" rel="stylesheet" type='text/css' media="all" />
        <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600' rel='stylesheet' type='text/css' />


        <link href='<?php echo $base_url ?>assets/demo/variations/default.css' rel='stylesheet' type='text/css' media='all' id='styleswitcher' /> 
        <link href='<?php echo $base_url ?>assets/demo/variations/default.css' rel='stylesheet' type='text/css' media='all' id='headerswitcher' /> 
        <link rel='stylesheet' type='text/css' href='<?php echo $base_url ?>assets/plugins/codeprettifier/prettify.css' /> 
        <link rel='stylesheet' type='text/css' href='<?php echo $base_url ?>assets/plugins/form-toggle/toggles.css' /> 
        <link rel='stylesheet' type='text/css' href='<?php echo $base_url ?>assets/plugins/form-select2/select2.css' /> 
        <link rel='stylesheet' type='text/css' href='<?php echo $base_url ?>assets/plugins/form-multiselect/css/multi-select.css' /> 
        <link rel='stylesheet' type='text/css' href='<?php echo $base_url ?>assets/plugins/jqueryui-timepicker/jquery.ui.timepicker.css' /> 
        <link rel='stylesheet' type='text/css' href='<?php echo $base_url ?>assets/plugins/form-daterangepicker/daterangepicker-bs3.css' /> 
        <link rel='stylesheet' type='text/css' href='<?php echo $base_url ?>assets/js/jqueryui.css' /> 
        <link rel='stylesheet' type='text/css' href='<?php echo $base_url ?>assets/plugins/codeprettifier/prettify.css' /> 
        <link rel='stylesheet' type='text/css' href='<?php echo $base_url ?>assets/plugins/form-toggle/toggles.css' /> 
        <link rel='stylesheet' type='text/css' href='<?php echo $base_url ?>assets/plugins/datatables/dataTables.css' /> 
        <link rel='stylesheet' type='text/css' href='<?php echo $base_url ?>assets/plugins/codeprettifier/prettify.css' /> 
        <link rel='stylesheet' type='text/css' href='<?php echo $base_url ?>assets/plugins/form-toggle/toggles.css' /> 

        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />


    </head>

    <header class="navbar navbar-inverse navbar-fixed-top" role="banner">
        <a id="leftmenu-trigger" class="pull-left" data-toggle="tooltip" data-placement="bottom" title="Toggle Left Sidebar"></a>
        <!--        <a id="rightmenu-trigger" class="pull-right" data-toggle="tooltip" data-placement="bottom" title="Toggle Right Sidebar"></a>-->

        <div class="navbar-header pull-left">
            <a class="navbar-brand" href="<?php echo site_url(); ?>">Webservice</a>
        </div>

        <ul class="nav navbar-nav pull-right toolbar">
            <?php
            $user_data = $this->user_model->get_sql_select_data('user_profile', array('p_u_id' => $this->session->userdata('u_id')), NULL, '1');
            ?>

            <li class="dropdown">
                <a href="#" class="dropdown-toggle username" data-toggle="dropdown">
                    <span class="hidden-xs"><?php echo $this->session->userdata('u_username'); ?> <i class="icon-caret-down icon-scale"></i>
                    </span>
                    <img src="<?php echo $base_url . 'uploads/' . $user_data[0]->p_image ?>"  />
                </a>
                <ul class="dropdown-menu userinfo arrow">
                    <li class="username">
                        <a href="#">
                            <div class="pull-left"><img class="userimg" src="<?php echo $base_url . 'uploads/profile/' . $user_data[0]->p_image ?>" /></div>
                            <div class="pull-right"><h5><?php echo $user_data[0]->p_fname . " " . $user_data[0]->p_lname ?> </h5>
                                <small>Logged in as <br><span><?php echo $this->session->userdata('u_email') ?></span></small>
                            </div>
                        </a>
                    </li>
                    <li class="userlinks">
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo site_url() . 'category/profile_edit' ?>">Edit Profile <i class="pull-right icon-pencil"></i></a></li>
                            <li class="divider"></li>
                            <li><a href="<?php echo site_url() . "user/logout" ?>" class="text-right">Sign Out</a></li>
                        </ul>
                    </li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#" class="hasnotifications dropdown-toggle" data-toggle='dropdown'><i class="icon-envelope"></i><span class="badge"></span></a>

            </li>



        </ul>
    </header>
    <div id="page-container">
        <!-- BEGIN SIDEBAR -->
        <nav id="page-leftbar" role="navigation">
            <!-- BEGIN SIDEBAR MENU -->
            <ul class="acc-menu" id="sidebar">
                <li id="search">
                    <a href="javascript:;"><i class="icon-search opacity-control"></i></a>
                    <form />
                    <input type="text" class="search-query" placeholder="Search..." />
                    <button type="submit"><i class="icon-search"></i></button>
                    </form>
                </li>
                <li class="divider"></li>
                <li><a href="<?php echo site_url(); ?>"><i class="icon-home"></i> <span>Dashboard</span></a></li>
                <li>
                    <a href="javascript:;"><i class="icon-reorder"></i> <span>Category</span> 
                    </a>
                    <ul class="acc-menu">
                        <li><a href="<?php echo site_url() . 'category/index'; ?>"><span>Category</span></a>
                        <li><a href="<?php echo site_url() . 'category/add'; ?>"><span>Add Category</span></a></li>                        
                    </ul>
                </li>
<!--                <li>
                    <a href="javascript:;"><i class="icon-reorder"></i> <span>Sub Category</span> 
                    </a>
                    <ul class="acc-menu">
                        <li><a href="<?php echo site_url() . 'subcate/index'; ?>"><span>Sub Category </span></a>
                        <li><a href="<?php echo site_url() . 'subcate/add'; ?>"><span>Add Sub Category</span></a></li>                        
                    </ul>
                </li>-->
                <li>
                    <a href="javascript:;"><i class="icon-reorder"></i> <span>Category Items</span> 
                    </a>
                    <ul class="acc-menu">
                        <li><a href="<?php echo site_url() . 'items/index'; ?>"><span>Category Items</span></a>
                        <li><a href="<?php echo site_url() . 'items/add'; ?>"><span>Add Category Items</span></a></li>                        
                    </ul>
                </li>
                
                <li>
                    <a href="javascript:;"><i class="icon-reorder"></i> <span>Advertise Category</span> 
                    </a>
                    <ul class="acc-menu">
                        <li><a href="<?php echo site_url() . 'advertise/index'; ?>"><span>Advertise Category</span></a>
                        <li><a href="<?php echo site_url() . 'advertise/add'; ?>"><span>Add Advertise Category</span></a></li>                        
                    </ul>
                </li>
                <li>
                    <a href="javascript:;"><i class="icon-reorder"></i> <span>Advertise Category Items</span> 
                    </a>
                    <ul class="acc-menu">
                        <li><a href="<?php echo site_url() . 'advertise_items/index'; ?>"><span>Advertise Category Items</span></a>
                        <li><a href="<?php echo site_url() . 'advertise_items/add'; ?>"><span>Add Advertise Category Items</span></a></li>                        
                    </ul>
                </li>
                <li>
                    <a href="javascript:;"><i class="icon-reorder"></i> <span>Events</span> 
                    </a>
                    <ul class="acc-menu">
                        <li><a href="<?php echo site_url() . 'events/index'; ?>"><span>Events</span></a>
                        <li><a href="<?php echo site_url() . 'events/add'; ?>"><span>Add Events</span></a></li>                        
                    </ul>
                </li>

            </ul>
            <!-- END SIDEBAR MENU -->
        </nav>




