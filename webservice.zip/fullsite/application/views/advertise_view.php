<?php $site_url = site_url() . 'advertise/'; ?>
<div id="page-content">
    <div id='wrap'>
        <div id="page-heading">
            <ol class="breadcrumb">
                <li><a href="<?php echo $site_url ?>">Dashboad</a></li>
                <li>Advertise</li>
                <li class="active">Advertise</li>
            </ol>
            <h1>Advertise</h1>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-sky">
                        <div class="panel-heading">
                            <h4>Advertise Data</h4>
                            <div class="options">   
                                <a href="javascript:;" class="panel-collapse"><i class="icon-chevron-down"></i></a>
                                <a href="<?php echo $site_url . 'add' ?>">Add Advertise</a>
                            </div>
                        </div>
                        <div class="panel-body table-responsive collapse in">
                            <table cellpadding="0" cellspacing="0" border="0" class="table table-striped datatables" id="example">
                                <thead>
                                    <tr>
                                        <th class="hidden">S.No</th>
                                        <th>Advertise Title</th>
                                        <th>Advertise Description</th>
                                        <th>image</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody id="list-data">

                                    <?php
                                    foreach ($advertise as $advertise) {
                                        ?>

                                        <tr id="<?php echo 'delete_' . $advertise->a_id; ?>">
                                            <td class="hidden"><?php echo $advertise->a_id ?></td>
                                            <td><?php echo $advertise->name ?></td>
                                            <td><?php echo $advertise->description ?></td>
                                            <td><img src="<?php echo $advertise->image ?>" height="50px" width="50px"></td>

                                            <td>
                                                <span id='order_<?php echo $advertise->a_id; ?>'>
                                                    <?php
                                                    if ($advertise->status == 0) {
                                                        $class = 'icon-remove ';
                                                        $status = "Inactive";
                                                        $onclick = "active($advertise->a_id,1)";
                                                    } else {
                                                        $class = ' icon-ok';
                                                        $status = "Active";
                                                        $onclick = "active($advertise->a_id,0)";
                                                    }

                                                    echo "<span onclick='$onclick' id='active_$advertise->a_id' class='btn'><i class='$class'></i></sapn>";
                                                     ?>
                                                </span>
                                               <span class='btn' onclick='ad_delete(<?php echo $advertise->a_id ?>)'>
                                                    <i class="icon-trash"></i>
                                                </span>
                                                <a href="<?php echo $site_url.'edit/'.$advertise->a_id ?>">
                                                  <span class='btn'>
                                                    <i class="icon-pencil"></i>
                                                </span>	
                                                </a>
                                            </td>

                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>

        </div> <!-- container -->
    </div> <!--wrap -->
</div> <!-- page-content -->

<!-- Footer Contained -->
<?php echo $this->load->view('template/footer_admin'); ?> 

<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/jquery-1.10.2.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/jqueryui-1.10.3.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/bootstrap.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/enquire.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/jquery.cookie.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/jquery.touchSwipe.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/jquery.nicescroll.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/codeprettifier/prettify.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/easypiechart/jquery.easypiechart.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/sparklines/jquery.sparklines.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/form-toggle/toggle.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/datatables/jquery.dataTables.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/datatables/dataTables.bootstrap.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/demo/demo-datatables.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/placeholdr.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/application.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/demo/demo.js'></script> 
<script>
function ad_delete(id) {
        if (confirm("Delete This Advertise")) {
            var form_data = {a_id: id};
            $.ajax({
                url: '<?php echo $site_url . 'delete'; ?>',
                data: form_data,
                type: 'post',
                datatype: 'json',
                success: function(data) {
                    $("#delete_" + id).remove();
                }
            });
        }
    }
    /*----its function use for Delete order-------*/
function active(id, val) {
    var form_data = {a_id: id,
        val: val};
    $.ajax({
        url: '<?php echo $site_url . 'active'; ?>',
        data: form_data,
        type: 'post',
        success: function(data) {         
                if (val=='1')
                    $("#active_" + id).replaceWith("<span onclick='active("+ id +",0)' id='active_" + id + "' class='btn'><i class='icon-ok'></i></sapn>");
                else
                    $("#active_" + id).replaceWith("<span onclick='active("+ id +",1)' id='active_" + id + "' class='btn'><i class='icon-remove'></i></sapn>");
        }
    });

}

</script>
</body></html>