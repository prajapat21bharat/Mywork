 
<div id="page-content">
    <div id='wrap'>

        <div id="page-heading">
            <ul class="breadcrumb">
                <li><a href="<?php echo site_url(); ?>">Dashboad</a></li>
                <li>Worker</li>
                <li class="active">Add Worker Form</li>
            </ul>

            <h1>Worker</h1>
            <div class="options">
                <div class="btn-toolbar">
                    <div class="btn-group hidden-xs">
                        <a href='#' class="btn btn-muted dropdown-toggle" data-toggle='dropdown'><i class="icon-cloud-download"></i><span class="hidden-sm"> Export as  </span><span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="#">Text File (*.txt)</a></li>
                            <li><a href="#">Excel File (*.xlsx)</a></li>
                            <li><a href="#">PDF File (*.pdf)</a></li>
                        </ul>
                    </div>
                    <a href="#" class="btn btn-muted"><i class="icon-cog"></i></a>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="panel panel-midnightblue">
                        <div class="panel-heading"><h4>Add Worker Form </h4></div>
                        <div class="panel-body">
                           
                             <?php
    $attr = array('class' => 'form-horizontal row-border', 'id' => 'validate-form','data-validate'=>'parsley');
    echo form_open_multipart("user/registration", $attr);
    ?>
                            <div class="form-group">
                                <label class="col-sm-3 control-label">Required Field</label>
                                <div class="col-sm-6">
                                    <input type="text" placeholder="Required Field" required="required" class="form-control" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label">Min-length</label>
                                <div class="col-sm-6">
                                    <input type="text" data-minlength="6" placeholder="At least 6 characters" required="required" class="form-control" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label">Max-legnth</label>
                                <div class="col-sm-6">
                                    <input type="text" data-maxlength="6" placeholder="At most 6 characters" required="required" class="form-control" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label">Range length</label>
                                <div class="col-sm-6">
                                    <input type="text" data-rangelength="[5,10]" placeholder="Between 5 and 10 characters" required="required" class="form-control" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label">RegExp</label>
                                <div class="col-sm-6">
                                    <input type="text" data-regexp="#[A-Fa-f0-9]{6}" placeholder="Hexadecimal Color Code" required="required" class="form-control" />
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-3 control-label">Email</label>
                                <div class="col-sm-6">
                                    <input type="text" data-type="email" placeholder="Email address" required="required" class="form-control" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label">URL</label>
                                <div class="col-sm-6">
                                    <input type="text" data-type="url" placeholder="URL address" required="required" class="form-control" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label">Digits</label>
                                <div class="col-sm-6">
                                    <input type="text" data-type="digits" placeholder="Digits only" required="required" class="form-control" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label">Alphanum</label>
                                <div class="col-sm-6">
                                    <input type="text" data-type="alphanum" placeholder="Alphanumeric only" required="required" class="form-control" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label">ISO Date</label>
                                <div class="col-sm-6">
                                    <input type="text" data-type="dateIso" placeholder="YYYY-MM-DD" required="required" class="form-control" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label">Phone</label>
                                <div class="col-sm-6">
                                    <input type="text" data-type="phone" placeholder="(XXX) XXXX XXX" required="required" class="form-control" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label">Password</label>
                                <div class="col-sm-6">
                                    <input type="text" id="ps1" required="required" class="form-control" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label">Repeat Password</label>
                                <div class="col-sm-6">
                                    <input type="text" data-equalto="#ps1" required="required" class="form-control" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label">Checkbox</label>
                                <div class="col-sm-6">
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" value="" required="required" name="terms" />
                                            Accept Terms &amp; Conditions
                                        </label>
                                    </div>
                                </div>
                            </div>
                            </form>
                        </div>
                        <div class="panel-footer">
                            <div class="row">
                                <div class="col-sm-6 col-sm-offset-3">
                                    <div class="btn-toolbar">
                                        <button class="btn-primary btn" onclick="javascript:$('#validate-form').parsley('validate');">Submit</button>
                                        <button class="btn-default btn">Cancel</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </div> <!-- container -->
    </div> <!--wrap -->
</div> <!-- page-content -->







<div class="tab-pane fade" id="create">
    <?php
    $attr = array('class' => 'form-horizontal', 'id' => 'register');
    echo form_open_multipart("user/registration", $attr);
    ?>

    <fieldset> 
        <div id="legend">
            <legend class="">Registration</legend>
        </div> 

        <div class="control-group">
            <label  class="control-label">Your First Name:</label>
            <div class="controls">
                <input type="text" id="p_fname" name="user_profile[p_fname]" value="<?php echo set_value("user_profile[p_fname]"); ?>" />
                <?php echo form_error("user_profile[p_fname]"); ?>
            </div>
        </div>

        <div class="control-group">
            <label class="control-label">Your Last Name:</label>
            <div class="controls">
                <input type="text" id="p_fname" name="user_profile[p_lname]" value="<?php echo set_value("user_profile[p_lname]"); ?>" />
                <?php echo form_error("user_profile[p_lname]"); ?>
            </div>
        </div>

        <!-- 
             <label class="control-label">Your DOB:</label>
            <div class="controls"> <input type="text" id="p_dob" name="user_profile[p_dob]" value="<?php echo set_value("user_profile[p_dob]"); ?>" />
        <?php echo form_error("user_profile[p_dob]"); ?>
        </div>
        -->
        <div class="control-group">
            <label class="control-label">Your Gender:</label>
            <div class="controls">
                <input type="radio" name="user_profile[p_gender]" <?php if (set_value("user_profile[p_gender]") == 'male') echo "checked='checked' "; ?>  value="male">Male
                <input type="radio" name="user_profile[p_gender]" <?php if (set_value("user_profile[p_gender]") == 'female') echo "checked='checked'"; ?> value="female">Female
                <?php echo form_error("user_profile[p_gender]"); ?>
            </div>
        </div>


        <div class="control-group">
            <label class="control-label">UserName:</label>
            <div class="controls">
                <input type="text" id="u_username" name="users[u_username]" value="<?php echo set_value("users[u_username]"); ?>" />
                <?php echo form_error("users[u_username]"); ?>
            </div>
        </div>
        <div class="control-group">
            <label class="control-label">Your Email:</label>
            <div class="controls">
                <input type="text" id="u_email" name="users[u_email]" value="<?php echo set_value("users[u_email]"); ?>" />
                <?php echo form_error("users[u_email]"); ?>
            </div>
        </div>


        <div class="control-group">
            <label class="control-label">Your Image:</label>
            <div class="controls">
                <input type="file" id="userfile" name="userfile" value="" />
                <?php if (!empty($error)) echo $error ?>
            </div>
        </div>


        <div class="control-group">
            <label class="control-label">Password:</label>
            <div class="controls">
                <input type="password" id="password" name="password" value="<?php echo set_value("password"); ?>" />
                <?php echo form_error("password"); ?>
            </div>
        </div>
        <div class="control-group">
            <label class="control-label">Confirm Password:</label>
            <div class="controls">
                <input type="password" id="u_password" name="users[u_password]" value="<?php echo set_value("users[u_password]"); ?>" />
                <?php echo form_error("users[u_password]"); ?>
            </div>
        </div>

        <div class="controls">
            <input type="submit" class="btn btn-primary" value="Submit" />
        </div>

        <?php echo form_close(); ?>

</div>


