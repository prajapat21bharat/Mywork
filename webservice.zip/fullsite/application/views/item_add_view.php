<?php $site_url = site_url() . "items/" ?>
<div id="page-content">
    <div id='wrap'>

        <div id="page-heading">
            <ul class="breadcrumb">
                <li><a href="<?php echo $site_url; ?>">Dashboad</a></li>
                <li>Items</li>
                <li class="active">Add Items Form</li>
            </ul>

            <h1>Add Items</h1>

        </div>



        <div class="container">
            <?php if (isset($success)) { ?>
                <div class="alert alert-dismissable alert-success">
                    <strong>Well done!</strong> Data Successfully Inserted.
                    <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                </div>
            <?php } ?>
            <div class="row">
                <div class="col-xs-12">
                    <div class="panel panel-sky">
                        <div class="panel-heading"><h4>Add Items </h4></div>
                        <div class="panel-body">
                            <?php
                            $attr = array('class' => 'form-horizontal row-bitems', 'id' => 'validate-form', 'data-validate' => 'parsley');
                            echo form_open_multipart('', $attr);
                            ?>


                            <div class="form-group">
                                <label class="col-sm-3 control-label">Select Category</label>
                                <div class="col-sm-6">
                                    <?php
                                    if (set_value("items[c_id]"))
                                        $name = set_value("items[c_id]");
                                    else
                                        $name = @$items->c_id;
                                    ?> 
                                    <select required="required" id="cate"  class="form-control parsley-validated" name="items[c_id]">
                                        <option value=''>--Select Category--</option>
                                        <?php
                                        foreach ($category as $category) {
                                            if ($category->c_id == $name)
                                                echo "<option selected value='$category->c_id'>$category->name</option>";
                                            else
                                                echo "<option value='$category->c_id'>$category->name</option>";
                                        }
                                        ?>
                                    </select>
                                    <?php echo form_error("items[c_id]"); ?>

                                </div>
                            </div>
                         <?php /*   <div class="form-group">
                                <label class="col-sm-3 control-label">Select Sub Category</label>
                                <div class="col-sm-6">
                                    <?php
                                    if (set_value("items[sc_id]"))
                                        $name = set_value("items[sc_id]");
                                    else
                                        $name = @$items->sc_id;
                                    ?> 
                                    <select required="required" class="form-control parsley-validated" id="scate" name="items[sc_id]">
                                        <option value=''>--Select Sub Category--</option>
                                        <?php
                                        if(@$subcate){
                                        foreach (@$subcate as $subcate) {
                                            if ($subcate->sc_id == $name)
                                                echo "<option selected value='$subcate->sc_id'>$subcate->name</option>";
                                            else
                                                echo "<option value='$subcate->sc_id'>$subcate->name</option>";
                                        }
                                        }
                                        ?>
                                    </select>
                                    <?php echo form_error("items[sc_id]"); ?>

                                </div>
                            </div> */ ?>


                            <div class="form-group">
                                <label class="col-sm-3 control-label">Items Title</label>
                                <div class="col-sm-6">
                                    <?php
                                    if (set_value("items[name]"))
                                        $name = set_value("items[name]");
                                    else
                                        $name = @$items->name;
                                    ?>                                      
                                    <input type="text"  name="items[name]" value="<?php echo $name ?>" placeholder="Items name" required="required" class="form-control" />
                                    <?php echo form_error("items[name]"); ?>

                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label">Address</label>
                                <div class="col-sm-6">
                                    <?php
                                    if (set_value("items[address]"))
                                        $name = set_value("items[address]");
                                    else
                                        $name = @$items->address;
                                    ?>                                      
                                    <input type="text"  name="items[address]" value="<?php echo $name ?>" placeholder="Items address" required="required" class="form-control" />
                                    <?php echo form_error("items[address]"); ?>

                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-3 control-label">Phone No.</label>
                                <div class="col-sm-6">
                                    <?php
                                    if (set_value("items[phone]"))
                                        $name = set_value("items[phone]");
                                    else
                                        $name = @$items->phone;
                                    ?>                                      
                                    <input type="text"  name="items[phone]" value="<?php echo $name ?>" placeholder="Items phone" required="required" class="form-control" />
                                    <?php echo form_error("items[phone]"); ?>

                                </div>
                            </div> 

                            <div class="form-group">
                                <label class="col-sm-3 control-label">Items Description</label>
                                <div class="col-sm-6">
                                    <?php
                                    if (set_value("items[description]"))
                                        $name = set_value("items[description]");
                                    else
                                        $name = @$items->description;
                                    ?>                                      
                                    <textarea name="items[description]"  required="required" class="form-control"><?php echo $name ?></textarea>
                                    <?php echo form_error("items[description]"); ?>

                                </div>
                            </div>


                            <div class="form-group">
                                <label class="col-sm-3 control-label">Items Image</label>
                                <div class="col-sm-6">
                                    <?php
                                    if (@$items)
                                        echo '<img src="' . @$items->image . '" height="100px" width="100px"><br><br>';
                                    ?> 
                                    <input type="file"  name="userfile" class="form-control" />
                                    <?php echo @$error; ?>
                                </div>
                            </div>
                            
                            
                            <div class="form-group">
                                <label class="col-sm-3 control-label">Front Page Banner</label>

                                <?php
                                if (set_value("items[front_banner]"))
                                    $status = set_value("items[front_banner]");
                                else
                                    $status = @$items->front_banner;
                                ?>                                 

                                <div class="col-sm-6">
                                    <label class="radio-inline">
                                        <input type="radio" name="items[front_banner]" value="1" <?php echo ($status == '1') ? "checked" : ''; ?>>
                                        Active
                                    </label>
                                    <label class="radio-inline">
                                        <input type="radio" name="items[front_banner]" value="0" <?php echo ($status != '1') ? "checked" : ''; ?>>
                                        InActive
                                    </label>
                                    <?php echo form_error("items[front_banner]");
                                         echo @$front;
                                    ?> 
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-3 control-label">Status</label>

                                <?php
                                if (set_value("items[status]"))
                                    $status = set_value("items[status]");
                                else
                                    $status = @$items->status;
                                ?>                                 

                                <div class="col-sm-6">
                                    <label class="radio-inline">
                                        <input type="radio" name="items[status]" value="1" <?php echo ($status == '1') ? "checked" : ''; ?>>
                                        Active
                                    </label>
                                    <label class="radio-inline">
                                        <input type="radio" name="items[status]" value="0" <?php echo ($status == '0') ? "checked" : ''; ?>>
                                        InActive
                                    </label>
                                    <?php echo form_error("items[status]"); ?> 
                                </div>
                            </div>



                            <div class="panel-footer">
                                <div class="row">
                                    <div class="col-sm-6 col-sm-offset-3">
                                        <div class="btn-toolbar">
                                            <input class="btn-success btn" type="submit" value="Submit" onclick="javascript:$('#validate-form').parsley('validate');" />
                                            <button type="reset" class="btn-default btn">Reset</button>
                                            <a class="btn-default btn" href="<?php echo $site_url . 'index' ?>">Cancel</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div> <!-- container -->
    </div> <!--wrap -->
</div> <!-- page-content -->

<!-- Footer Contained -->
<?php echo $this->load->view('template/footer_admin'); ?> 

<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/jquery-1.10.2.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/jqueryui-1.10.3.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/bootstrap.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/enquire.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/jquery.cookie.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/jquery.touchSwipe.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/jquery.nicescroll.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/codeprettifier/prettify.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/easypiechart/jquery.easypiechart.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/sparklines/jquery.sparklines.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/form-toggle/toggle.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/form-parsley/parsley.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/demo/demo-formvalidation.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/form-multiselect/js/jquery.multi-select.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/quicksearch/jquery.quicksearch.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/form-typeahead/typeahead.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/form-select2/select2.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/form-autosize/jquery.autosize-min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/form-ckeditor/ckeditor.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/form-colorpicker/js/bootstrap-colorpicker.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/jqueryui-timepicker/jquery.ui.timepicker.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/form-daterangepicker/daterangepicker.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/plugins/form-daterangepicker/moment.min.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/demo/demo-formcomponents.js'></script>
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/placeholdr.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/js/application.js'></script> 
<script type='text/javascript' src='<?php echo base_url(); ?>assets/demo/demo.js'></script> 
<!-- Add fancyBox main JS and CSS files -->
<script type="text/javascript" src='<?php echo base_url(); ?>assets/js/jquery.fancybox.js'></script>
<link rel="stylesheet" type="text/css" href='<?php echo base_url(); ?>assets/css/jquery.fancybox.css' media="screen" />

<script>
function subcate(){
    var form_data = {c_id: $('#cate').val()};
    $.ajax({
        url: '<?php echo $site_url . 'cate'; ?>',
        data: form_data,
        type: 'post',
        success: function(data) {
             
            $("#scate").html(data);
        }
    });

}
</script>



