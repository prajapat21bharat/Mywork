<div id="page-content">
    <div id='wrap'>
        Welcome
    </div>
</div>