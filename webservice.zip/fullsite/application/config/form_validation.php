<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');
/*
  | -------------------------------------------------------------------
  | USER AGENT TYPES
  | -------------------------------------------------------------------
  | This file contains four arrays of user agent data.  It is used by the
  | User Agent Class to help identify browser, platform, robot, and
  | mobile device data.  The array keys are used to identify the device
  | and the array values are used to set the actual name of the item.
  |
 */

$config = array(
    'edit_profile' => array(
        array(
            'field' => 'user_profile[p_fname]',
            'label' => 'First Name',
            'rules' => 'trim|required|xss_clean'
        ),
        array(
            'field' => 'user_profile[p_lname]',
            'label' => 'Last Name',
            'rules' => 'trim|required|xss_clean'
        ),
        array(
            'field' => 'user_profile[p_gender]',
            'label' => 'Gender',
            'rules' => 'trim|required'
        ),
    ),
    'login' => array(
        /* array(
          'field' => 'email',
          'label' => 'Email',
          'rules' => 'trim|valid_email|required|min_length[4]|xss_clean|'
          ), */
        array(
            'field' => 'pass',
            'label' => 'Password',
            'rules' => 'trim|required|min_length[4]|xss_clean|'
        ),
    ),
    'category' => array(
        array(
            'field' => 'category[name]',
            'label' => 'Category Title',
            'rules' => 'trim|required|xss_clean'
        ),
    ),
    
    'subcate' => array(
        array(
            'field' => 'subcate[name]',
            'label' => 'Item Title',
            'rules' => 'trim|required|xss_clean'
        ),
        array(
            'field' => 'subcate[c_id]',
            'label' => 'Item Category',
            'rules' => 'trim|required|xss_clean'
        ),
    ),
    
    'items' => array(
        array(
            'field' => 'items[name]',
            'label' => 'Item Title',
            'rules' => 'trim|required|xss_clean'
        ),
        array(
            'field' => 'items[c_id]',
            'label' => 'Item Category',
            'rules' => 'trim|required|xss_clean'
        ),
//        array(
//            'field' => 'items[sc_id]',
//            'label' => 'Item Sub Category',
//            'rules' => 'trim|required|xss_clean'
//        ),
        array(
            'field' => 'items[address]',
            'label' => 'Item Address',
            'rules' => 'trim|required|xss_clean'
        ),
        array(
            'field' => 'items[phone]',
            'label' => 'Phone No.',
            'rules' => 'trim|required|xss_clean'
        ),
    ),
    'events' => array(
        array(
            'field' => 'events[name]',
            'label' => 'events Title',
            'rules' => 'trim|required|xss_clean'
            ),
       array(
            'field' => 'events[address]',
            'label' => 'events Address',
            'rules' => 'trim|required|xss_clean'
            ),
        array(
            'field' => 'events[phone]',
            'label' => 'Phone No.',
            'rules' => 'trim|required|xss_clean'
            ),
    ),
    'advertise' => array(
        array(
            'field' => 'advertise[name]',
            'label' => 'Advertise Title',
            'rules' => 'trim|required|xss_clean'
        ),
        array(
            'field' => 'advertise[description]',
            'label' => 'Advertise Description',
            'rules' => 'trim|required|xss_clean'
        ),
    ),
    'advertise_items' => array(
        array(
            'field' => 'advertise_items[name]',
            'label' => 'Advertise Item Title',
            'rules' => 'trim|required|xss_clean'
        ),
        array(
            'field' => 'advertise_items[a_id]',
            'label' => 'Advertise Item Category',
            'rules' => 'trim|required|xss_clean'
        ),
        array(
            'field' => 'advertise_items[description]',
            'label' => 'Advertise Description',
            'rules' => 'trim|required|xss_clean'
        ),
    ),
);


