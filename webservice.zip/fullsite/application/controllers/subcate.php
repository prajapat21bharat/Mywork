<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Subcate extends MY_Controller {

    public function __construct() {
        parent::__construct();
        if (($this->session->userdata('u_type') != "1"))
            redirect(site_url() . 'user/');
    }

    public function index(){
        $join=array(array('table'=>'category','condition'=>'subcate.c_id=category.c_id','jointype'=>'inner'));
        $data['subcate'] = $this->user_model->get_joins('subcate',NULL,$join,array('subcate.*','category.name as cname'));
        $this->layout->view('subcate_view',$data);
    }

    public function add(){
        
        $data['category'] = $this->user_model->get_joins('category',NUll,NULL,array('c_id','name'));
        if ($this->form_validation->run('subcate') == false) {
            $this->layout->view('subcate_add_view',$data);
        } else {      

            /* --file upload---- */
            $config['upload_path'] = './uploads/';
            $config['allowed_types'] = 'gif|jpg|jpeg|png';
            $this->load->library('upload');
            $this->upload->initialize($config);
            if (!$this->upload->do_upload()) {
                print_r($this->upload->display_errors());
                $data['error'] = 'Select Image';
                $this->layout->view('subcate_add_view', $data);
            } else {
                $uploads = $this->upload->data();

                $randomcode = time() . rand();
                $newimagename = $randomcode . $uploads['file_ext'];
                rename($uploads['full_path'], $uploads['file_path'] . $newimagename);
               
                $item = $this->input->post('subcate');
                $item['image'] = base_url() . 'uploads/' .$newimagename;
                $this->user_model->INSERTDATA('subcate', $item);
                redirect(site_url() . 'subcate');
            }
        }
    }

    function edit() {
        if (!$this->uri->segment('3'))
            redirect(site_url() . 'subcate');
         $data['category'] = $this->user_model->get_joins('category',NUll,NULL,array('c_id','name'));
       
        $where = array('sc_id' => $this->uri->segment('3'));
        $data['subcate'] = array_shift($this->user_model->get_joins('subcate', $where));
        if ($this->form_validation->run('subcate') == false) {
            $this->layout->view('subcate_add_view',$data);
        } else {
           
            $item = $this->input->post('subcate');
            $this->user_model->UPDATEDATA('subcate', $where, $item);
            
            $config['upload_path'] = './uploads/';
            $config['allowed_types'] = 'gif|jpg|jpeg|png';
            $this->load->library('upload');
            $this->upload->initialize($config);
            if ($this->upload->do_upload()) {
                $uploads = $this->upload->data();
                $randomcode = time() . rand();
                $newimagename = $randomcode . $uploads['file_ext'];
                rename($uploads['full_path'], $uploads['file_path'] . $newimagename);               
                $item['image'] = base_url() . 'uploads/' .$newimagename;
                $this->user_model->UPDATEDATA('subcate', $where, $item);
            }
            redirect(site_url() . 'subcate');           
            
        }
    }
    
     function delete() {
        if ($this->input->is_ajax_request()) {
            $this->user_model->deletedata('subcate', array('sc_id' => $this->input->post('sc_id')));
           
        }
    }
    
    function active() {
        if ($this->input->is_ajax_request()) {
            $this->user_model->UPDATEDATA('subcate', array('sc_id' => $this->input->post('sc_id')),array('status'=>$this->input->post('val')));
          
        }
    }

  

}
