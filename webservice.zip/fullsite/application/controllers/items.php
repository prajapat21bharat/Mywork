<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class items extends MY_Controller {

    public function __construct() {
        parent::__construct();
        if (($this->session->userdata('u_type') != "1"))
            redirect(site_url() . 'user/');
    }

    public function index() {
        $join = array(array('table' => 'category', 'condition' => 'items.c_id=category.c_id', 'jointype' => 'inner'),
                // array('table' => 'subcate', 'condition' => 'items.sc_id=subcate.sc_id', 'jointype' => 'inner')
        );
        $data['items'] = $this->user_model->get_joins('items', NULL, $join, array('items.*', 'category.name as cname'));
        $this->layout->view('item_view', $data);
    }

    public function add() {

        $data['category'] = $this->user_model->get_joins('category', NUll, NULL, array('c_id', 'name'));
        //$data['subcate'] = $this->user_model->get_joins('subcate',$data['category'],NULL,array('sc_id','name'));
        if ($this->form_validation->run('items') == false) {
            $this->layout->view('item_add_view', $data);
        } else {

            /* --file upload---- */
            $config['upload_path'] = './uploads/';
            $config['allowed_types'] = 'gif|jpg|jpeg|png';
            $this->load->library('upload');
            $this->upload->initialize($config);
            $item = $this->input->post('items');

            $itemfront = count($this->user_model->get_joins('items', array('status' => '1')));
            if ($itemfront >= 10 && $item['front_banner'] == '1') {
                $data['front'] = '<p>Front Page Banner Is more Then 10</p>';
                $this->layout->view('item_add_view', $data);
            } else if (!$this->upload->do_upload()) {
                print_r($this->upload->display_errors());
                $data['error'] = 'Select Image';
                $this->layout->view('item_add_view', $data);
            } else {
                $uploads = $this->upload->data();


                $randomcode = time() . rand();
                $newimagename = $randomcode . $uploads['file_ext'];
                rename($uploads['full_path'], $uploads['file_path'] . $newimagename);


                $item['image'] = base_url() . 'uploads/' . $newimagename;



                $this->user_model->INSERTDATA('items', $item);
                redirect(site_url() . 'items');
            }
        }
    }

    function edit() {
        if (!$this->uri->segment('3'))
            redirect(site_url() . 'items');
        $data['category'] = $this->user_model->get_joins('category', NUll, NULL, array('c_id', 'name'));

        $where = array('i_id' => $this->uri->segment('3'));
        $data['items'] = array_shift($this->user_model->get_joins('items', $where));
        //$data['subcate'] = $this->user_model->get_joins('subcate', array('c_id' => $data['items']->c_id), NULL, array('sc_id', 'name'));

        if ($this->form_validation->run('items') == false) {
            $this->layout->view('item_add_view', $data);
        } else {

            $item = $this->input->post('items');

            $itemfront = count($this->user_model->get_joins('items', array('status' => '1')));
            if ($itemfront >= 10 && $item['front_banner'] == '1') {
                $data['front'] = '<p>Front Page Banner Is more Then 10</p>';
                $this->layout->view('item_add_view', $data);
            } else {
                $this->user_model->UPDATEDATA('items', $where, $item);


                $config['upload_path'] = './uploads/';
                $config['allowed_types'] = 'gif|jpg|jpeg|png';
                $this->load->library('upload');
                $this->upload->initialize($config);
                if ($this->upload->do_upload()) {
                    $uploads = $this->upload->data();
                    $randomcode = time() . rand();
                    $newimagename = $randomcode . $uploads['file_ext'];
                    rename($uploads['full_path'], $uploads['file_path'] . $newimagename);
                    $item['image'] = base_url() . 'uploads/' . $newimagename;
                    $this->user_model->UPDATEDATA('items', $where, $item);
                }
                redirect(site_url() . 'items');
            }
        }
    }

    function cate() {
        if ($this->input->is_ajax_request()) {
            if ($this->input->post('c_id')) {
                $data = $this->user_model->get_joins('subcate', array('c_id' => $this->input->post('c_id')), NULL, array('sc_id', 'name'));
                $opt = "<option value=''>--Select Sub Category--</option>";
                foreach ($data as $data) {
                    $opt.= "<option value='$data->sc_id'>$data->name</option>";
                }
                echo $opt;
            }
        }
    }

    function delete() {
        if ($this->input->is_ajax_request()) {
            $this->user_model->deletedata('items', array('i_id' => $this->input->post('i_id')));
        }
    }

    function active() {
        if ($this->input->is_ajax_request()) {
            $this->user_model->UPDATEDATA('items', array('i_id' => $this->input->post('i_id')), array('status' => $this->input->post('val')));
        }
    }

}
