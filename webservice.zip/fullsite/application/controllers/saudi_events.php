<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Saudi_events extends MY_Controller {

    public function __construct() {
        parent::__construct();

        $where = array('apikey' => $this->uri->segment('3'));
        $key = $this->user_model->get_joins('apikeys', $where);
        if (!$key) {
            echo 'ApiKey Not Valid';
            die;
        }
    }

    function category() {
        $where = array('status' => '1');
        echo json_encode($this->user_model->get_joins('category', $where));
    }

    function subcate() {
        if ($this->uri->segment('4')){
            $where = array('subcate.c_id' => $this->uri->segment('4'),
                'status' => '1');
            echo json_encode($this->user_model->get_joins('subcate', $where));
        } else {
            echo 'Incorrect Url';
        }
    }

    function items() {
        if ($this->uri->segment('4')) {
            
            //----cate where condition
           // $where = array('subcate.sc_id' => $this->uri->segment('4'),
              //  'status' => '1');

            //--get category data
           // $data['subcate'] = $this->user_model->get_joins('subcate', $where);


            $where = array('items.c_id' => $this->uri->segment('4'),
                            'items.status' => '1',
                            'category.status' => '1');
            //----get category item data
            $join = array(array('table' => 'category', 'condition' => 'items.c_id=category.c_id', 'jointype' => 'inner'));
            $data['items'] = $this->user_model->get_joins('items', $where, $join, array('items.*'));

           // echo $this->db->last_query();
           // print_r($data);
            //--check category item 
            if (!$data['items'])
                $data['items'] = "Category Data Not Found";
            print_r(json_encode($data));
        }else {
            echo 'Incorrect Url';
        }
    }

    function items_details() {
        if ($this->uri->segment('4')) {
            $where = array('i_id' => $this->uri->segment('4'));
            $data['items'] = $this->user_model->get_joins('items', $where);
            print_r(json_encode($data));
        } else {
            echo 'Incorrect Url';
        }
    }

    function advertise() {

        $where = array('status' => '1');
        echo json_encode($this->user_model->get_joins('advertise', $where));
    }

    function advertise_items() {
        if ($this->uri->segment('4')) {
            //----cate where condition
            $where = array('advertise.a_id' => $this->uri->segment('4'),
                'status' => '1');

            //--get category data
            $data['advertise'] = $this->user_model->get_joins('advertise', $where);


            $where = array('advertise.a_id' => $this->uri->segment('4'),
                'advertise_items.status' => '1',
                'advertise.status' => '1');
            //----get category item data
            $join = array(array('table' => 'advertise', 'condition' => 'advertise_items.a_id=advertise.a_id', 'jointype' => 'inner'));
            $data['advertise_items'] = $this->user_model->get_joins('advertise_items', $where, $join, array('advertise_items.*'));

            //--check category item 
            if (!$data['advertise_items'])
                $data['advertise_items'] = "Advertise items Data Not Found";
            print_r(json_encode($data));
        }else {
            echo 'Incorrect Url';
        }
    }

    function event() {
        $where = array('status' => '1');
        if ($this->uri->segment('4'))
            $where['e_id'] = $this->uri->segment('4');

        echo json_encode($this->user_model->get_joins('events', $where));
    }

    function search(){
        $where = array('status' => '1');
        $like['name'] = '';
        if ($this->uri->segment('4'))
            $like['name'] = $this->uri->segment('4');
        $data = $this->user_model->get_sql_select_data('events', $where, NULL, NULL, NULL, $like);
        if ($data)
            echo json_encode($data);
        else
            echo "No Data Found";
    }
    
    function banner(){
        $where = array('status' => '1','front_banner' => '1');
        echo json_encode($this->user_model->get_sql_select_data('items', $where,array('i_id','name','image')));
     }

}

?>
