<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Advertise extends MY_Controller {

    public function __construct() {
        parent::__construct();
        if (($this->session->userdata('u_type') != "1"))
            redirect(site_url() . 'user/');
    }

    public function index() {
        $data['advertise'] = $this->user_model->get_joins('advertise');
        $this->layout->view('advertise_view', $data);
    }

    public function add() {

        if ($this->form_validation->run('advertise') == false) {
            $this->layout->view('advertise_add_view');
        } else {

            /* --file upload---- */
            $config['upload_path'] = './uploads/';
            $config['allowed_types'] = 'gif|jpg|jpeg|png';
            $this->load->library('upload');
            $this->upload->initialize($config);
            if (!$this->upload->do_upload()) {
                print_r($this->upload->display_errors());
                $data['error'] = 'Select Image';
                $this->layout->view('advertise_add_view', $data);
            } else {
                $uploads = $this->upload->data();

                $randomcode = time() . rand();
                $newimagename = $randomcode . $uploads['file_ext'];
                rename($uploads['full_path'], $uploads['file_path'] . $newimagename);

                $advertise = $this->input->post('advertise');
                $advertise['image'] = base_url() . 'uploads/'.$newimagename;
                $this->user_model->INSERTDATA('advertise', $advertise);
                redirect(site_url() . 'advertise');
            }
        }
    }

    function edit() {
        if (!$this->uri->segment('3'))
            redirect(site_url() . 'advertise');

        $where = array('a_id' => $this->uri->segment('3'));
        $data['advertise'] = array_shift($this->user_model->get_joins('advertise', $where));
        if ($this->form_validation->run('advertise') == false) {
            $this->layout->view('advertise_add_view', $data);
        } else {

            $advertise = $this->input->post('advertise');
            $this->user_model->UPDATEDATA('advertise', $where, $advertise);
            
            $config['upload_path'] = './uploads/';
            $config['allowed_types'] = 'gif|jpg|jpeg|png';
            $this->load->library('upload');
            $this->upload->initialize($config);
            if ($this->upload->do_upload()) {
                $uploads = $this->upload->data();
                $randomcode = time() . rand();
                $newimagename = $randomcode . $uploads['file_ext'];
                rename($uploads['full_path'], $uploads['file_path'] . $newimagename);
                $advertise['image'] = base_url().'uploads/'.$newimagename;
                $this->user_model->UPDATEDATA('advertise', $where, $advertise);
            }
            redirect(site_url() . 'advertise');
        }
    }

   

    function delete() {
        if ($this->input->is_ajax_request()) {
            $this->user_model->deletedata('advertise', array('a_id' => $this->input->post('a_id')));
        }
    }
    function active() {
        if ($this->input->is_ajax_request()) {
            $this->user_model->UPDATEDATA('advertise', array('a_id' => $this->input->post('a_id')),array('status'=>$this->input->post('val')));
        }
    }

}

?>
