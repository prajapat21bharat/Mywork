<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Category extends MY_Controller {

    public function __construct() {
        parent::__construct();
        if (($this->session->userdata('u_type') != "1"))
            redirect(site_url() . 'user/');
    }

    public function index() {
        $data['category'] = $this->user_model->get_joins('category');
        $this->layout->view('category_view', $data);
    }

    public function add() {

        if ($this->form_validation->run('category') == false) {
            $this->layout->view('category_add_view');
        } else {

            /* --file upload---- */
            $config['upload_path'] = './uploads/';
            $config['allowed_types'] = 'gif|jpg|jpeg|png';
            $this->load->library('upload');
            $this->upload->initialize($config);
            if (!$this->upload->do_upload()) {
                print_r($this->upload->display_errors());
                $data['error'] = 'Select Image';
                $this->layout->view('category_add_view', $data);
            } else {
                $uploads = $this->upload->data();

                $randomcode = time() . rand();
                $newimagename = $randomcode . $uploads['file_ext'];
                rename($uploads['full_path'], $uploads['file_path'] . $newimagename);

                $category = $this->input->post('category');
                $category['image'] = base_url() . 'uploads/'.$newimagename;
                $this->user_model->INSERTDATA('category', $category);
                redirect(site_url() . 'category');
            }
        }
    }

    function edit() {
        if (!$this->uri->segment('3'))
            redirect(site_url() . 'category');

        $where = array('c_id' => $this->uri->segment('3'));
        $data['category'] = array_shift($this->user_model->get_joins('category', $where));
        if ($this->form_validation->run('category') == false) {
            $this->layout->view('category_add_view', $data);
        } else {

            $category = $this->input->post('category');
            $this->user_model->UPDATEDATA('category', $where, $category);
            
            $config['upload_path'] = './uploads/';
            $config['allowed_types'] = 'gif|jpg|jpeg|png';
            $this->load->library('upload');
            $this->upload->initialize($config);
            if ($this->upload->do_upload()) {
                $uploads = $this->upload->data();
                $randomcode = time() . rand();
                $newimagename = $randomcode . $uploads['file_ext'];
                rename($uploads['full_path'], $uploads['file_path'] . $newimagename);
                $category['image'] = base_url().'uploads/'.$newimagename;
                $this->user_model->UPDATEDATA('category', $where, $category);
            }
            redirect(site_url() . 'category');
        }
    }

    public function profile_edit() {
        $where = array('p_u_id' => $this->session->userdata('u_id'));
        $this->data['user_data'] = $this->user_model->get_sql_select_data('user_profile', $where, NULL, '1');
        $this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
        //registration
        if ($this->form_validation->run('edit_profile') == FALSE) {
            $this->layout->view("profile_edit_view", $this->data);
        } else {
            $profile = $this->input->post('user_profile');
            $this->user_model->UPDATEDATA('user_profile', $where, $profile);

            /* --file upload---- */
            $config['upload_path'] = './uploads/';
            $config['allowed_types'] = 'gif|jpg|jpeg|png';
            $this->load->library('upload');
            $this->upload->initialize($config);

            if ($this->upload->do_upload()) {
                $uploads = array($this->upload->data());
                foreach ($uploads as $key => $value) {

                    $randomcode = time() . rand();
                    $newimagename = $randomcode . $value['file_ext'];
                    rename($value['full_path'], $uploads[0]['file_path'] . $newimagename);
                    $userfile = $newimagename;

                    $profile['p_image'] = $userfile;
                    $this->user_model->UPDATEDATA('user_profile', $where, $profile);
                    //redirect(site_url() . 'home');
                }
            }
            $this->data['user_data'] = $this->user_model->get_sql_select_data('user_profile', $where, NULL, '1');
            $this->data['success'] = 'well done';
            $this->layout->view("profile_edit_view", $this->data);
        }
    }

    function delete() {
        if ($this->input->is_ajax_request()) {
            $this->user_model->deletedata('category', array('c_id' => $this->input->post('c_id')));
        }
    }
    function active() {
        if ($this->input->is_ajax_request()) {
            $this->user_model->UPDATEDATA('category', array('c_id' => $this->input->post('c_id')),array('status'=>$this->input->post('val')));
        }
    }

}

?>
