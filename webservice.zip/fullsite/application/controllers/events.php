<?php if (!defined('BASEPATH'))exit('No direct script access allowed');

class Events extends MY_Controller {

    public function __construct() {
        parent::__construct();
        if (($this->session->userdata('u_type') != "1"))
            redirect(site_url() . 'user');
    }

    public function index() {
        $data['events'] = $this->user_model->get_joins('events', NULL, NULL, array('events.*'));
        $this->layout->view('events_view', $data);
    }

    public function add() {

        if ($this->form_validation->run('events') == false) {
            $this->layout->view('events_add_view');
        } else {
            /* --file upload---- */
            $config['upload_path'] = './uploads/';
            $config['allowed_types'] = 'gif|jpg|jpeg|png';
            $this->load->library('upload');
            $this->upload->initialize($config);
            if (!$this->upload->do_upload()) {
                $data['error'] = $this->upload->display_errors();
                $this->layout->view('events_add_view', $data);
            } else {
                $uploads = $this->upload->data();

                $randomcode = time() . rand();
                $newimagename = $randomcode . $uploads['file_ext'];
                rename($uploads['full_path'], $uploads['file_path'] . $newimagename);

                $item = $this->input->post('events');
                $item['image'] = base_url() . 'uploads/' . $newimagename;
                $this->user_model->INSERTDATA('events', $item);
                redirect(site_url() . 'events');
            }
        }
    }

    function edit() {
        if (!$this->uri->segment('3'))
            redirect(site_url() . 'events');
        $where = array('e_id' => $this->uri->segment('3'));
        $data['events'] = array_shift($this->user_model->get_joins('events', $where));
         if ($this->form_validation->run('events') == false) {
            $this->layout->view('events_add_view', $data);
        } else {

            $item = $this->input->post('events');
            $this->user_model->UPDATEDATA('events', $where, $item);

            $config['upload_path'] = './uploads/';
            $config['allowed_types'] = 'gif|jpg|jpeg|png';
            $this->load->library('upload');
            $this->upload->initialize($config);
            if ($this->upload->do_upload()) {
                $uploads = $this->upload->data();
                $randomcode = time() . rand();
                $newimagename = $randomcode . $uploads['file_ext'];
                rename($uploads['full_path'], $uploads['file_path'] . $newimagename);
                $item['image'] = base_url() . 'uploads/' . $newimagename;
                $this->user_model->UPDATEDATA('events', $where, $item);
            }
            redirect(site_url() . 'events');
        }
    }

    function delete() {
        if ($this->input->is_ajax_request()) {
            $this->user_model->deletedata('events', array('e_id' => $this->input->post('e_id')));
        }
    }

    function active() {
        if ($this->input->is_ajax_request()) {
            $this->user_model->UPDATEDATA('events', array('e_id' => $this->input->post('e_id')), array('status' => $this->input->post('val')));
        }
    }

}
