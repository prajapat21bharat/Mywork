<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Advertise_items extends MY_Controller {

    public function __construct() {
        parent::__construct();
        if (($this->session->userdata('u_type') != "1"))
            redirect(site_url() . 'user/');
    }

    public function index(){
        $join=array(array('table'=>'advertise','condition'=>'advertise_items.a_id=advertise.a_id','jointype'=>'inner'));
        $data['advertise_items'] = $this->user_model->get_joins('advertise_items',NULL,$join,array('advertise_items.*','advertise.name as aname'));
        $this->layout->view('Advertise_items_view',$data);
    }

    public function add(){
        
        $data['advertise'] = $this->user_model->get_joins('advertise',NUll,NULL,array('a_id','name'));
        if ($this->form_validation->run('advertise_items') == false) {
            $this->layout->view('Advertise_items_add_view',$data);
        } else {      

            /* --file upload---- */
            $config['upload_path'] = './uploads/';
            $config['allowed_types'] = 'gif|jpg|jpeg|png';
            $this->load->library('upload');
            $this->upload->initialize($config);
            if (!$this->upload->do_upload()) {
                print_r($this->upload->display_errors());
                $data['error'] = 'Select Image';
                $this->layout->view('Advertise_items_add_view', $data);
            } else {
                $uploads = $this->upload->data();

                $randomcode = time() . rand();
                $newimagename = $randomcode . $uploads['file_ext'];
                rename($uploads['full_path'], $uploads['file_path'] . $newimagename);
               
                $item = $this->input->post('advertise_items');
                $item['image'] = base_url() . 'uploads/' .$newimagename;
                $this->user_model->INSERTDATA('advertise_items', $item);
                redirect(site_url() . 'advertise_items');
            }
        }
    }

    function edit() {
        if (!$this->uri->segment('3'))
            redirect(site_url() . 'advertise_items');
         $data['advertise'] = $this->user_model->get_joins('advertise',NUll,NULL,array('a_id','name'));
       
        $where = array('ai_id' => $this->uri->segment('3'));
        $data['advertise_items'] = array_shift($this->user_model->get_joins('advertise_items', $where));
        if ($this->form_validation->run('advertise_items') == false) {
            $this->layout->view('Advertise_items_add_view',$data);
        } else {
           
            $item = $this->input->post('advertise_items');
            $this->user_model->UPDATEDATA('advertise_items', $where, $item);
            
            $config['upload_path'] = './uploads/';
            $config['allowed_types'] = 'gif|jpg|jpeg|png';
            $this->load->library('upload');
            $this->upload->initialize($config);
            if ($this->upload->do_upload()) {
                $uploads = $this->upload->data();
                $randomcode = time() . rand();
                $newimagename = $randomcode . $uploads['file_ext'];
                rename($uploads['full_path'], $uploads['file_path'] . $newimagename);               
                $item['image'] = base_url() . 'uploads/' .$newimagename;
                $this->user_model->UPDATEDATA('advertise_items', $where, $item);
            }
            redirect(site_url() . 'advertise_items');           
            
        }
    }
    
     function delete() {
        if ($this->input->is_ajax_request()) {
            $this->user_model->deletedata('advertise_items', array('ai_id' => $this->input->post('ai_id')));
           
        }
    }
    
    function active() {
        if ($this->input->is_ajax_request()) {
            $this->user_model->UPDATEDATA('advertise_items', array('ai_id' => $this->input->post('ai_id')),array('status'=>$this->input->post('val')));
          
        }
    }

  

}
