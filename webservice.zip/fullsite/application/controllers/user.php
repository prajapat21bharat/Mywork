<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class User extends MY_Controller {

    public function __construct() {
        parent::__construct();
    }

    public function index() {
        if ($this->session->userdata('u_type')=="1") {
            $this->session->set_userdata($udata);
            redirect(site_url() . 'category');
        }
        
        $this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
        if ($this->form_validation->run('login') == FALSE) {
            $this->load->view("login_view");
        } else {

            if ($this->input->post('reminder') == 1) {
                setcookie('email', $this->input->post('email'));
                setcookie('pass', $this->input->post('pass'));
            }

            $where = array('u_email' => $this->input->post('email'),
                           'u_password' => md5($this->input->post('pass')),
                           'u_status'=>'1',
                           'u_group'=>'1');
            $result = $this->user_model->get_sql_select_data('users', $where, NULL, '1');
            
            if (empty($result)) {
                $where = array('u_username' => $this->input->post('email'),
                               'u_password' => md5($this->input->post('pass')),
                               'u_status'=>'1');
                $result = $this->user_model->get_sql_select_data('users', $where, NULL, '1');
            }
            
            
            if (!empty($result)) {
                $udata = array(
                    'u_id' => $result[0]->u_id,
                    'u_username' => $result[0]->u_username,
                    'u_email' => $result[0]->u_email,
                    'u_type' => $result[0]->u_group,
                    'logged_in' => TRUE
                );
                $this->session->set_userdata($udata);

                
                    redirect(site_url() . 'category/');
               

               
            } else {
                $data['title'] = 'Home';
                $data['validation_error'] = "User not valid";
                $this->load->view("login_view", $data);
            }
        }
    }

    public function logout() {
        $newdata = array(
            'u_id' => '',
            'u_username' => '',
            'u_email' => '',
            'u_type' => '',
            'logged_in' => FALSE,
        );
        $this->session->unset_userdata($newdata);
        $this->session->sess_destroy();
        redirect(site_url() . 'user');
    }

}

?>
