<?php

class MY_Worker extends CI_Controller {

    public $layout_view = 'template/worker';

    function __construct() {
        parent::__construct();
        $this->load->library('layout');
        // error_reporting(0);
    }

    public function order_count() {

        $joins = array(array('table' => 'process',
                            'condition' => 'order.order_process_type=process.process_id',
                            'jointype' => 'inner'));
        $where = array('o_delete' => '1',
                       'worker_id'=> $this->session->userdata('u_id'));
        $column=array('order_id','order_alert','order_delivery_date','order_title','order_process_status');
        $order_count = $this->user_model->get_joins('order', $where, $joins,$column,NULL,NULL,'order_alert Desc,order_id Desc');
        return $order_count;
        
    }
    
    

}
