<?php

class MY_Controller extends CI_Controller {

    public $layout_view = 'template/admin';

    function __construct() {
        parent::__construct();
        $this->load->library('layout');
        // error_reporting(0);
    }

    /*--Its function use to get query alert ----*/
    public function query_count() {

        $joins = array(array('table' => 'order',
                'condition' => 'query.q_order_id=order.order_id',
                'jointype' => 'inner'),
            array('table' => 'user_profile',
                'condition' => 'query.q_worker_id=user_profile.p_u_id',
                'jointype' => 'left'));
        $column = array('q_date', 'q_order_id', 'q_query','query_id', 'order_title', 'order_id', 'q_status','p_fname', 'p_lname');
        return $this->user_model->get_joins('query', array('q_status'=>'1'), $joins, $column, NULL, NULL, 'query_id  DESC');
    }
    
}
