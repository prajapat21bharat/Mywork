import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Calendermodel1editPage } from './calendermodel1edit';

@NgModule({
  declarations: [
    Calendermodel1editPage,
  ],
  imports: [
    IonicPageModule.forChild(Calendermodel1editPage),
  ],
})
export class Calendermodel1editPageModule {}
