import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Calendermodel3Page } from '../calendermodel3/calendermodel3';


/**
 * Generated class for the ReactivatesessionPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-reactivatesession',
  templateUrl: 'reactivatesession.html',
})
export class ReactivatesessionPage {
  overlayHidden: boolean = true;
  overlayHiddenReactivated: boolean = true;
  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ReactivatesessionPage');
  }

	hideOverlay() {
		this.overlayHidden = true;
	}
  
	showOverlay() {
		this.overlayHidden = false;
	}

	hideOverlayReactivated() {
		this.overlayHiddenReactivated = true;
	}
  
	showOverlayReactivated() {
		this.overlayHiddenReactivated = false;
	}
	
	//Loadreactivate(){
	//	this.navCtrl.push(ReactivatecnfrmPage);
	//}
	
	LoadcalendarHome(){
		this.navCtrl.setRoot(Calendermodel3Page);
	}
	
	
}
