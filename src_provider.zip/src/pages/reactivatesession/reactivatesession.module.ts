import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ReactivatesessionPage } from './reactivatesession';

@NgModule({
  declarations: [
    ReactivatesessionPage,
  ],
  imports: [
    IonicPageModule.forChild(ReactivatesessionPage),
  ],
})
export class ReactivatesessionPageModule {}
