import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Calendermodel3editPage } from '../calendermodel3edit/calendermodel3edit';
import { ClndrbookingreqstPage } from '../clndrbookingreqst/clndrbookingreqst';
import { CalendarComponentOptions } from 'ion2-calendar';

/**
 * Generated class for the Calendermodel3Page page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-calendermodel3',
  templateUrl: 'calender3.html',
})
export class Calendermodel3Page {

  constructor(public navCtrl: NavController, public navParams: NavParams) {
		this.shownGroup=0;
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad Calendermodel3Page');
  }
	Loadclendr3(){
		this.navCtrl.push(Calendermodel3editPage);
	}
	Loadcapacity(){
		this.navCtrl.push(ClndrbookingreqstPage);
	}
	/* monu 031117
	hideOverlay() {
		this.overlayHidden = true;
	}
  
	showOverlay() {
		this.overlayHidden = false;
	}
	*/
	
date= new Date();
dateRange: { from: string; to: string; };
  type: 'string'; // 'string' | 'js-date' | 'moment' | 'time' | 'object'
  optionsRange: CalendarComponentOptions = {
    pickMode: 'range'
  };

	overlayHidden: boolean = true;
	shownParent = null;
	shownGroup = null;
	selectedAll = null;
	category: Array<any>;
	
	arr = {};
	
	
	structure: any = { lower: 7, upper: 15 };

	    selectedEntry;

	items=[
		{"title":"Sport & Mouvement","parent_id":0, "id": 1, checked: false},
		{"title":"Divertissement","parent_id":0, "id": 2, checked: false},
		{"title":"Bien-être & Personnalité","parent_id":0, "id": 3, checked: false},
		{"title":"Créativité & Arts","parent_id":0, "id": 4, checked: false},
		{"title":"Goût & Papilles","parent_id":0, "id": 5, checked: false},
		{"title":"Ipsum","parent_id":1, "id": 6, checked: false},
		{"title":"Lorem Ipsum","parent_id":1, "id": 7, checked: false},
		{"title":"sitis","parent_id":1, "id": 8, checked: false},
		{"title":"Dolor","parent_id":1, "id": 9, checked: false},
		{"title":"Dolor sitis","parent_id":1, "id": 10, checked: false},
		{"title":"Ipsum","parent_id":2, "id": 11, checked: false},
		{"title":"Lorem Ipsum","parent_id":2, "id": 12, checked: false},
		{"title":"sitis","parent_id":2, "id": 13, checked: false},
		{"title":"Dolor","parent_id":2, "id": 14, checked: false},
		{"title":"Dolor sitis","parent_id":2, "id": 15, checked: false},

		{"title":"sitis","parent_id":3, "id": 16, checked: false},
		{"title":"Dolor","parent_id":3, "id": 17, checked: false},
		{"title":"Dolor sitis","parent_id":4, "id": 18, checked: false},

		{"title":"sitis","parent_id":4, "id": 19, checked: false},
		{"title":"Dolor","parent_id":5, "id": 20, checked: false},
		{"title":"Dolor sitis","parent_id":5, "id": 121, checked: false},
	];

  


	checked() {
          return this.items .filter(item => {
			return item.checked;
          });
    }


  hideOverlay() {
		this.overlayHidden = true;
	}

	showOverlay() {
		console.log("hiiiii");
			this.overlayHidden = false;
	}

	toggleGroup(group) {
		/*if (this.isGroupShown(group)) {
			this.shownGroup = null;
		} else {
			this.shownGroup = group;
		}*/
		this.shownParent =null;
		this.shownGroup = group;
		console.log(this.shownGroup+"Hoii");
	};

	isGroupShown(group) {
		console.log(group);
		return this.shownGroup === group;
	};


	toggleParent(group) {
		/*if (this.isGroupShown(group)) {
			this.shownGroup = null;
		} else {
			this.shownGroup = group;
		}*/
		this.shownParent = group;
		console.log(this.shownParent+"Hoii");
	};

	isParentShown(group) {
		console.log(group);
		return this.shownParent === group;
	};

	onSelectionChange(entry,pid,index) {
		this.arr[index]  = pid;
		this.selectedEntry = entry;
		console.log(this.arr,'cccccccc');
		console.log(entry,"xxxxxx",pid,index);
		
    }

    selectAll(element) {
		for (var i = 0; i < this.items.length; i++) {
			if(this.items[i].parent_id==element){
				this.items[i].checked = this.selectedAll;
			}
		}
	}
	
	checkIfAllSelected() {
		this.selectedAll = this.items.every(function(item:any) {
			return item.checked == true;
		})
	}
}
