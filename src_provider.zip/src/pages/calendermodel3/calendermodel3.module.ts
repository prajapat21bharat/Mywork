import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Calendermodel3Page } from './calendermodel3';

@NgModule({
  declarations: [
    Calendermodel3Page,
  ],
  imports: [
    IonicPageModule.forChild(Calendermodel3Page),
  ],
})
export class Calendermodel3PageModule {}
