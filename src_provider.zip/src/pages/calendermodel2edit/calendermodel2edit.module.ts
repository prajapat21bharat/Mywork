import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Calendermodel2editPage } from './calendermodel2edit';

@NgModule({
  declarations: [
    Calendermodel2editPage,
  ],
  imports: [
    IonicPageModule.forChild(Calendermodel2editPage),
  ],
})
export class Calendermodel2editPageModule {}
