import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Calendermodel2Page } from '../calendermodel2/calendermodel2';

/**
 * Generated class for the Calendermodel2editPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-calendermodel2edit',
  templateUrl: 'calendermodel2edit.html',
})
export class Calendermodel2editPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad Calendermodel2editPage');
  }
	Loadcnclsession2(){
			this.navCtrl.push(Calendermodel2Page);
	}
}
