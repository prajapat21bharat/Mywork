import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Calendermodel3Page } from '../calendermodel3/calendermodel3';
import { CapacityPage } from '../capacity/capacity';
import { CancelcnfrmPage } from '../cancelcnfrm/cancelcnfrm';


/**
 * Generated class for the Calendermodel3editPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-calendermodel3edit',
  templateUrl: 'calendermodel3edit.html',
})
export class Calendermodel3editPage {
  overlayHidden: boolean = true;

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad Calendermodel3editPage');
  }
	Loadcnclsession3(){
			this.navCtrl.push(Calendermodel3Page);
	}
	Loadcapacity(){
			this.navCtrl.push(CapacityPage);
	}
	hideOverlay() {
		this.overlayHidden = true;
	}
  
	showOverlay() {
		this.overlayHidden = false;
	}
	Loadcncel(){
		this.navCtrl.push(CancelcnfrmPage);
	}
	LoadcalendarBack(){
		this.navCtrl.setRoot(Calendermodel3Page);
	}
	
}
