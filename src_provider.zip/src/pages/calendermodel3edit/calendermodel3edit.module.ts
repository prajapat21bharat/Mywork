import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Calendermodel3editPage } from './calendermodel3edit';

@NgModule({
  declarations: [
    Calendermodel3editPage,
  ],
  imports: [
    IonicPageModule.forChild(Calendermodel3editPage),
  ],
})
export class Calendermodel3editPageModule {}
