import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Calendermodel1Page } from './calendermodel1';

@NgModule({
  declarations: [
    Calendermodel1Page,
  ],
  imports: [
    IonicPageModule.forChild(Calendermodel1Page),
  ],
})
export class Calendermodel1PageModule {}
