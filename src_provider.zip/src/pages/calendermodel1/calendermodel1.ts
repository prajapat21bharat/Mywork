import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Calendermodel1editPage } from '../calendermodel1edit/calendermodel1edit';


/**
 * Generated class for the Calendermodel1Page page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-calendermodel1',
  templateUrl: 'calender.html',
})
export class Calendermodel1Page {

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad Calendermodel1Page');
  }
	Loadclendr1(){
		this.navCtrl.push(Calendermodel1editPage);
	}
	
}
