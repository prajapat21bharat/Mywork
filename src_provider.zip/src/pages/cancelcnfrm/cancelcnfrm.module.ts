import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CancelcnfrmPage } from './cancelcnfrm';

@NgModule({
  declarations: [
    CancelcnfrmPage,
  ],
  imports: [
    IonicPageModule.forChild(CancelcnfrmPage),
  ],
})
export class CancelcnfrmPageModule {}
