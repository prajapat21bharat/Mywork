import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { ReactivatesessionPage } from '../reactivatesession/reactivatesession';
import { Calendermodel3editPage } from '../calendermodel3edit/calendermodel3edit';

/**
 * Generated class for the CancelcnfrmPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-cancelcnfrm',
  templateUrl: 'cancelcnfrm.html',
})
export class CancelcnfrmPage {
  overlayHidden: boolean = true;
  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CancelcnfrmPage');
  }
  hideOverlay() {
	this.overlayHidden = true;
  }
  showOverlay() {
	this.overlayHidden = false;
  }
  Loadedit(){
	this.navCtrl.push(Calendermodel3editPage);
  }
  LoadedReactivate(){
	this.navCtrl.push(ReactivatesessionPage);
  }
}
