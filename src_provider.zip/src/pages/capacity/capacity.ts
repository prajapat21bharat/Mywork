import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Calendermodel3editPage } from '../calendermodel3edit/calendermodel3edit';
import { Calendermodel3Page } from '../calendermodel3/calendermodel3';

/**
 * Generated class for the CapacityPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-capacity',
  templateUrl: 'capacity.html',
})


export class CapacityPage {

  overlayHidden: boolean = true;
  structure: any = { lower: 7, upper: 15 };
  
  
  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }
	hideOverlay() {
		this.overlayHidden = true;
	}
	showOverlay() {
		this.overlayHidden = false;
	}  
	
	ionViewDidLoad() {
		console.log('ionViewDidLoad CapacityPage');
	}	
	Loadcapacity(){
		this.navCtrl.push(Calendermodel3editPage);
  }
  LoadcapacityHome(){
  this.navCtrl.setRoot(Calendermodel3editPage);
  }
}
