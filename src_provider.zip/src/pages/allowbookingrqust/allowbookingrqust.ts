import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the AllowbookingrqustPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-allowbookingrqust',
  templateUrl: 'allowbookingrqust.html',
})
export class AllowbookingrqustPage {
  overlayHidden: boolean = true;
  overlayHiddennew: boolean = false;
  overlayHiddenchange: boolean = false;
  overlayHiddenvalue: boolean = false;
  checked: boolean = false;
  checkednew: boolean = false;
  checkednewvalue: boolean = false;
  bookingbtn: boolean = false;
  	buttonClicked: boolean = false;

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AllowbookingrqustPage');
  }

	hideOverlay() {
		this.overlayHidden = true;
	}
  
	showOverlay() {
			this.overlayHidden = false;
	}
	
	onButtonClick() {
		this.buttonClicked = !this.buttonClicked;
    }
//code for show button	
	
	addValue(e): void {
    var isChecked = e.currentTarget.checked;
    //console.log(e.currentTarget);
    console.log(this.checked);
    if(this.checked == true || this.checkednew == true || this.checkednewvalue == true){
    this.bookingbtn = true;
    }else{
    this.bookingbtn = false;
    }
    }
 

// For hide checkbox data
  
 	hideOverlaynew() {
		this.overlayHidden = true;
		if(this.checked == true){
			this.overlayHiddennew = true;
    }
    if(this.checkednew == true){
			this.overlayHiddenchange = true;
    }
    if(this.checkednewvalue == true){
			this.overlayHiddenvalue = true;
    }
    this.bookingbtn = false;
 	}
}
