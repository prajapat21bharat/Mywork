import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AllowbookingrqustPage } from './allowbookingrqust';

@NgModule({
  declarations: [
    AllowbookingrqustPage,
  ],
  imports: [
    IonicPageModule.forChild(AllowbookingrqustPage),
  ],
})
export class AllowbookingrqustPageModule {}
