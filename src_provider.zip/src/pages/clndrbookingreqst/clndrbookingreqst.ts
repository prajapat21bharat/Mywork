import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Calendermodel3Page } from '../calendermodel3/calendermodel3';
import { CapacityPage } from '../capacity/capacity';

/**
 * Generated class for the ClndrbookingreqstPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-clndrbookingreqst',
  templateUrl: 'clndrbookingreqst.html',
})
export class ClndrbookingreqstPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ClndrbookingreqstPage');
  }
	Loadclednrbook(){
		this.navCtrl.setRoot(Calendermodel3Page);
	}
	Loadinccap(){
		this.navCtrl.push(CapacityPage);
	}
}
