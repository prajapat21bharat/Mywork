import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ClndrbookingreqstPage } from './clndrbookingreqst';

@NgModule({
  declarations: [
    ClndrbookingreqstPage,
  ],
  imports: [
    IonicPageModule.forChild(ClndrbookingreqstPage),
  ],
})
export class ClndrbookingreqstPageModule {}
