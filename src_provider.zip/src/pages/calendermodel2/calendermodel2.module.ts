import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Calendermodel2Page } from './calendermodel2';

@NgModule({
  declarations: [
    Calendermodel2Page,
  ],
  imports: [
    IonicPageModule.forChild(Calendermodel2Page),
  ],
})
export class Calendermodel2PageModule {}
