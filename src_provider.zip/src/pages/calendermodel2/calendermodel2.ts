import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Calendermodel2editPage } from '../calendermodel2edit/calendermodel2edit';

/**
 * Generated class for the Calendermodel2Page page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-calendermodel2',
  templateUrl: 'calender2.html',
})
export class Calendermodel2Page {

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad Calendermodel2Page');
  }
  Loadclendr2(){
		this.navCtrl.push(Calendermodel2editPage);
	}
}
