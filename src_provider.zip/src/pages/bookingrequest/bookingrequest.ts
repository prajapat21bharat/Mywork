import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { AllowbookingrqustPage } from '../allowbookingrqust/allowbookingrqust';

/**
 * Generated class for the BookingrequestPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-bookingrequest',
  templateUrl: 'bookingrequest.html',
})
export class BookingrequestPage {

  constructor(public navCtrl: NavController, public navParams: NavParams) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad BookingrequestPage');
  }

  allowRequest() {
    this.navCtrl.push(AllowbookingrqustPage);
  }

}
