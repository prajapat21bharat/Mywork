import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { BookingrequestPage } from './bookingrequest';

@NgModule({
  declarations: [
    BookingrequestPage,
  ],
  imports: [
    IonicPageModule.forChild(BookingrequestPage),
  ],
})
export class BookingrequestPageModule {}
