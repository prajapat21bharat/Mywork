import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';

import { MyApp } from './app.component';
import { LoginPage } from '../pages/login/login';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { CalendarModule } from "ion2-calendar";
import { MyDataPipe } from '../pipes/my-data/my-data';

import { Calendermodel1Page } from '../pages/calendermodel1/calendermodel1';
import { Calendermodel1editPage } from '../pages/calendermodel1edit/calendermodel1edit';
import { Calendermodel2Page } from '../pages/calendermodel2/calendermodel2';
import { Calendermodel2editPage } from '../pages/calendermodel2edit/calendermodel2edit';
import { Calendermodel3Page } from '../pages/calendermodel3/calendermodel3';
import { Calendermodel3editPage } from '../pages/calendermodel3edit/calendermodel3edit';
import { QrcodePage } from '../pages/qrcode/qrcode';
import { AttendancePage } from '../pages/attendance/attendance';
import { BookingrequestPage } from '../pages/bookingrequest/bookingrequest';
import { AllowbookingrqustPage } from '../pages/allowbookingrqust/allowbookingrqust';
import { CapacityPage } from '../pages/capacity/capacity';
import { CancelcnfrmPage } from '../pages/cancelcnfrm/cancelcnfrm';
import { ReactivatesessionPage } from '../pages/reactivatesession/reactivatesession';
import { ClndrbookingreqstPage } from '../pages/clndrbookingreqst/clndrbookingreqst';
import { FilterPage } from '../pages/filter/filter';
import { ReservationPage } from '../pages/reservation/reservation';
import { ForgotpasswordPage } from '../pages/forgotpassword/forgotpassword';

	
@NgModule({
  declarations: [
    MyApp,    
    LoginPage,
    
    Calendermodel1Page,
    Calendermodel1editPage,
    Calendermodel2Page,
    Calendermodel2editPage,
	Calendermodel3Page,
	Calendermodel3editPage,
    QrcodePage,
    AttendancePage,
    BookingrequestPage,
    AllowbookingrqustPage,
    CapacityPage,
    ClndrbookingreqstPage,
    CancelcnfrmPage,
    ReactivatesessionPage,
    ReservationPage,
    MyDataPipe,
    ForgotpasswordPage
  ],
  imports: [
    BrowserModule,
    CalendarModule,
    IonicModule.forRoot(MyApp, {
        platforms : {
          android : {
            scrollAssist: false,    
            autoFocusAssist: false  
          }         
        }
      }
      /*
       * END MODIFY
       */
    ),
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,    
    LoginPage,
    Calendermodel1Page,
    Calendermodel1editPage,
    Calendermodel2Page,
    Calendermodel2editPage,
	Calendermodel3Page,
	Calendermodel3editPage,
    QrcodePage,
    AttendancePage,
    BookingrequestPage,
    AllowbookingrqustPage,
    CapacityPage,
	ClndrbookingreqstPage,
    CancelcnfrmPage,
    ReactivatesessionPage,
    ReservationPage,
    ForgotpasswordPage
    ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {}
