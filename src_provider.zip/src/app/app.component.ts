import { Component, ViewChild } from '@angular/core';
import { Nav, Platform, AlertController } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { LoginPage } from '../pages/login/login';

import { Calendermodel1Page } from '../pages/calendermodel1/calendermodel1';
import { Calendermodel1editPage } from '../pages/calendermodel1edit/calendermodel1edit';
import { Calendermodel2Page } from '../pages/calendermodel2/calendermodel2';
import { Calendermodel2editPage } from '../pages/calendermodel2edit/calendermodel2edit';
import { Calendermodel3Page } from '../pages/calendermodel3/calendermodel3';
import { Calendermodel3editPage } from '../pages/calendermodel3edit/calendermodel3edit';
import { QrcodePage } from '../pages/qrcode/qrcode';
import { AttendancePage } from '../pages/attendance/attendance';
import { BookingrequestPage } from '../pages/bookingrequest/bookingrequest';
import { AllowbookingrqustPage } from '../pages/allowbookingrqust/allowbookingrqust';
import { CapacityPage } from '../pages/capacity/capacity';
import { CancelcnfrmPage } from '../pages/cancelcnfrm/cancelcnfrm';
import { ReactivatesessionPage } from '../pages/reactivatesession/reactivatesession';
import { ClndrbookingreqstPage } from '../pages/clndrbookingreqst/clndrbookingreqst';
import { ReservationPage } from '../pages/reservation/reservation';
import { FilterPage } from '../pages/filter/filter';

@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  @ViewChild(Nav) nav: Nav;

  rootPage: any = LoginPage;

  pages: Array<{title: string, component: any, img: string}>;
  
  constructor(public platform: Platform, public statusBar: StatusBar, public splashScreen: SplashScreen, private alertCtrl: AlertController) {
    this.initializeApp();

    // used for an example of ngFor and navigation
    this.pages = [
      { title: 'CALENDAR', component: Calendermodel3Page , img : "assets/img/menu_tick.png" },
      { title: 'BOOKING REQUEST', component: BookingrequestPage , img : "assets/img/Group 16.png" },
      { title: 'ATTENDANCE', component: AttendancePage,img : "assets/img/Group 13.png" },
      { title: 'QR CODE', component: QrcodePage ,img : "assets/img/Group 14.png" },
  
    ];
 }
	
  initializeApp() {
    this.platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
  }
  openPage(page) {
    // Reset the content nav to have just this page
    // we wouldn't want the back button to show in this scenario
    this.nav.setRoot(page.component);
  }
  
  
	LogoutConfirm() {
	  let alert = this.alertCtrl.create({
		title: '',
		message: 'Are you sure you want to logout?',
		buttons: [
		  {
			text: 'Yes',
			handler: () => {
				this.nav.setRoot(LoginPage);
			  console.log('Buy clicked');
			}
		  },
		  {
			text: 'No',
			role: 'cancel',
			handler: () => {
			  console.log('Cancel clicked');
			}
		  }
		]
	  });
	  alert.present();
	}
}
