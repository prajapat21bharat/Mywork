<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

<?php $this->load->view('layout/header'); ?>

<link rel="stylesheet" href="<?php echo base_url(); ?>assets/slider/index_data/jquery.css" type="text/css" media="screen">

<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" />

 <link rel="stylesheet" href="<?php echo base_url('assets/css/jquery.datepick.css') ?>">

  <script type="text/javascript" src="<?php echo base_url('assets/js/jquery.datepick.js') ?>"></script> 

   <script type="text/javascript">

    $(function() {

     $('#popupDatepicker').datepick();

		});

		

		

	function changepassword(){	

	parent.$.fancybox.open({href : "<?php echo site_url().'changepassword';?>" , type: 'ajax',height: 'auto', width: 'auto',scrolling : 'auto'});

	

	}

</script>







<div class="hero-unit container" id="profile">

  <div class="row-fluid profile-form">

    <div class="span12">

      <h3>Profile Information</h3>

      <div class="right_btn">

       <a class="back_btn" href="javascript: history.go(-1)">Back</a>

      </div>

  <div class="msg"> 

    <?php if(!empty($success)){

           echo $success;

	       } ?>

  </div>    

            

<div class="profile-left-part span3 ">

  <div id="profile_img">

       <?php if($user_info){

		  if(!empty($user_info[0]->userfile)){	

		  $image=site_url()."uploadimages/user/".$user_info[0]->userfile; 

		  }else{

		 	$image=$this->session->userdata('user_image');

			 }

	   }?>

      <a class="fancybox" href=" javascript:void(0)"><img src="<?php echo $image;?>" height="100px" width="100px"/></a>

     

      <?php if(!empty($error)) echo $error; ?>

    

    </div>

    

    <div class="profile-link">

        <a class="profile" title="profile" id="view_pro" href="javascript:void(0)" >

        <span class="profile_box Profile_icon"> </span>

        <span>Profile</span> 

        </a> 

        <a class="favlist"  id ="favlist" href="javascript:void(0)">

		<span class="profile_box favorites_icon"> </span>

		<span>Favorites List</span>

        </a> 

        <a class="Edit" title="Edit" id="profiledata" href="javascript:void(0)">

        <span class="profile_box setting_icon"> </span>

        <span>Setting</span>

        </a>

        <a onclick="changepassword()" href="javascript:void(0)" >

        <span class="profile_box password_icon"> </span>

        <span>Change Password</span> 

        </a>

    </div>

         

</div>  



<!---its is a Profile EDIT Div---> 

<?php if($this->uri->segment('2')!='change_profile'){ ?> 

  <div id="editpro"  class="profile-form-wrap span9" style="display:none;"> 

  <?php }else{?>

   <div id="editpro" class="profile-form-wrap span9"> 

  <?php }?> 

  

  

  <?php $edit=array('class'=>'profile_form white_bg edit_pro_from');

    echo form_open_multipart(site_url().'register/change_profile',$edit);?>

   <div class="profile-sapreter">

    <input type="hidden" name="user_id" value="<?php if($user_info){echo $user_info[0]->user_id;} ?>" />

    

    <label>First Name <sup>*</sup>:</label>

    <?php 

	if(set_value('first_name')!=''){

		$name=set_value('first_name');}

	else{

		if($user_info){$name=$user_info[0]->first_name;

		}else{$name='';}

	 }

	?>

    <input type="text" id="firstName" name="first_name" value="<?php echo $name?>"/>

    <?php echo form_error('first_name'); ?></span></p>

    

     <?php 

	if(set_value('last_name')!=''){

		$last_name=set_value('last_name');}

	else{

		if($user_info){$last_name=$user_info[0]->last_name;

		}else{$last_name='';}

	 }

	?>

    </div>

    

    <div class="profile-sapreter">

    <label>Last Name <sup>*</sup>:</label>

    <input type="text"  id="lastName" name="last_name" value="<?php echo $last_name ?>"/>

   <?php echo form_error('last_name'); ?>

   </div>

   

    <div class="profile-sapreter">

    <label>Profile Image :</label>

    <input type="file" name="userfile" value="" />

    <img class="profile" src="<?php echo $image?>" height="100px" width="100px"/>

      <?php if($user_info){

		  if(!empty($user_info[0]->userfile)){	

		     $image=site_url()."uploadimages/user/".$user_info[0]->userfile; 

		  }else{ $image=$this->session->userdata('user_image');

			 }

	   }?>

   

    

    

    <?php if(!empty($error)) echo $error; ?>

    <?php echo form_error('userfile'); ?>

    </div>

    

    <div class="profile-sapreter">

     <?php 

	if(set_value('gender')!=''){

		$gender=set_value('gender');}

	else{

		if($user_info){$gender=$user_info[0]->gender;

		}else{$gender='';}

	 }

	?>    

    <label>Gender :</label>

	

    <input type="radio" name="gender" value="male" <?php if($gender=='male'){ echo 'checked="checked"';}?> />

    <span class="radio-active">Male</span>

    

    

     <input type="radio" name="gender" value="female" <?php if($gender=='female'){ echo 'checked="checked"';}?> />

     <span class="radio-active">Female</span>

     

      </div>

	  

      <div class="profile-sapreter">

	  <?php 

	if(set_value('date')!=''){

		$date=set_value('date');}

	else{

		if($user_info){$date=$user_info[0]->date;

		}else{$date='';}

	 }

	?>

    <label>Date of Birth <sup>*</sup>:</label>

    <input type="text"  value="<?php echo $date;?>" name="date" id="popupDatepicker"/>

     <?php echo form_error('date'); ?>

     </div>

    

    <div class="profile-sapreter">

    <?php 

	if(set_value('city')!=''){

		$city=set_value('city');}

	else{

		if($user_info){$city=$user_info[0]->city;

		}else{$city='';}

	 }

	?> 

    <label>City<sup>*</sup>:</label>

    <input type="text" id="city" value="<?php echo $city;?>" name="city"/>

    <?php echo form_error('city');?>

   </div>

   

   <div class="profile-sapreter">

   <?php 

	if(set_value('state')!=''){

		$state=set_value('state');}

	else{

		if($user_info){$state=$user_info[0]->states;

		}else{$state='';}

	 }

	?> 

    <label>State<sup>*</sup>:</label>

    <input type="text" id="state" value="<?php echo $state;?>" name="state"/>

    <?php echo form_error('state'); ?>

    </div> 

     

     <div class="profile-sapreter">

      <?php 

	if(set_value('zip')!=''){

		$zip=set_value('zip');}

	else{

		if($user_info){$zip=$user_info[0]->zip;

		}else{$zip='';}

	 }

	?> 

    <label>Zip code<sup>*</sup>:</label>

    <input type="text" id="zip" value="<?php echo $zip; ?>" name="zip"/>

     <?php echo form_error('zip'); ?>

    </div>

    

    <div class="profile-sapreter">

     <?php 

	if(set_value('user_phone')!=''){

		$user_phone=set_value('user_phone');}

	else{

		if($user_info){$user_phone=$user_info[0]->user_phone;

		}else{$user_phone='';}

	 }

	?> 

    <label>Mobile Number for notifications <sup>*</sup>:</label>

    <input type="text" name="user_phone" value="<?php echo $user_phone; ?>"  />

     <?php echo form_error('user_phone');?>

    </div>

   <div class="login_button">

    <input type="submit" value="Save" name=" " class="login-btn " />

    <a href="<?php echo base_url()?>register/user_info" id="profileBack" class="login-btn"> Back</a>

    </div>

    <?php echo  form_close();?>

    

  </div>

<!---END Profile EDIT Div--->



  <div id="favs_list" class="profile-form-wrap span9" style="display:none;"></div>

    

<!---its is a Profile Show Div--->

<?php if($this->uri->segment('2')=='change_profile'){ ?> 

  <div id="pro" style="display:none;"> 

  <?php }else{?>

   <div id="pro" class="profile-form-wrap span9"> 

  <?php }?>

  

    <?php  $show=array('class'=>'profile_form white_bg');

	echo form_open_multipart('register/change_profile', $show); ?>

   <input type="hidden" name="user_id"  id="user_id" value="<?php if($user_info){echo $user_info[0]->user_id;} ?>" />

    <div class="profile-sapreter">

        <label>First Name :</label>

        <span>

        <?php if($user_info){echo $user_info[0]->first_name;} ?>

        </span>

    </div>

    

    <div class="profile-sapreter">

        <label>Last Name :</label>

        <span>

        <?php if($user_info){echo $user_info[0]->last_name;} ?>

        </span>

	</div>

    

    <div class="profile-sapreter">

        <label>Gender :</label>

        <span>

        <?php if($user_info){echo $user_info[0]->gender;}?>

        </span>

    </div>

    

    <div class="profile-sapreter">

    <label>Date of Birth :</label>

    <span>

    <?php if($user_info){echo $user_info[0]->date; }?>

    </span>

   	</div>

    

    <div class="profile-sapreter">

    <label>City :</label>

    <span>

    <?php if($user_info){echo $user_info[0]->city;} ?>

    </span>

   	</div>

    

    <div class="profile-sapreter">

    <label>State :</label>

    <span>

    <?php if($user_info){echo $user_info[0]->states;} ?>

    </span>

   	</div>

    

    <div class="profile-sapreter">

    <label>Zip code :</label>

    <span>

    <?php if($user_info){echo $user_info[0]->zip;} ?>

    </span>

    </div>

   

   	<div class="profile-sapreter">

    <label>Mobile Number for notifications :</label>

    <span>

    <?php if($user_info){ echo $user_info[0]->user_phone;} ?>

    </span>

  	</div>

     

    <?php 

echo  form_close();



?>

				</div>

			</div>

<!---END Profile Show Div--->            

            

            

  </div>

 </div>

 </div>

</body>

</html>



<script type="text/javascript">



   $(document).ready(function(){

		

	<?php if($this->uri->segment('2')=='change_profile'){ ?> 

	    jQuery("#profiledata").css("background-color","sandybrown");

		 jQuery("#view_pro").css("background-color","#D75803");

       

     <?php }else{?>

         jQuery("#view_pro").css("background-color","sandybrown");

		 jQuery("#profiledata").css("background-color","#D75803");

    <?php }?>

	    

        jQuery("#favlist").click(function(){ 

 		jQuery("#pro").hide();

		jQuery("#favs_list").show();

		jQuery("#editpro").hide();

		jQuery("#favlist").css("background-color","sandybrown");

		

		

		

	});

	    jQuery("#view_pro").click(function(){ 

 	

		jQuery("#favs_list").hide();

		jQuery("#pro").show();

		jQuery("#editpro").hide();

		jQuery("#view_pro").css("background-color","sandybrown");

		jQuery("#profiledata").css("background-color","#D75803");

		jQuery("#favlist").css("background-color","#D75803");

	});

	     jQuery("#profiledata").click(function(){ 

 		jQuery("#favs_list").hide();

		jQuery("#pro").hide();

		jQuery("#editpro").show();

		jQuery("#profiledata").css("background-color","sandybrown");

		jQuery("#favlist").css("background-color","#D75803");

		jQuery("#view_pro").css("background-color","#D75803");

		

	});   

	

	

	

<!---Its use to Get All Favorite List--->	   

var name = $('#user_id').val();

    if(name==""){

     $("#favs_list").html("");

	 }else{

	

	   $.ajax({	

              type: "POST",

              url: "<?php echo site_url("home/get_favorite_list"); ?>",

              data: {}

              }).done(function( msg ) {

	             $("#favs_list").html(msg);

          });

       }

<!---END get Favorite List--->



});

</script>