<?=$this->load->view('web_view/header.php') ?>
<?php $navigation=site_url().'restaurant/'; ?>
<script type="text/javascript">
		$(document).ready(function() {
			$('.fancybox').fancybox();
			
			$("a#single_image").fancybox();
		});
function pageval(val){
	
	$('.active').removeClass("active");
	$('.active1').removeClass("active1");
	if(val=='menu'){$("#"+val+"_page").attr("class","active1");}
	else{$("#"+val+"_page").attr("class","active");}
	

	
	var form_data = {values:val,rest_id:'<?php echo $this->uri->segment(3);?>'};
	$.ajax({
	   url:'<?=site_url().'restaurant/';?>'+val,
	   data:form_data,    
	   datatype:'json',
	   success:function(data){ 
	   $('#pagedata').html(data);
	   }
  });
}





function Getdirection(){
	
	parent.$.fancybox.open({href : '<?php echo base_url();?>restaurant/getDirection?address = <?php echo $restaurant[0]->restaurant_address; ?>', type: 'iframe',height: 800, width: 500,scrolling : 'auto'})
	
	
	
	}
</script>

<?php ?>
<?php echo 'test'.$restaurant[0]->restaurant_address; ?>
<div class="container main1">
  <div class="row-fluid">
    <div class="span5" >
      <div class="slideman"> <a href="<?php echo $navigation; ?>" class="slideman"><img src="<?php echo base_url().'uploadimages/files/'.$restaurant[0]->restaurant_logo ?>" /></a> </div>
      
      <div id="example1" class="showbiz-container"> 
        <!-- THE NAVIGATION -->
        <?php if(!empty($restaurant_photo)){?>
        <div class="showbiz-navigation center sb-nav-grey"> <a id="showbiz_left_1" class="sb-navigation-left"><i class="sb-icon-left-open"></i></a> <a id="showbiz_right_1" class="sb-navigation-right"><i class="sb-icon-right-open"></i></a>
          <div class="sbclear"></div>
        </div>
        <?php }?>
        <!-- END OF THE NAVIGATION -->
        
        <div class="divide20"></div>
        <div id="sbiz9283" class="showbiz" data-left="#showbiz_left_1" data-right="#showbiz_right_1" data-play="#showbiz_play_1">
          <div style="height: 104px;" class="overflowholder">
            <ul style="width: 1073px; left: -6px; height: 104;">
              <?php
			  //$address=base_url().'uploadimages/submitted_gallery/';	 
		//print_r($photo_gallery);
/*if($photo_gallery){
foreach($photo_gallery as $photo_gallery)  
{
	
	?>
<li style="width: 144px;" class="sb-grey-skin">
                <div class="media">
                  <div class="mediaholder_innerwrap">
                  <img style="height:104px; width:100%;" alt="" src="<?=$address.'thumimage/'.$photo_gallery->thumb_image_url?>" >
                   <div style="opacity: 0;" class="hovercover"><a class="fancybox fancybox.ajax" rel="group" href="<?=site_url().'restaurant/show_photo/'.$photo_gallery->gallery_image_id?>">
                      <div class="lupeicon notalone"><i class="sb-icon-search"></i></div>
                      </a> </div>
                   </div>
                </div>
              </li>
<?php } 
}*/
if($restaurant_photo){
foreach($restaurant_photo as $photo)  
{
	
	?>
              <li style="width: 144px;" class="sb-grey-skin">
                <div class="media">
                  <div class="mediaholder_innerwrap"> <img style="height:104px; width:100%;" alt="" src="<?php echo base_url().'/uploadimages/files/'.$photo->image; ?>" >
                    <div style="opacity: 0;" class="hovercover"> <a class="fancybox" rel="group" href="<?php echo base_url().'/uploadimages/files/'.$photo->image; ?>">
                      <div class="lupeicon notalone"><i class="sb-icon-search"></i></div>
                      </a> </div>
                  </div>
                </div>
              </li>
<?php } 
}?>

            </ul>
            <div class="sbclear"></div>
          </div>
          <!-- END OF OVERFLOWHOLDER -->
          <div class="sbclear"></div>
        </div>
      </div>
    </div>
    <div class="span4 content ">
      <div id="res_info">
        <label><?php echo $restaurant[0]->restaurant_name ?></label>
        <span><?php echo $city[0]->city.' , '.$state[0]->state; ?></span></div>
      <div id="contct">
        <label>Contact us</label>
        <span><?php //echo $restaurant[0]->restaurant_address; ?></span><br />
        <span><?php echo $restaurant[0]->restaurant_phone .' - '.$city[0]->city; ?></span></div>
      <div id="stt"><?php echo $restaurant[0]->state_id .' - '.$restaurant[0]->country_id; ?></div>
      <div class="butn"><a target="_new" href="http://<?=$restaurant[0]->restaurant_website?>">Visit Website</a></div>
      <div class="icons">
      <div class="mobileapp"><a target="_new" href="<?='http://'.$restaurant[0]->mobile_app_url?>">get the mobile app</a></div>
        <ul>
          <li><a target="_new" href="<?='http://'.$restaurant[0]->restaurant_facebook_url?>"><img src="/apetizr/assets/images/fb.png" /></a></li>
          <li><a target="_new" href="<?='http://'.$restaurant[0]->restaurant_twitter_url?>"><img src="/apetizr/assets/images/twit.png" /></a></li>
        </ul>
        
      </div>
    </div>
    <div class="span3">
      <div id="add" class="pull-right"><a class="fancybox fancybox.ajax" href="<?php echo $navigation.'favorite'?>"><img src="/apetizr/assets/images/addfav.png" /></a></div>
   
      <a onclick="Getdirection();" style="cursor:pointer;" >Get Direction</a>
      
      <div class="mapr">
        <label>location</label>
        <iframe width="350" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;
                      geocode=&amp;q=<?=$restaurant[0]->latitude;?>,<?=$restaurant[0]->longitude?>&amp;aq=&amp;sll=<?=$restaurant[0]->latitude;?>,<?=$restaurant[0]->longitude?>&amp;sspn=0.008134,0.01929&amp;t=h&amp;g=<?=$restaurant[0]->latitude;?>,<?=$restaurant[0]->longitude?>&amp;ie=UTF8&amp;ll=<?=$restaurant[0]->latitude;?>,<?=$restaurant[0]->longitude?>&amp;spn=0.004067,0.009645&amp;z=14&amp;iwloc=A&amp;output=embed" style="width: 100% !important;"> </iframe>
      </div>
    </div>
  </div>
  <div class="row-fluid contain1">
    <div class="span12">
      <div class="index">
        <div class="tab">
          <ul>
            <li><a id="menu_page" onclick="pageval('menu')" href="javascript:void(0)">Menu</a></li>
            <li><a id="offer_page" onclick="pageval('offer')" href="javascript:void(0)">Special Offers</a></li>
            <li><a id="events_page" onclick="pageval('events')" href="javascript:void(0)">Event</a></li>
            <li><a href="javascript:void(0)"> Reservations</a></li>
          </ul>
        </div>
        <div class="tabcontain" id="pagedata">
          <?=$content_for_layout?>
        </div>
      </div>
    </div>
  </div>
</div>

<!--footer-->
<?=$this->load->view('web_view/footer.php') ?>
<!--end footer--> 
<script>



</script>
