<?php $site=site_url().'owner/'; ?>
<script type="text/javascript">

function delete_image(id)
{
var r=confirm('Are you Sure Delete This Image');
if (r==true)
	{
	var form_data = {
    photo_id: id
       };
		$.ajax({
			   url:'<?php echo $site.'header_banner/delete_header_gallery';?>',
			   data:form_data,    
			   datatype:'json',
			   success:function(data){
				   $('#'+id).empty();
				   
			   }
		});
	}
}

</script>
<div class="container-fluid main-container header_banner_wrap">
<div class="row-fluid">
<div class="span12">
 <?php $this->load->view('owner/edit_resturant_header') ?>
<div class="container-fluid content-wrapper cluster_container mob-right-part span10">
  <div class="hero-unit">
  
   <h3 class="title">Header Banner Gallery </h3>
  <div class="back_color white_bg"> 
       <?php
foreach($restaurant_banner as $photo)
{?>
     <span class="header_banner" id="<?php echo $photo->header_image_id; ?>">
             <img style="height:150px; width:100%;" alt="" src="<?php echo base_url().'uploadimages/header_banner/'.$photo->h_image; ?>" >
             
                <h4 class="showbiz-title txt-center delete_btn"><a class="login-btn" href="javascript:void(0)"  onclick="delete_image(<?php echo $photo->header_image_id; ?>)">Delete</a></h4>
             
            </span>
  
<?php } ?>

          <?php 
 $attributes = array('class' => 'edit_form','id'=>'header_banner_form');
 echo form_open_multipart('owner/header_banner/edit_header',$attributes); ?>
    <input type="file" multiple name="userfile[]"/>
    <?php echo form_error('userfile'); ?>
    
    
      <input class="login-btn" type="submit" name='' value="Save" />
      </div>
    </div>
  </div>
</div>
 </div>
 </div>
