<?php $site=site_url().'owner/event/'; ?>
<script type="text/javascript">

$(function() {
			$('#basicExample').timepicker();
		  });
 function add_photo()
{ 
	var id=$('#counter').val();
	photo='<input type="file" name="userfile'+id+'" value=""  /><br>';	
	  $('#counter').val(Number(id)+1)
	  $('#more_photo').append(photo);
	
}

function delete_image(id)
{
var r=confirm('Are you Sure Delete This Image');
if (r==true)
	{
	var form_data = {
    photo_id: id
       };
		$.ajax({
			   url:'<?php echo $site.'delete_event_gallery';?>',
			   data:form_data,    
			   datatype:'json',
			   success:function(data){
				   $('#'+id).empty();
				   
			   }
		});
	}
}
 </script>

<div class="container-fluid main-container">
<div class="row-fluid">
<div class="span12">
<?php $this->load->view('owner/edit_resturant_header.php') ?>
<div class="container-fluid content-wrapper cluster_container mob-right-part span10">
  <div class="hero-unit">
    <h3 class="title">Event Edit</h3>
    
    <!--<span id=menu_msg></span>-->
    <?php 
  foreach($event as $event){
		  $attr=array('class'=>'edit_form white_bg');
 echo form_open_multipart($site.'edit_event/'.$this->uri->segment(4),$attr)?>
    <input type="hidden" name="restaurant_id" value="<?php echo $event->ID;?>" />
    <div class="wit">
      <label>Date</label>
      <span data-language="javascript" class="datepair">
      <input type="text" class="date start" name="start_date" value="<?php echo $event->start_date; ?>">
      <input type="hidden" class="time start ui-timepicker-input" value="<?php echo $event->start_time; ?>" autocomplete="off" name="start_time">
      to
      <input type="hidden" class="time end ui-timepicker-input" value="<?php echo $event->end_time; ?>" autocomplete="off" name="end_time">
      <input type="text" class="date end" value="<?php echo $event->end_date; ?>" name="end_date">
      </span> <?php echo form_error('start_date'); ?> <?php echo form_error('start_time'); ?> <?php echo form_error('end_time'); ?> <?php echo form_error('end_date'); ?></div>
    <div class="wit">
      <label>Title</label>
      <input type="text" name="event_title" value="<?php echo $event->event_title; ?>" />
      <?php echo form_error('event_title'); ?></div>
    <div class="wit">
      <label>Description</label>
      <textarea name="event_description" id="content" ><?php echo $event->event_description; ?></textarea>
      <?php echo display_ckeditor($ckeditor); ?> <br />
      <?php echo form_error('event_description'); ?></div>
    <div class="wit">
      <label>Vanue</label>
      <?php /*?> <input type="text" name="event_vanue" value="<?php echo $event->event_vanue; ?>" /><?php */?>
      <textarea name="event_vanue" ><?php echo $event->event_vanue; ?></textarea>
      <?php echo form_error('event_vanue'); ?></div>
    <div class="wit">
      <label>Event Image</label>
       <input type="file" name="userfile1"  />
      <?php if(!empty($error))echo $error; ?>
     
              <?php
foreach($event_photo as $photo)
{?>
         <div id="<?php echo $photo->event_photo_id; ?>" class="show_image_tag">
                  <div class="mediaholder_innerwrap"> <img style="height:150px; width:100%;" alt="" src="<?=base_url().'uploadimages/events/'.$photo->image;?>" ></div>
                 <div class="detailholder">
                  <h4 class="showbiz-title txt-center delete_btn"><a class="login-btn" href="javascript:void(0)"  onclick="delete_image(<?php echo $photo->event_photo_id; ?>)">Delete</a></h4>
                </div>
              
              <?php } ?>
         
    </div>
    <div class="wit">
      <label>Active</label>
      <span class="radio-active">Yes</span>
      <input type="radio" name="active" <? if($event->active=='1')echo 'checked="checked"';?> value="1" />
     <span class="radio-active">No</span>
      <input type="radio" name="active" <? if($event->active=='0')echo 'checked="checked"';?>  value="0" />
    </div>
    <div id="sub_btn">
      <input class="login-btn" type="submit"  value="Submit" />
      <a href="<?php echo $site;?>">
      <input class="login-btn" type="button"  value="Cancel" />
      </a> </div>
    </form>
    <?php }?>
  </div>
</div>
</div>
</div>
</div>
</div>

