<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$site=site_url().'owner/home/edit_retaurant/'.$this->session->userdata('restaurant_id');
$address=base_url().'uploadimages/submitted_gallery/';
?>
<script>
$(document).ready(function(){
$('#pagination .active').html('<a href="<?=site_url().'owner/gallery/index'?>">1</a>');
$("#pagination a:last").remove();	
	});
	
	function delete_photo(photo_id){
		
		var r=confirm('Are Sure Delete This Menu');
if (r==true)
	{
	var form_data = {
		gallery_image_id:photo_id
		  };
    $.ajax({
       url:'<?=site_url().'owner/gallery/delete_photo'?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		  $('#delete_photo_'+photo_id).remove();
       }
     });
}

		
	}
</script>

<div class="container">
  <div class="hero-unit">
  
   <?php include('edit_resturant_header.php') ?>
    <h3 id="menu_update">  </h3>
<div class="heading">
  <h3>Photo Gallery</h3>
</div>
<div class="row-fluid">
  <?php 
  if($photo)
  {
    foreach($photo as $photo)
    { ?>
  <div class="delete_photo" id="delete_photo_<?=$photo->gallery_image_id?>"> <a class="fancybox fancybox.ajax" href="<?=site_url().'owner/gallery/show_photo/'.$photo->gallery_image_id?>"><img src="<?=$address.'thumimage/'.$photo->thumb_image_url?>"/></a> <span class="clear_both"><a onclick="delete_photo(<?=$photo->gallery_image_id?>)" href="javascript:void(0)">delete</a></span> </div>
  <?php 
    }
  }else{echo '<div class="error"><h4>No Data Found</h4></div>';}?>
</div>
</div></div>
<?php echo $links;?> 