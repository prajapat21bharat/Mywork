<?php $site=site_url().'owner/menu_categories/'; ?>
<script type="text/javascript">
  $().ready(function() {
	  
	$("#select1").change(menu_categories_val);
    menu_categories_val();
   
   
   
   $('#add_new_menu_categories').click(function() {
	  var menu_cate_name= $('#menu_cate_add').val();
	   if(menu_cate_name!='')
	   {
	    var form_data = {
          menu_cate_name: menu_cate_name,
		  menu_id:$('#select1 option:selected').val(),
		  restaurant_id:'<?php echo $this->session->userdata('restaurant_id'); ?>'
	     };
	    $.ajax({
          url:'<?php echo $site.'add_menu_categories';?>',
            data:form_data,    
              datatype:'json',
                success:function(data){
					$('#menu_cate_add').val("");
				 $('#select2').append('<option value='+data+'>'+menu_cate_name+'</option>');
				 $('#menu_msg').html('Success Fully Add  Menu')
			   }//End Success
	      }); //End Ajax
	  } //End If
	  else{
		  $('#menu_msg').html('Plz Enter Menu Name')
		  }
	  
   });
   
   
   
   
  });
  
  
function menu_categories_val() {
	
				
		var form_data = {
			   menu_id:$("#select1").val(),
			   restaurant_id:'<?php echo $this->session->userdata('restaurant_id'); ?>'
			 };
			$.ajax({
			  url:'<?php echo $site.'get_menu_categories';?>',
				data:form_data,    
				  datatype:'json',
					success:function(data){
						$("#select2").empty();
						
					var newdata=jQuery.parseJSON(data);
					 $.each(newdata,function(i,index){
					 htmlString="<option value='"+index['restaurant_menu_item_id']+"'>"+index['menu_categorie_name']+"</option>"
					 $("#select2").append(htmlString);
					   });
				   }//End Success
			  }); //End Ajax
		}
  
  
  
  
  
 </script>

<div class="container">
  <div class="hero-unit"> 
   <?php include('edit_resturant_header.php') ?>
    <h4>Menu Categories :</h4>
    <?php echo form_open() ?>
    <div style="float:left">
      <select id="select1" >
        <?php  foreach($menus as $menus){?>
        <option value="<?=$menus->menu_id;?>">
        <?=$menus->menu_name;?>
        </option>
        <?php }?>
      </select>
      <br />
    </div>
    <div style="float:left">
      <select multiple id="select2" name="select_menu[]" style="height:200px">
      </select>
      <br />
      <?php /*?>  <a href="javascript:void(0)" id="remove">&lt;&lt; remove</a><?php */?>
    </div>
    </form>
    <div style="clear:both"> <span id=menu_msg></span><br />
      <?php echo form_open() ?>
      <h3>Add New Menu Categories</h3>
      <input type="text"  value="" id="menu_cate_add" />
      <input class="btn btn-primary btn-large" id="add_new_menu_categories" type='button' value="Submit" />
      </form>
    </div>
  </div>
</div>
