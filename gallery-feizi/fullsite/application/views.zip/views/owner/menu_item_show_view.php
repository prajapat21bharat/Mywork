<?php $site=site_url().'owner/menu_item/'; ?>

<script type="text/javascript">

function menu_item_delete(id)
{
var r=confirm('Are Sure Delete This Menu');
if (r==true)
	{
	var form_data = {
		 menu_item_id:id
		  };
    $.ajax({
       url:'<?php echo $site.'delete_sub_menu';?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		  $('#'+id).hide();
		  $('#msg').html('Menu Successfully Deleted!');
       }
     });
}

}
function active(value,menu_item_id)
{

var form_data = {
		 active:value,
		 menu_item_id:menu_item_id
		  };
    $.ajax({
       url:'<?php echo $site.'active_inactive';?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		   
		   if(data!='1')
		   {
			   
            $('#actve_deactive_'+menu_item_id).html("<a title='Enable' onclick='active(1,"+menu_item_id+")' href='javascript:void(0)'><img src='<?php echo base_url().'assets/img/btn-red1.png'?>'/></a>");
			   
		   }else{
			       $('#actve_deactive_'+menu_item_id).html("<a title='Enable' onclick='active(0,"+menu_item_id+")' href='javascript:void(0)'><img src='<?php echo base_url().'assets/img/btn-green.png'?>'/></a>");
		   }
		  
		
       }
     });


}
//$(document).ready(function(){
//$('#pagination .active').html('<a href="<?php echo $site; ?>">1</a>');
//$("#pagination a:last").remove();
//	});
	
	$(function(){	
$('#pagination .active').html('<a href="0">1</a>');
$("#pagination a:last").remove();
var val_loc=window.location;

var arr = String(val_loc).split("/");
var size=arr.length-1;

if(arr[size])
{
	var par_page='<?php echo $per_page; ?>';
	var page=Math.ceil(arr[size]/par_page)+1;
	$("#pagination >li.active").removeClass("active");
	$("#pagination li:nth-child("+page+") a ").addClass("active");

}
});
</script>
<div class="container-fluid main-container">
<div class="row-fluid">
<div class="span12">
 <?php $this->load->view('owner/edit_resturant_header.php') ?>
<div class="container-fluid content-wrapper cluster_container mob-right-part span10">
<div class="hero-unit">
 <h3 class="title">Menu Item List</h3>
 <div class="back_color white_bg">
<div id="msg"></div>
<a class="add_restaurant_btn" href="<?php echo $site.'add_menu' ?>">Add New Menu Item</a>
<a class="add_restaurant_btn" href="<?php echo $site.'menu_sort' ?>">Sort Menu</a>
<a class="add_restaurant_btn" href="<?php echo $site.'menu_upload' ?>">Upload Menu</a>
<?php if(!empty($menu_items)){?>	
<table width="100%" class="table table-striped table-bordered table-radmin">
   <thead>
      <tr>
      
         <th width="">Name</th> 
         <th width="">Menu categories</th>    
         <th width="">Menu</th>
         <th width="">Action</th>
      </tr>
   </thead>
 	
   <?php foreach ($menu_items as $menu): ?>
      <tr id='<?php echo $menu->menu_item_id ; ?>'>
          <td><a href="<?php echo $site.'edit_menu/'.$menu->menu_item_id; ?>"><?php echo $menu->title; ?></a></td>
          <td><?php echo $menu->menu_categorie_name; ?></td>
         <td><?php echo $menu->menu_name;?></td>
         <td>
                
         <?php if($menu->active==1){
			 $active="\"Enable\"";
			$dactive="\"Disable\"";
			
			
			  echo "<span  id='actve_deactive_$menu->menu_item_id'><a title='Disable' onclick='active(0,$menu->menu_item_id)' href='javascript:void(0)'><img src='".base_url()."assets/img/btn-green.png'  /></a></span>";
			 
		}else{
			echo  "<span id='actve_deactive_$menu->menu_item_id'><a title='Enable'  onclick='active(1,$menu->menu_item_id)' href='javascript:void(0)'><img src='".base_url()."assets/img/btn-red1.png' /></a></span>"; 
             } ?>
             |
         <a  href="<?php echo $site.'edit_menu/'.$menu->menu_item_id; ?>">
        <img src="<?php echo base_url().'uploadimages/site_image/edit.png';?>"/></a> | 
        <a  href="javascript:void(0)" onclick="menu_item_delete(<?php echo $menu->menu_item_id; ?>)">
        <img src="<?php echo base_url().'uploadimages/site_image/delete.png';?>"/></a>
        </td>
         
    
        </tr>
   <?php endforeach;?>
   
</table>

<?php } else{ echo '<div class="error data"><h4>No Data Found</h4></div>'; }
 echo $links;?>
</div>
</div>
</div>

</div>
</div>
</div>