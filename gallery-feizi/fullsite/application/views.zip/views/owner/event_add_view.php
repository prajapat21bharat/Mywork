<?php $site=site_url().'owner/event/'; ?>
<script type="text/javascript">

$(function() {
			$('#basicExample').timepicker();
		  });
 
 function add_photo()
{ 
	var id=$('#counter').val();
	photo='<input type="file" name="userfile'+id+'" value=""  /><br>';	
	  $('#counter').val(Number(id)+1)
	  $('#more_photo').append(photo);
	
}
 </script>

<div class="container-fluid main-container">
<div class="row-fluid">
<div class="span12">
<?php $this->load->view('owner/edit_resturant_header.php') ?>
<div class="container-fluid content-wrapper cluster_container mob-right-part span10">
  <div class="hero-unit">
    <h3 class="title">Add New  Event </h3>
    <div class=""> 
      <!--<span id=menu_msg></span>-->
      
      <form method="post" class="edit_form white_bg" id="validation" accept-charset="utf-8" enctype="multipart/form-data" action="<?php echo $site.'add_event';?>">
        <input type="hidden" name="restaurant_id" value="<?php echo $this->session->userdata('restaurant_id');?>" />
        <div class="wit">
          <label>Date</label>
          <span data-language="javascript" class="datepair">
          <input type="text" class="date start " name="start_date"  value="<?php echo set_value('start_date'); ?>">
          <input type="hidden" class="time start ui-timepicker-input" value="12:00am" <?php /*?>value="<?php echo set_value('start_time'); ?>"<?php */?> autocomplete="off" name="start_time">
          to
          <input type="hidden" class="time end ui-timepicker-input " value="11:59pm" <?php /*?>value="<?php echo set_value('end_time'); ?>"<?php */?> autocomplete="off" name="end_time">
          <input type="text" class="date end " value="<?php echo set_value('end_date'); ?>" name="end_date">
          </span> <?php echo form_error('start_date'); ?> <?php echo form_error('start_time'); ?> <?php echo form_error('end_time'); ?> <?php echo form_error('end_date'); ?></div>
        <div class="wit">
          <label>Title</label>
          <input type="text" name="event_title" value="<?php echo set_value('event_title'); ?>" />
          <?php echo form_error('event_title'); ?></div>
        <div class="wit">
          <label>Description</label>
          <textarea name="event_description" id="content" ><?php echo set_value('event_description'); ?>
    </textarea>
          <?php echo display_ckeditor($ckeditor); ?> <br />
          <?php echo form_error('event_description'); ?></div>
        <div class="wit">
          <label>Vanue</label>
          <?php /*?><input type="text" name="event_vanue" value="<?php echo set_value('event_vanue'); ?>" /><?php */?>
          <textarea name="event_vanue" ><?php echo set_value('event_vanue'); ?></textarea>
          <?php echo form_error('event_vanue'); ?></div>
        <div class="wit">
          <label>Event Image</label>
          <input type="file" name="userfile1"  />
          <?php echo form_error('userfile1'); ?> </div>
        <div class="wit">
          <label>Active</label>
          <span class="radio-active">Yes</span>
          <input type="radio" name="active" checked="checked" value="1" />
          <span class="radio-active">No</span>
          <input type="radio" name="active"  value="0" />
        </div>
        <div id="sub_btn">
          <input class="login-btn" type="submit"  value="Submit" />
          <a href="<?php echo $site;?>">
          <input class="login-btn" type="button"  value="Cancel" />
          </a> </div>
      </form>
    </div>
  </div>
</div>
</div>
</div>
</div> 