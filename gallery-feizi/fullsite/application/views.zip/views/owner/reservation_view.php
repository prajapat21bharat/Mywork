<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

<div class="container-fluid main-container">
<div class="row-fluid">
<div class="span12">
 <?php $this->load->view('owner/edit_resturant_header.php') ?>
<div class="container-fluid content-wrapper cluster_container mob-right-part span10">

  <div class="hero-unit">
 
    <h3 class="title">Restaurant Reservation</h3>
  <div class="">
    <div id="hide_form" >
      <?php 
	  if(!empty($success_msg)){
		  ?><div id="msg"><?php echo $success_msg;?></div> <?php
		  }
	  
   		$val=array('class'=>'edit_form white_bg reser_wrapp');
     echo form_open(site_url().'owner/reservation/',$val); 
	 
	 ?>
      <div id="disp" class="error"></div>
      <label>Restaurant Reservation Link </label>
      <textarea name="reservation_link" id="reservation_link"><?php if(!empty($reservation)){foreach($reservation as $reservation){echo $reservation->reservation_text;}}?>
</textarea>
      <span id="reservation_link"> <?php echo form_error('reservation_link'); ?></span>
      <div id="sub_btn">
      <input type="submit"  name="reservation" value="Save" class="login-btn" id="reservation"/>
      </div>
      <?php echo form_close();
 	   ?> </div>
  </div>
</div>
