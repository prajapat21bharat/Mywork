<div class="container-fluid main-container">
<div class="row-fluid">
<div class="span12">
<?php $this->load->view('owner/edit_resturant_header.php') ?> 
<div class="container-fluid content-wrapper mob-right-part span10">
  <div class="hero-unit">
   <h3 class="title"><?php echo $this->session->userdata('restaurant_name'); ?></h3>
    <div class="back_color white_bg">
  <div><a class="add_restaurant_btn active" href="<?php echo site_url().'owner/home/edit_retaurant/'.$this->session->userdata('restaurant_id'); ?>">Edit</a></div>
 <iframe width="100%" height="1300px" frameborder="0" src="<?php echo site_url().$rest_id ;?>"></iframe>
</div>
</div>
</div>
</div>
</div>
</div>
