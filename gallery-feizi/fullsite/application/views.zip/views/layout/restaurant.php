<?=$this->load->view('layout/header.php') ?>

<?php $slider=base_url().'assets/slider/';

 $slider_n=base_url().'assets/new_slider/';

?>

<link rel="stylesheet" type="text/css" href="<?=$slider?>index_data/preview.css" media="screen">

<link rel="stylesheet" type="text/css" href="<?=$slider?>index_data/settings.css" media="screen">

<link rel="stylesheet" href="<?php echo base_url().'assets/slider/'?>index_data/jquery.css" type="text/css" media="screen">

<link rel="stylesheet" href="<?php echo base_url('assets/css/responsiveslides.css') ?>">

<link rel="stylesheet" href="<?php echo base_url('assets/css/demo.css') ?>">

<script type="text/javascript">



	jQuery(document).ready(function() {



	$("a#single_image").fancybox();

	

	

	if('<?=$this->session->userdata('user_name')?>'){

	var form_data = {

	restaurant_id:'<?=$this->session->userdata('restaurant')?>',

	user_id:'<?=$this->session->userdata('user_name')?>'

       };

		$.ajax({

			   url:'<?=site_url().'restaurant/get_favorite';?>',

			   data:form_data,    

			   datatype:'json',

			   success:function(data){

				 var newdata= jQuery.parseJSON(data);

		       $.each(newdata,function(i,index){

				   if(index['favorite']=='1')

				   {

					   $('.add_favc_butto').html('<a href="javascript:void(0)" onclick="favroritres(0)">Remove from Favorites</a>');

				  

				   }else{

					   $('.add_favc_butto').html('<a href="javascript:void(0)" onclick="favroritres(1)">Add to Favorites</a>');

					   }

				   

			 });

				   

			   }

		});

		

		var form_data = {

	restaurant_id:'<?=$this->session->userdata('restaurant')?>',

	user_id:'<?=$this->session->userdata('user_name')?>'

       };

		$.ajax({

			   url:'<?=site_url().'restaurant/subscribe_detail';?>',

			   data:form_data,    

			   datatype:'json',

			   success:function(data){

				 if(data==1)

				 $('#subscribe_delais_butto_1').prop("checked", true);

				 else

				 $('#subscribe_delais_butto_0').prop("checked", true);

			   }

		});

		

	}

		

	});

	

	

	

	if('<?=$this->session->userdata('user_name')?>'){

	function favroritres(id)

{ 

	var form_data = {

    value: id,

	restaurant_id:'<? echo $this->session->userdata('restaurant')?>'

       };

		$.ajax({

			   url:'<?=site_url().'restaurant/favorite2';?>',

			   data:form_data,    

			   datatype:'json',

			   success:function(data){

				 if(id==1){

				 $('.add_favc_butto').html('<a href="javascript:void(0)" onclick="favroritres(0)">Remove from Favorites</a>');

				 $("#myModal").modal('show');

				 $('#favriots_model').html("Thank You. You have successfully added <?php echo $restaurant[0]->restaurant_name ?>  to your favorites!!");

				 

				 }else{

					  $('.add_favc_butto').html('<a href="javascript:void(0)" onclick="favroritres(1)">Add to Favorites</a>');

					  $("#myModal").modal('show');					 

					$('#favriots_model').html("You have successfully removed <?php echo $restaurant[0]->restaurant_name ?> from your favorites.");

					 }

			   }

		});

}

	}

</script>

<script type="text/javascript">

 <?php if($restaurant[0]->restaurant_type!='Basic'){ ?>

function pageval(val){

	

	$('.active').removeClass("active");

	$('.active1').removeClass("active1");

	if(val=='menu'){$("#"+val+"_page").attr("class","active1");}

	else{$("#"+val+"_page").attr("class","active");}

	var form_data = {values:val,restaurant_id:"<?php echo $this->uri->segment(3);?>"};

	$.ajax({

	   url:'<?=site_url().'restaurant/';?>'+val,

	   data:form_data,    

	   datatype:'json',

	   success:function(data){

		if(data=='error'){ $('#pagedata').html('<div class="row-fluid resevent"><div class="error"><h4>Sorry, there is no data for this restaurant listing.</h4></div></div>');}

		else{   

	   $('#pagedata').html(data);

		}

	   }

  });

}

<?php }else{ ?>

function pageval(val){

	$('.active').removeClass("active");

	$('.active1').removeClass("active1");

	if(val=='menu'){$("#"+val+"_page").attr("class","active1");}

	else{$("#"+val+"_page").attr("class","active");}

	 $('#pagedata').html('<div class="error"><h4>Currently restaurant has no details for selected option.</h4></div>');

}



 <?php }?>

 

 

function subscribe(val){

	

	var form_data = {value:val,restaurant_id:"<?php echo $this->session->userdata('restaurant')?>"};

	$.ajax({

	   url:'<?=site_url().'restaurant/subscribe';?>',

	   data:form_data,    

	   datatype:'json',

	   success:function(data){ 

	   if(data=='phone no.')

	   {

		 $('#phone_no').show();

		 

	   }else if(data=='1')

	   {

		    $('#subscribe_msg').html('Successfully Add your Phone No.');

			$('#myModal').modal('hide') 

	   }else if(data=='0'){

		   $('#subscribe_msg').html('Successfully Remove your Phone No.');

		   $('#myModal').modal('hide') 

		   

		   }

	   }

	});

}

 

 function enter_phone()

{

	var form_data = {phone:$('#subscribe_phone').val()};

	$.ajax({

	   url:'<?=site_url().'restaurant/subscribe_phone';?>',

	   data:form_data,    

	   datatype:'json',

	   success:function(data){ 

	   $('#phone_no').hide();

	   $('#subscribe_delais_butto_1').prop('checked', false);

	   $('#subscribe_delais_butto_0').prop('checked', false);

	   $('#subscribe_msg').html('Please Select Subscribe For Notification');

	   }

	});

	

}



</script>

<!--main-content-->



<div id="main-content" class="page_resturent">

  <?php $navigation=site_url().'restaurant/'; ?>

  <div class="row-fluid">

    <div class="span12" >

      <div id="home-slider">

        <div class="content resturent_add">

          <div id="res_info">

            <label><?php echo $restaurant[0]->restaurant_name ?></label>

            <span><?php echo $city[0]->city.' , '.$state[0]->state; ?></span></div>

          <div id="contct">

            <label>Contact us</label>

            <span><?php echo $restaurant[0]->restaurant_address.'<br> '.$restaurant[0]->city.', '.$restaurant[0]->state_id." ".$restaurant[0]->zip_code; ?></span><br />

            <span><?php echo $restaurant[0]->restaurant_phone; ?></span></div>

        </div>

        <div id="wrapper"> 

          

          <!-- Slideshow 1 -->

          <ul class="rslides" id="slider1">

            <?php

if(!empty($header_photo)){



foreach($header_photo as $photo)  

{?>

            <li><img style="height:104px; width:100%;" alt="" src="<?php echo base_url().'/uploadimages/header_banner/'.$photo->h_image; ?>" > </li>

            <?php } }else{ ?>

            <li><img style="height:104px; width:100%;" alt="" src="<?php echo base_url().'/uploadimages/header_banner/slider1.jpg'; ?>" > </li>

            <?php }



  ?>

          </ul>

          <div class="rest_type"> <img src="<?php echo base_url().'uploadimages/restaurant_type/'.$restaurant[0]->restaurant_type .'.png';?>" /> </div>

          <div class="slideman"><img src="<?php echo base_url().'uploadimages/files/'.$restaurant[0]->restaurant_logo ?>" /> </div>

        </div>

        <?php if($restaurant[0]->restaurant_type!='Basic'){

		  

		  $site=$restaurant[0]->restaurant_website;

		  $mobile=$restaurant[0]->mobile_app_url;

		  $facebook=$restaurant[0]->restaurant_facebook_url;

		  $twitter=$restaurant[0]->restaurant_twitter_url; ?>

        <div class="row-fluid add_action">

          <div class="span2"> <a onclick="Getdirection()" style="cursor:pointer;" id="dir" >Get Directions</a></div>

          <div class="span2">

            <div class="butn"><a target="_new" href="http://<?=$site?>">Visit Website</a></div>

          </div>

          <div class="span2">

            <div class="mobileapp"> <a class="fancybox fancybox.ajax" href="<? echo site_url().'restaurant/sms_from?app_url='.$mobile?>">Get the Mobile App</a> </div>

          </div>

          <div class="span2">

            <div id="add" class="pull-right add_favc_butto">

              <?php if($this->session->userdata('user_name')!=''){ ?>

              <a href="javascript:void(0);" onclick="favroritres(1)">Add to Favorites</a>

              <?php }else{ ?>

              <a href="<?php echo $navigation.'favorite'?>" class="fancybox fancybox.ajax">Add to Favorites</a>

              <? }?>

            </div>

          </div>

          <div class="span2">

            <div class="icons">

              <ul>

                <li class="first"><a target="_new" href="http://<?=$facebook?>">fb-icon</a></li>

                <li class="last"><a target="_new" href="http://<?=$twitter?>">twit-icon</a></li>

              </ul>

            </div>

          </div>

        </div>

        <?  }?>

      </div>

    </div>

  </div>

</div>

<div class="container main1">

  <div class="row-fluid contain1">

    <div class="span12">

      <div class="index">

        <div class="tab">

          <ul>

            <li><a id="menu_page" onclick="pageval('menu')" href="javascript:void(0)">Menu</a></li>

            <li><a id="offer_page" onclick="pageval('offer')" href="javascript:void(0)">Special Offers</a></li>

            <li><a id="events_page" onclick="pageval('events')" href="javascript:void(0)">Events</a></li>

            <li><a id="rest_gallery_page"   onclick="pageval('rest_gallery')" href="javascript:void(0)">Gallery</a></li>

            <li class="last" ><a  id="reservations_page" href="javascript:void(0)" onclick="pageval('reservations')"> Reservations</a></li>

          </ul>

        </div>

        <div class="tabcontain" id="pagedata">

          <?=$content_for_layout?>

        </div>

      </div>

    </div>

  </div>

</div>

<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">

  <div class="modal-dialog">

    <div class="modal-content">

      <div class="modal-header">

        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>

        <h4 class="modal-title" id="favriots_model"> </h4>

      </div>

      <div class="modal-body">

        <h4>Subscribe For Notification</h4>

        <span id="subscribe_msg"></span>

        <div class="subscribe_model_btn">

        <input type="radio" name="subscribe" id="subscribe_delais_butto_1" onclick="subscribe(1)" value="1" />

        <span>Yes</span>

        <input type="radio" name="subscribe" id="subscribe_delais_butto_0" onclick="subscribe(0)" value="0" />

        <span>No</span>

        </div>

        <div id="phone_no" style="display:none"> <span>Please Enter your phone no</span>

          <input type="text" name="phone" id="subscribe_phone" value="" />

          <input class="login-btn" type="button" value="Submit" onclick="enter_phone()" />

        </div>

      </div>

    </div>

  </div>

  <!-- /.modal-content --> 

</div>

<!-- /.modal-dialog -->

</div>

<!-- /.modal --> 



<?php

$arrayReplace = array(',',$restaurant[0]->city,$restaurant[0]->state_id,$restaurant[0]->zip_code);

$value_add=trim(str_replace($arrayReplace,"", $restaurant[0]->restaurant_address));





$arrayReplace = array(' ', ',');

$arrayReplacewith = array('_', '+','','','');

$url=base_url().'restaurant/getDirection/'.str_replace($arrayReplace,$arrayReplacewith,$value_add);

?>

<script>





function Getdirection(){

	parent.$.fancybox.open({href : "<?php echo $url; ?>", type: 'iframe',height: 800, width: 500,scrolling : 'no'});

}

</script>

<?php if($header_photo){

	?>

<script src="<?php echo base_url('assets/js/responsiveslides.min.js') ?>"></script> 

<script>

    // You can also use "$(window).load(function() {"

    $(function () {



      // Slideshow 1

      $("#slider1").responsiveSlides({

		  Next: "#showbiz_right_1",

           Previous: "#showbiz_left_1",

		  auto: 800,

          speed: 500,

	       

       

      });

    });

	</script>

<?php }?>

<script type="application/javascript">

    function getProducts(City,State){

	$.post("<?php echo base_url();?>home/ajaxHome",{State:State,City:City},function(data){

	 

	 $('#restaurant_result').html(data)

	 

	 });

    

	}

    </script> 


<!-- Piwik -->
<script type="text/javascript">
  var _paq = _paq || [];
  _paq.push(["trackPageView"]);
  _paq.push(["enableLinkTracking"]);

  (function() {
    var u=(("https:" == document.location.protocol) ? "https" : "http") + ":<?php echo str_replace("http:","","http://www.apetizr.com/");?>//analytics/";
    _paq.push(["setTrackerUrl", u+"piwik.php"]);
    _paq.push(["setSiteId", "<?php echo $this->session->userdata('restaurant'); ?>"]);
    var d=document, g=d.createElement("script"), s=d.getElementsByTagName("script")[0]; g.type="text/javascript";
    g.defer=true; g.async=true; g.src=u+"piwik.js"; s.parentNode.insertBefore(g,s);
  })();
</script>
<!-- End Piwik Code -->

<?php /*?><!-- Piwik --> 
<script type="text/javascript">

  var _paq = _paq || [];

  _paq.push(["setDocumentTitle", document.domain + "/" + document.title]);

  _paq.push(["setCookieDomain", "*.103.21.53.250"]);

  _paq.push(["setDomains", ["*.103.21.53.250"]]);

  _paq.push(["trackPageView"]);

  _paq.push(["enableLinkTracking"]);



  (function() {

    var u=(("https:" == document.location.protocol) ? "https" : "http") + "://103.21.53.250/apetizr//analytics/";

    _paq.push(["setTrackerUrl", u+"piwik.php"]);

    _paq.push(["setSiteId", "<?php echo $this->session->userdata('restaurant'); ?>"]);

    var d=document, g=d.createElement("script"), s=d.getElementsByTagName("script")[0]; g.type="text/javascript";

    g.defer=true; g.async=true; g.src=u+"piwik.js"; s.parentNode.insertBefore(g,s);

  })();

</script> 

<!-- End Piwik Code --> 
<?php */?>


<!---Page----->



</div>

<!-- end main-content-->

</div>

<!-- end main--> 



<!--footer-->

<? $this->load->view('layout/footer.php') ?>

<!--end footer--> 

