<?php echo $this->load->view('layout/header.php') ?>
<link rel="stylesheet" href="<?php echo base_url().'assets/slider/'?>index_data/jquery.css" type="text/css" media="screen">
<link rel="stylesheet" href="<?php echo base_url('assets/css/responsiveslides.css') ?>">
<link rel="stylesheet" href="<?php echo base_url('assets/css/demo.css') ?>">
<script src="<?php echo base_url('assets/js/responsiveslides.min.js') ?>"></script>
<script>
    // You can also use "$(window).load(function() {"
    $(function () {

      // Slideshow 1
      $("#slider1").responsiveSlides({
        speed: 800
      });
    });
	</script>
  <!--home slider-->
  <div id="home-slider">
    <div id="wrapper"> 
      
      <!-- Slideshow 1 -->
      <ul class="rslides" id="slider1">
        <li><img src="<?php echo base_url().'assets/images/slid1.png'; ?>" alt=""></li>
        <li><img src="<?php echo base_url().'assets/images/slid2.png'; ?>" alt=""></li>
        <li><img src="<?php echo base_url().'assets/images/slid3.png'; ?>" alt=""></li>
        <li><img src="<?php echo base_url().'assets/images/slid4.png'; ?>" alt=""></li>
      </ul>
    </div>
    
    <!--search part-->
    <div class="container search-block">
      <div class="row-fluid">
        <div class="span12">
          <div class="search-rest">
            <div class="row-fluid">
              <div class="serch-txt">
                <p>Search Restaurants </p>
              </div>
            </div>
            <div class="row-fluid">
              <div class="search-box">
                <form action="<?php echo site_url().'search/search_name'; ?>">
                  <input type="text" name="name" id="search_name" class="search" value="" placeholder="Search by restaurant name">
                  <a href="javascript:void(0)">
                  <input type="submit" class="submit">
                  </a> 
                  <!--<a href="#main-content"><input type="submit" onClick="search_name()" class="submit"></a>-->
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--end search part--> 
    
  </div>
  <!--end home slider--> 
  <div class="bottom_slide_img">
  <img src="<?php echo base_url().'assets/images/hr_line.png'; ?>" alt="" border="0">
  </div>
  
  <!--how it works-->
  <div id="how">
    <div class="container">
      <div class="row-fluid">
        <div class="how-text">
          <h5>Put Apetizr to Work for You</h5>
        </div>
      </div>
      <div class="row-fluid how-wrap">
        <div class="span4">
          <div class="row-fluid">
            <div class="span12">
              <div class="how-left"><a href="<?php echo site_url().'blog'; ?>"> <img src="<?php echo base_url().'assets/images/how1.png'; ?>" alt="" border="0"> </a></div>
            </div>
            <div class="span12">
              <div class="how-rt">
                <h6><a href="<?php echo site_url().'blog'; ?>">Local Events</a></h6>
                <p>Stay up to date on the hottest events in your area with real-time updates and schedule changes for your favorites. </p>
            
              </div>
            </div>
          </div>
        </div>
        <div class="span4">
          <div class="row-fluid">
            <div class="span12">
              <div class="how-left"><a href="<?php echo site_url().'special_offer/#Offer'; ?>"><img src="<?php echo base_url().'assets/images/how2.png'; ?>" alt="" border="0"></a> </div>
            </div>
            <div class="span12">
              <div class="how-rt">
                <h6><a href="<?php echo site_url().'special_offer/#Offer'; ?>">Special Offers</a></h6>
                <p>Never miss out on the best special offers from restaurants you've saved in your favorites. </p>    <div class="special_toogel" style="display:none"><p>With apetizr.com, there are two ways you can stay up to date. You can subscribe to Apetizr.com 
                      and we'll send you messages about all of the best events coming in your area as they come up. </p>
                         <p> Once you have created your own profile you can save individual restaurants to your favorites and 
                         even subscribe to individual restaurants and get only messages specific to the restaurants you know and love.</p>
                         <p>You can also check back frequently and click on the Local Events tab to get information in your area.</p>
                  </div><a href="javascript:void(0)" id="special_offer">Read More…..</a>
                 
              </div>
            </div>
           </div>
                   
        </div>
        <div class="span4">
          <div class="row-fluid">
            <div class="span12">
              <div class="how-left"> <a href="<?php echo site_url().'mobile_apps/#Apps'; ?>"><img src="<?php echo base_url().'assets/images/how3.png'; ?>" alt="" border="0"></a> </div>
            </div>
            <div class="span12">
              <div class="how-rt">
                <h6><a href="<?php echo site_url().'mobile_apps/#Apps'; ?>">Mobile Apps</a> </h6>
                <p>Get mobile apps for each of your favorite restaurants sent directly to your mobile phone, powered by Apetizr.com.<br/></p>
                     <div class="mobile_toggel" style="display:none;"><p>Simply search for your favorite restaurant by name or location then go to that restaurant page.  Once you're there, you can save the restaurant to your favorites.</p>
                      <p> You can click on "Get the Mobile App" enter your phone number and a link to the mobile app for that restaurant will be sent directly to your phone.</p>
                       <p> We NEVER sell or give away your phone number. We ONLY use it to send you text message specific to the favorites you've saved. And we pay for the text message – not you.</p>
                     </div>  <a href="javascript:void(0)" id="mobile_app">Read More…..</a>
              </div>
               
            </div>
          </div>
          
        </div>
      </div>
    </div>
           
           
          
  </div>
  <!--how it works--> 
  <div class="bottom_featured_img">
  <img src="<?php echo base_url().'assets/images/shadow.png'; ?>" alt="" border="0">
  </div>
  <!--main-->
  <div id="main"> 
    <div class="container"> 
      <!--row-fluid-->
      <div class="row-fluid">
        <div class="span12">
          <div class="main-content" id="main-content">
            <?=$content_for_layout?>
          </div>
        </div>
        
      </div>
      <!--end row-fluid--> 
    </div>
  </div>
  <!--end main--> 
  
  
   
  <script type="application/javascript">
    function getProducts(City,State){
	$.post("home/ajaxHome",{State:State,City:City},function(data){
	 
	 $('#restaurant_result').html(data)
	 
	 });
    
	}
    </script> 

<script>
$(document).ready(function(){
  $("#special_offer").click(function(){
	  	 var thisElem = $(this);
	    thisElem.text(thisElem.text() === "Close" ? "Read More....." : "Close");
        $(".special_toogel").toggle();
	
  });
    $("#mobile_app").click(function(){
		 var thisElem = $(this);
	    thisElem.text(thisElem.text() === "Close" ? "Read More....." : "Close");
    $(".mobile_toggel").toggle();

  });
  
});
</script>	
	<?php $this->load->helper('piwik');?>
	<?php echo piwik_tag(); ?>
    
   <!--footer--> 
  <? $this->load->view('layout/footer.php') ?>
  <!--end footer--> 