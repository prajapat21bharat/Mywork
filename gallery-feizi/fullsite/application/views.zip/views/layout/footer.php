<!--This function use to get city cluster-->

<?php /*?><script>

function clusters(state,city,ul_id){

	

	if($("#cluster_ul_"+ul_id).is(':empty')){

	$.ajax({

			type: "POST",

			url: "<?php echo site_url().'search/cluster'; ?>",

			data: {state:state,city:city}

			}).done(function( data ) {

			   var newdata= jQuery.parseJSON(data);

		     if(newdata!='')

		     {

			   $("#cluster_ul_"+ul_id).empty();

			    var html='';

                  $.each(newdata,function(i,index){

			        html = '<li><a href="<?php echo site_url().'search/city_cluster/';?>'+index['cluster_id']+'/">'+index['cluster_name']+'</a></li>';

				 

				  $("#cluster_ul_"+ul_id).append(html);

				  

				  });

				 

		   }else{$("#cluster_ul_"+ul_id).html('<li class="error">Sorry, No results found for the entered Search option..</li>'); }

			

			});

	}else{ $("#cluster_ul_"+ul_id).show();}

}	

</script><?php */?>

<!--END-->

<!--footer-->

<!--bottom block-->

<div id="bottom-block">
  <div class="container">
    <div class="row-fluid">
      <div class="browse-rest">
        <h6>Browse Restaurants by</h6>
      </div>
    </div>
    <div class="row-fluid">
      <div class="span3">
        <div class="block-bot popular_loctn">
          <h6>Popular Localities</h6>
          <ul>
            <li> <a  href="<?php echo base_url()?>search?state=Minnesota&city=Minneapolis&country_code=US&country_name=United States&/" >Minneapolis</a>
              <ul id="cluster_ul_1" class="cluster_ul">
              </ul>
            </li>
            <li><a href="<?php echo base_url()?>search?state=Minnesota&city=Saint Paul&country_code=US&country_name=United States&/" >St. Paul</a>
              <ul id="cluster_ul_2" class="cluster_ul">
              </ul>
            </li>
            
            <!--<li><a href="home/searchresult?state=Minnesota&city=Saint Paul" >St. Paul</a></li>-->
            
            <li><a  href="<?php echo base_url()?>search?state=Minnesota&city=Duluth&country_code=US&country_name=United States&/" >Duluth</a>
              <ul id="cluster_ul_3" class="cluster_ul">
              </ul>
            </li>
            <li><a  href="<?php echo base_url()?>search?state=Minnesota&city=Lake Elmo&country_code=US&country_name=United States&/" >Lake Elmo</a>
              <ul id="cluster_ul_4" class="cluster_ul">
              </ul>
            </li>
            <li><a  href="<?php echo base_url()?>search?state=Minnesota&city=Saint Cloud&country_code=US&country_name=United States&/" >St. Cloud</a>
              <ul id="cluster_ul_5" class="cluster_ul">
              </ul>
            </li>
            <li><a  href="<?php echo base_url()?>search?state=Minnesota&city=Mankato&country_code=US&country_name=United States&/" >Mankato</a>
              <ul id="cluster_ul_6" class="cluster_ul">
              </ul>
            </li>
          </ul>
          <div class="cluster_result" id="cluster_result"></div>
        </div>
      </div>
      <div class="span3">
        <div class="block-bot">
          <h6>Popular Cuisines</h6>
          <ul>
            <?php if(!empty($count_cuisines)){

				foreach($count_cuisines as $count_cuisines){?>
            <li><a href="<?php echo base_url()?>search/searchfoods?food=<?php echo $count_cuisines->restaurant_cuisines; ?>&/"><?php echo $count_cuisines->restaurant_cuisines .' ('.$count_cuisines->cuisines_count.')' ?></a></li>
            <?php } }?>
          </ul>
        </div>
      </div>
      <div class="span3">
        <div class="block-bot">
          <h6>By Budget (for two people)</h6>
          <ul>
            <li><a href="<?php echo site_url().'search/search_price/0/20'?>">Less than $20</a></li>
            <li><a href="<?php echo site_url().'search/search_price/20/40'?>">$20 to $40</a></li>
            <li><a href="<?php echo site_url().'search/search_price/40/75'?>">$40 to $75</a></li>
            <li><a href="<?php echo site_url().'search/search_price/75/100'?>">$75 to $100</a></li>
            <li><a href="<?php echo site_url().'search/search_price/100'?>">$100+</a></li>
          </ul>
        </div>
      </div>
      <div class="span3">
        <div class="block-bot">
          <h6>Popular Searches</h6>
          <ul>
            <li><a href="#">Restaurants serving Breakfast</a></li>
            <li><a href="#">Vegetarian Restaurants</a></li>
            <li><a href="#">Restaurants with WiFi</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>

<!--bottom block end-->

<div id="footer">
  <div class="container">
    <div class="copyright"><span>© 2013 APETIZR.COM All Rights Reserved</span>
      <div class="ficon pull-right">
        <ul>
          <li><a href="https://www.facebook.com/Apetizr" target="_blank" ><img src="<?php echo base_url();?>assets/images/fb.png" /></a></li>
          <li><a href="https://twitter.com/apetizr" id="login" target="_new"><img src="<?php echo base_url();?>assets/images/twitter.png" /></a></li>
          <li><a href="https://plus.google.com/" ><img src="<?php echo base_url();?>assets/images/gplus.png" /></a></li>
          <li><a href="http://www.youtube.com/"><img src="<?php echo base_url();?>assets/images/youtube.png" /></a></li>
        </ul>
      </div>
    </div>
  </div>
</div>

<!--end footer-->

</div>
</body></html>