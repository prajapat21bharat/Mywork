<!DOCTYPE html>

<html lang="en">

<head>

<meta http-equiv="Content-Type" content="text/html" charset="utf-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<meta name="description" content="">

<meta name="keywords" content="">

<meta name="author" content="">

<title><?php 

echo $title= (!empty($restaurant[0]->restaurant_name)) ? $restaurant[0]->restaurant_name : 'Apetizr';

?>

</title>

<link rel="shortcut icon" href="<?php echo base_url().'assets/images/favicon.ico';?>" type="image/x-icon" />

<link rel="apple-touch-icon" href="<?php echo base_url().'assets/images/favicon.ico';?>"/>

<link href="<?php echo base_url('assets/css/bootstrap.min.css') ?>" rel="stylesheet">

<link href="<?php echo base_url('assets/css/bootstrap.css') ?>" rel="stylesheet">

<link href="<?php echo base_url('assets/css/bootstrap-responsive.min.css') ?>" rel="stylesheet">

<link href="<?php echo base_url('assets/css/font-awesome.css') ?>" rel="stylesheet">

<link href="<?php echo base_url('assets/css/custom.css') ?>" rel="stylesheet">

<link href="<?php echo base_url('assets/css/flages.css') ?>" rel="stylesheet">

<script src="<?php echo base_url('assets/js/1.9.1.jquery.min.js') ?>"></script>

<script src="<?php echo base_url('assets/js/1.10.3.jquery-ui.min.js') ?>"></script>

<script src="<?php echo base_url('assets/js/1.2.1.lodash.min.js') ?>"></script>

<script src="<?php echo base_url('assets/js/bootstrap.min.js') ?>"></script>

<script src="<?php echo base_url('assets/js/custom.js') ?>"></script>

<script type="text/javascript" src="<?php echo base_url('assets/js/jquery.mousewheel-3.0.6.pack.js') ?>"></script>

<script type="text/javascript" src="<?php echo base_url('assets/js/jquery.fancybox.js?v=2.1.5') ?>"></script>



<script type="text/javascript">

$(document).ready(function() {

 $('.fancybox').fancybox();

  getall_state();

	});



function getall_state(){

	var form_data = {};

	$.ajax({

	   url:"<?php echo site_url().'home/countery_state';?>",

	    data:form_data,    

	     datatype:'json',

	     success:function(data){ 
		 //alert(data);

		    $('#countery_states_drop_down').html('<option><?php echo $this->session->userdata('city');?></option>');

	       $('#countery_states_drop_down').append(data); 

		 }

      });

}



function city_change_header(){

	var city=$('#countery_states_drop_down').val(); 

	window.location.replace(city);

	

	}





</script>



<script src="http://connect.facebook.net/en_US/all.js"></script>

<script>

//var FB_APPID = '{/literal}{$FB_APPID}{literal}';

$(document).ready(function() {

FB.init({
	    appId  : '535414506539291',

	    status : true, 

	    cookie : true, 

	    xfbml  : true

	  });



});



var accesstoken='';

var username='';

var name = '';

var id ='';

function FBlogin()  

{

	

	FB.login(function(response) {

	if (response.authResponse.accessToken) {

		$('#fbKey').val(response.authResponse.accessToken);

		accesstoken = response.authResponse.accessToken;

	}

	

	if (response.authResponse) {

		FB.api('/me', function(response) {

			id = response.message;

			username = response.username;

			name = response.name ;

		});

	}

	

 $("#facebook_info").addClass("facebook_login");



		FB.api('/me?fields=cover,name,picture', function(response) {

			var profHTML='';



      profHTML += "<img class=img_border align=\"left\" src=\"" + response.picture.data.url + "\"></a>";      

     

      profHTML += "<h2 class=myname_profile>" + response.name + "</a> </h2>";

	  profHTML += "<div class='disconnect'><input type='button' onclick='disconnect_Facebook()' value='Disconnect' /></div>";

      $("#facebook_info").html(profHTML);

	

		});	

		

	}, {scope: 'email,user_birthday,offline_access,read_stream,publish_stream,publish_actions'});

}



function disconnect_Facebook()
    {    
   parent.location='<?php echo site_url().'login/logout'; ?>'
 
    FB.logout(function(response) {location.reload()});

	setTimeout(loadwindow,3600);

	

}

<?php if($this->session->userdata('user_name')==''){ ?>

$(function(){ 



	FB.getLoginStatus(function(response) {

		if (response.status === 'connected') {

		

		FB.api('/me?fields=cover,name,picture,username', function(response) {

		var profHTML='';

      profHTML += "<img class=img_border align=\"left\" src=\"" + response.picture.data.url + "\"></a>";      

      profHTML += "<h2 class=myname_profile>" + response.name + "</a> </h2>";

      $("#facebook_info").html(profHTML);

	  $("#facebook_info").addClass("facebook_login");

	  $.post('login/fb_session',{username:response.username},function(){});

	  $('li#checkfb').html('<a class="login-btn" title="Login" href="javascript:void(0)" onClick="disconnect_Facebook()">Logout</a>');

	  $('li#checkfbprofile').html('<a class="login-btn" title="Signup" href="<?php echo site_url()."register/user_info"; ?>">Profile</a>');

	  

	   $.ajax({

				type: "POST",

				 url: "<?php echo site_url("login/facebook_login"); ?>",

				data: { id:response.username,fname:response.name,uimage:response.picture.data.url}

				}).done(function( msg ) {

					location.reload();

					

				});

	  

	  });	



	}

	}, true);

	});

<?php } ?>	

	

</script>

<!--ends here-->

</head>





<body >

<!--page--> 

<div id="page"> 

  <!--top border-->

  <div id="top-border"> </div>

  <!--end top border--> 

  <!--header-->

  <div id="header">

    <div class="container">

      <div class="row-fluid">

      <div class="span12">

        <div class="span3">

          <div class="logo"> <a href="<?=site_url()?>"><img src="<?php echo base_url().'assets/images/logo.png'; ?>" alt="" border="0" /></a> </div>

        </div>

        <?php 

			$counter_name=$this->session->userdata('country_name');

				$counter_code=$this->session->userdata('country_code');

		?>

        <div class="span3 country_state">

        	<div class="f32">

           	<!--<a href="javascript:void(0)" class="flag <?php echo strtolower($counter_code);?>" onClick="getall_state()"><?php echo $this->session->userdata('state');?> <span class="down_arrow"> &nbsp;</span></a>-->

            <select class="flag" onChange="city_change_header()" id="countery_states_drop_down">

         

            </select>

             </div>

        

                <div id="country_result" class="country_result"></div>

                <div class="social pull-right">

                  <ul>

                    <!--<li class="first"><a target="_blank" class="appstore" href="#">appstore</a></li>-->

                    <li class="last" id='facebook_info'></li>

                  </ul>

                </div>

        </div> 

        

        <div class="span6 social-wrap">

        

        		<div class="login-user pull-right">

                  <ul>

                    <?php if($this->session->userdata('user_name')!=''){ ?>

                    <li class="first"><a class="login-btn" title="Logout" href="javascript:void(0)" onClick="disconnect_Facebook()">Logout</a></li>

                    <li class="last" ><a class="login-btn" title="Profile" href="<?php echo site_url()."register/user_info/"; ?>">Profile</a></li>

                      <?php }else{?>

                    <li class="first" id="checkfb"><a class="login-btn fancybox fancybox.ajax"  href="<?=site_url()."login" ?>" >Login</a></li>

                    <li class="last" id="checkfbprofile"><a class="login-btn fancybox fancybox.ajax"  href="<?php echo site_url()."register"; ?>">Signup</a></li>

                    <?php }?>

                  </ul>

                </div>

                

                <?php if($this->session->userdata('user_name')){ ?>

                <span class="login_user_info"> 

                 <?php 

				 if($this->session->userdata('user_image')!=''){?>

                 

					<img src="<?php echo $this->session->userdata('user_image') ?>" class="head_image"/>

					 

					 <?php }else{?>

						 <img src="<?php echo base_url().'/assets/images/user2.png'; ?>" class="head_image"/>

						 <? } ?>

                         <span class="login_user_name">

                    <?php echo $this->session->userdata('f_name').' '.$this->session->userdata('l_name');?>

                     </span>

                </span>

                <?php }?> 

              </div>

      </div>

    </div>

    </div>

  </div>

  <!--end header--> 

