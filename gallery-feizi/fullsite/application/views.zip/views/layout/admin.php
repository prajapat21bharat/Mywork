<!DOCTYPE html>

<html lang="en">

<head>

<meta http-equiv="Content-Type" content="text/html" charset="utf-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<meta name="description" content="">

<meta name="keywords" content="">

<meta name="author" content="">

<title>Admin</title>

<link rel="shortcut icon" href="<?php echo base_url().'assets/images/favicon.ico';?>" type="image/x-icon" />

<link rel="apple-touch-icon" href="<?php echo base_url().'assets/images/favicon.ico';?>"/>

<link href="<?php echo base_url('assets/css/bootstrap.min.css') ?>" rel="stylesheet">

<link href="<?php echo base_url('assets/css/bootstrap-responsive.min.css') ?>" rel="stylesheet">

<link href="<?php echo base_url('assets/css/font-awesome.css') ?>" rel="stylesheet">

<link href="<?php echo base_url('assets/css/custom.css') ?>" rel="stylesheet">

<link rel="stylesheet" href="<?php echo base_url().'assets/slider/index_data/jquery.css'; ?>" type="text/css" media="screen">

<link href="<?php echo base_url('assets/css/admin_owner.css') ?>" rel="stylesheet"/>

<link href="<?php echo base_url('assets/css/apetizer-admin.css') ?>" rel="stylesheet"/>

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>

<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>

<script src="//cdnjs.cloudflare.com/ajax/libs/lodash.js/1.2.1/lodash.min.js"></script>

<script src="<?php echo base_url('assets/js/bootstrap.min.js') ?>"></script>

<script src="<?php echo base_url('assets/js/custom.js') ?>"></script>

</head>

<body>

<!--top nav part start-->

<div class="container-fluid top-header"> <a class="btn btn-navbar hidden-desktop mob_btn" data-toggle="collapse" data-target=".nav-collapse"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </a>

  <div class="nav-collapse collapse">

    <?php $site=site_url().'admin/';?>

    <p class="navbar-text pull-right">

      <?php if($this->session->userdata('group')=='1'){?>

      <a id="user-popover" href="#" class="navbar-link user-info">

      <?php if($this->session->userdata('admin_mail')!='')

echo $this->session->userdata('admin_mail');?>

      </a> <a href="<?=$site.'register' ?>" class="btn btn-mini btn-inverse navbar-link orange-btn">Add Owner</a> <a href="<?=$site.'changepassword' ?>" class="btn btn-mini btn-inverse navbar-link orange-btn">Change Password</a> <a href="<?=$site.'/login/logout' ?>" class="btn btn-mini btn-inverse navbar-link orange-btn">Logout</a>

      <?php } ?>

    </p>

  </div>

</div>



<!--<div class="row-fluid">

<div class="span12">

<div class="subnav" style="margin-bottom: 10px;">



</div>

</div>

</div>

</div>--><!--top nav part close-->

<div class="row-fluid">

  <div class="span12">&nbsp;</div>

</div>

<?php $site_segment3=$this->uri->segment(3);

      $site_segment2=$this->uri->segment(2);?>

<!--Subnav Left part -->

<div class="container-fluid main-container">

  <div class="row-fluid">

    <div class="span12">

      <div class="sidebar-nav mob-left-part span2">

        <ul class="nav nav-stacked left-menu">

          <?php if($this->session->userdata('group')=='1'){?>

          <li>

              <a class="<?php if($site_segment3=="restaurant" || $site_segment3=="retaurant_cluster" ||$site_segment3=="city"){echo 'active';}?>" href="<?=$site.'home/restaurant/' ?>">

              <span class="icon_box dashboard_icon"></span>

              <span class="hidden-tablet hidden-phone">Dashboard</span>

              </a>

          </li>

          <li>

              <a class="<?php if($site_segment2=="cluster"){echo 'active';}?>" href="<?=$site.'cluster' ?>">

              <span class="icon_box cluster_icon"></span>

              <span class="hidden-tablet hidden-phone">Cluster</span>

              </a>

          </li>

          <li>

              <a class="<?php if($site_segment2=="home" && $site_segment3=="" || $site_segment3=="index"){echo 'active';}?>" href="<?=$site.'home/' ?>">

              <span class="icon_box restaurant_icon"></span>

              <span class="hidden-tablet hidden-phone">Add Restaurant</span>

              </a>

          </li>

          <li>

              <a class="<?php if($site_segment2=="csvupload"){echo 'active';}?>" href="<?=$site.'csvupload' ?>">

              <span class="icon_box upload_icon"></span>

              <span class="hidden-tablet hidden-phone">Upload CSV File</span>

              </a>

          </li>

          <li>

              <a class="<?php if($site_segment2=="special_offers"){echo 'active';}?>" href="<?=$site.'special_offers' ?>">

              <span class="icon_box offer_icon"></span>

              <span class="hidden-tablet hidden-phone">Special Offer</span>

              </a>

          </li>

          <li>

              <a class="<?php if($site_segment3=="user_profile" ||$site_segment2=="register" ){echo 'active';}?>" href="<?=$site.'home/user_profile' ?>">

              <span class="icon_box user_icon"></span>

              <span class="hidden-tablet hidden-phone">User</span>

              </a>

          </li>

          <li>

              <a class="<?php if($site_segment3=="analytics"){echo 'active';}?>" href="<?=$site.'home/analytics' ?>">

              <span class="icon_box analytics_icon"></span>

              <span class="hidden-tablet hidden-phone">analytics</span>

              </a>

          </li>

          

          <?php } ?>

        </ul>

      </div>

      <?=$content_for_layout?>

    </div>

  </div>

</div>

</body>

</html>

