<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

<script type="text/javascript">

$(document).ready(function () {

  $('.preview2').on("click", function (e) {
	  
    $.ajax({

      type: "POST",

      cache: false,

	 url:'<?php echo site_url().'changepassword';?>',

      data: $("#postp").serializeArray(), // all form fields

      success: function (data) {

        $.fancybox(data, {

          fitToView: false,

          width: 'auto',

          height: 'auto',

          autoSize: true,

          closeClick: false,

          openEffect: 'none',

          closeEffect: 'none'

        }); // fancybox

      } // success

    }); // ajax

  }); // on

}); // ready





function check_owner(){

	

	parent.$.fancybox.open({href : "<?php echo site_url().'changepassword';?>" , type: 'ajax',height: 800, width: 500,scrolling : 'no'});

	}

</script>







 <div class="update_pass">

    </div>

	<div class="chang-pass">

	<h3>Change Password</h3>

    </div>

<?php if(!empty($success)){ 
     echo '<p class="msg">'.$success.'</p>';
 } ?>
  

 <form id="postp">

   <input type="hidden" id="user_name" name="user_name" value="<?php echo $this->session->userdata('user_name');?>"/>

   

  <label>Old Password</label>

  <input type="password" id="old_password" name="old_password" value="" />

    <?php echo form_error('old_password'); ?>

    <?php

  if(!empty($invaild)){

	  echo '<p>'.$invaild.'</p>';

	  }

 ?>  

    

  <label>New Password</label>

 <input type="password" id="new_password" name="new_password" value="<?php //echo set_value('new_password') ?>" />

     <?php echo form_error('new_password'); ?>

     

 <label>Confirm Password</label>

<input type="password" id="confirm_password" name="confirm_password" value="<?php //echo set_value('confirm_password') ?>" />

    <?php echo form_error('confirm_password'); ?> 

    

    <div class="login_button">

    <a class="preview2" href="javascript:void(0)">

     <input type="button"  value="Change" class="login-btn " id="change_password"/>

   </a>

   </div>

    </form>

</div>



