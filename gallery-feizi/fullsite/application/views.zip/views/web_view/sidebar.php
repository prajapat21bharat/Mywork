  <!--  #####    SAIDE BAR START   ##########-->
  
  <?php $navigation=site_url().'restaurant/'; ?>
  
         <div id="main-content">
          <div class="row-fluid">
          
            <div id="layout-widget" class="span3">
            	<div id="logo_image"><a href="javascript:void(0)"><img src="<?php echo site_url().'uploadimages/files/'.$restaurant[0]->restaurant_logo;?> " width="150px" height="150px"/></a></div>
               	<div class="getbutton"><a href="javascript:void(0)">Get Mobile</a></div>
                <div class="getbutton"><a href="javascript:void(0)">Share Button</a></div>
                <div class="getbutton"><a href="javascript:void(0)">Facebook</a></div>
                <div class="getbutton"><a href="javascript:void(0)">Twitter</a></div>
                <div class="getbutton"><a href="javascript:void(0)">Website</a></div>
                <div class="getbutton"><a href="javascript:void(0)">Submitted Photo Gallery</a></div>
                <div class="getbutton"><a href="javascript:void(0)">Subscribe for Notifications</a></div>
                <div class="getbutton"><a href="<?php echo $navigation.'location'; ?>">Location</a></div>
                <div class="getbutton"><a href="<?php echo $navigation.'contact'; ?>">Contact Us</a></div>
                
             <!-- <h4>WIDGET</h4>
              <!----{{ widget_slug:sidebar }}----->
              <!--<h4>ADVERTISEMENT</h4>
              <!----{{ widget_slug:advertisement }}------>
              <div class="clear"></div>
            </div>
         
            
             <!--  #####    END SAIDE BAR START   ##########-->