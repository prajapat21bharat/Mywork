<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$address=base_url().'uploadimages/submitted_gallery/';
?>

<script>
$(document).ready(function(){
	var url_segment='<?=$this->uri->segment(3)?>';
	if(url_segment=='')
	{
		//$('#pagination .active').html('<a href="<?=site_url().'restaurant/gallery'?>">1</a>');
		$("#pagination a:last").remove();
	}else{
		$("#pagination a:first").remove();	
	}
});
</script>

<div class="heading"><h3>Photo Gallery</h3></div>
 <div id="image_box">
	<h6><a class="fancybox fancybox.ajax" href="<?=site_url().'restaurant/add_gallery'?>">Add New Photo</a></h6>
</div>
<div class="row-fluid">

		<?php 
		if($photo)
		{
    foreach($photo as $photo)
    { ?>
		<a class="fancybox fancybox.ajax" href="<?=site_url().'restaurant/show_photo/'.$photo->gallery_image_id?>"><img src="<?=$address.'thumimage/'.$photo->thumb_image_url?>"/></a>
               
		<?php  }
    }?>	
    
    					 
</div>
<?=$links?>		




