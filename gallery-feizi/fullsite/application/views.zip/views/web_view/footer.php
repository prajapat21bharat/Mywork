</div>
<!-- end main-content-->
</div>
<!-- end main-->

<!--footer-->
<!--bottom block-->

<div id="bottom-block">
  <div class="container">
    <div class="row-fluid">
      <div class="browse-rest">
        <h6>Browse Restaurants by</h6>
      </div>
    </div>
    <div class="row-fluid">
        <div class="span3">
            <div class="block-bot">
            <h6>Popular Localities</h6>
            <ul>
                <li><a href="<?php echo base_url()?>search?state=Minnesota&city=Minneapolis&country_code=US&country_name=United States&/" >Minneapolis</a></li>
                <li><a href="<?php echo base_url()?>search?state=Minnesota&city=Saint Paul&country_code=US&country_name=United States&/" >St. Paul</a></li>
                <!--<li><a href="home/searchresult?state=Minnesota&city=Saint Paul" >St. Paul</a></li>-->
                <li><a href="<?php echo base_url()?>search?state=Minnesota&city=Duluth&country_code=US&country_name=United States&/" >Duluth</a></li>
                <li><a href="<?php echo base_url()?>search?state=Minnesota&city=Lake Elmo&country_code=US&country_name=United States&/" >Lake Elmo</a></li>
                <li><a href="<?php echo base_url()?>search?state=Minnesota&city=Saint Cloud&country_code=US&country_name=United States&/" >St. Cloud</a></li>
                <li><a href="<?php echo base_url()?>search?state=Minnesota&city=Mankato&country_code=US&country_name=United States&/" >Mankato</a></li>
              </ul>
          </div>
          </div>
        <div class="span3">
            <div class="block-bot">
            <h6>Popular Cuisines</h6>
            <ul>
                <li><a href="<?php echo base_url()?>search/searchfoods?food=Chinese&/">Chinese (186)</a></li>
                <li><a href="<?php echo base_url()?>search/searchfoods?food=Fast Food&/">Fast Food (142)</a></li>
                <li><a href="<?php echo base_url()?>search/searchfoods?food=Desserts&/">Desserts (90)</a></li>
                <li><a href="<?php echo base_url()?>search/searchfoods?food=Street Food&/">Street Food (82)</a></li>
                <li><a href="<?php echo base_url()?>search/searchfoods?food=South Indian&/">South Indian (69)</a></li>
                <li><a href="<?php echo base_url()?>search/searchfoods?food=Continental&/">Continental (48)</a></li>
              </ul>
          </div>
          </div>
        <div class="span3">
            <div class="block-bot">
            <h6>By Budget (for two people)</h6>
            <ul>
                <li><a href="#">Less than $20</a></li>
                <li><a href="#">$20 to $40</a></li>
                <li><a href="#">$40 to $75</a></li>
                <li><a href="#">$75 to $100</a></li>
                <li><a href="#">$100+</a></li>
              </ul>
          </div>
          </div>
        <div class="span3">
            <div class="block-bot">
            <h6>Popular Searches</h6>
            <ul>
                <li><a href="#">Restaurants serving Breakfast</a></li>
                <li><a href="#">Vegetarian Restaurants</a></li>
                <li><a href="#">Restaurants with WiFi</a></li>
              </ul>
          </div>
          </div>
      </div>
  </div>
</div>
<!--bottom block end-->
<div id="footer">
  <div class="container">
    <div class="copyright"><span>© 2013 APETIZR.COM All Rights Reserved</span>
      <div class="ficon pull-right">
        <ul>
          <li><a href="http://facebook.com/" target="_blank" ><img src="/apetizr/assets/images/ffb.png" /></a></li>
          <li><a href="https://plus.google.com/" ><img src="/apetizr/assets/images/fg.png" /></a></li>
          <li><a href="https://twitter.com/share" id="login" target="_new"><img src="/apetizr/assets/images/ft.png" /></a></li>
          <li><a href="http://www.youtube.com/"><img src="/apetizr/assets/images/fyou.png" /></a></li>
        </ul>
      </div>
    </div>
  </div>
</div>
<!--end footer--> 
 <script type="application/javascript">
    function getProducts(City,State){
	$.post("<?php echo base_url();?>home/ajaxHome",{State:State,City:City},function(data){
	 
	 $('#restaurant_result').html(data)
	 
	 });
    
	}
    </script>


 
     
<!---Page----->
</div>

<!-- Piwik -->

<!-- Piwik -->
<script type="text/javascript">
  var _paq = _paq || [];
  _paq.push(["setDocumentTitle", document.domain + "/" + document.title]);
  _paq.push(["setCookieDomain", "*.103.21.53.250"]);
  _paq.push(["setDomains", ["*.103.21.53.250"]]);
  _paq.push(["trackPageView"]);
  _paq.push(["enableLinkTracking"]);

  (function() {
    var u=(("https:" == document.location.protocol) ? "https" : "http") + "://103.21.53.250/apetizr//analytics/";
    _paq.push(["setTrackerUrl", u+"piwik.php"]);
    _paq.push(["setSiteId", "<?php echo $this->session->userdata('restaurant'); ?>"]);
    var d=document, g=d.createElement("script"), s=d.getElementsByTagName("script")[0]; g.type="text/javascript";
    g.defer=true; g.async=true; g.src=u+"piwik.js"; s.parentNode.insertBefore(g,s);
  })();
</script>
<!-- End Piwik Code -->

</body></html>