<div id="layout-content" class="menu_navigation">
<div class="row-fluid resevent about_us_rest">
 <?php  
foreach($about as $about){
	echo $about->about;} ?>  
    
    <!-- hitwebcounter Code START -->

<?php /*?><img src="http://hitwebcounter.com/counter/counter.php?page=5078983&style=0001&nbdigits=5&type=page&initCount=0" title="http webcounter" Alt="http webcounter"   border="0" ><?php */?>

   
  </div>
  </div>


