<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
  ?>
  
  <style>
#image_box{margin-bottom:10px;}
#image_box img{height:250px;width:250px;}
</style>
<div class="container">
	<div class="hero-unit"> 
             	 <div id="containt_heading" class="containt_heading"><h3>Special Offers</h3></div>
                  
              		<div id="image_box">
                    
                    
                    
                    
                    	 <?php foreach($photo as $photo)
					{ 
					 if($photo!=NULL)
                        {?>
                    	 <a href="javascript:void(0)"><img src="<?php echo site_url().'uploadimages/offer_image/'.$photo->image;?>" /></a>
                         
                      <?php } 
					}?>  
                
					   <div class="clear"></div>
                      
                      
              		<div id="description">
                  <div class="Title_event"><h2> Title </h2>  <?php echo $offer[0]->offer_title; ?></div>
                  <div class="Title_event"><h2> Web site</h2><a href="<?php echo 'http://'.$offer[0]->offer_website; ?>"> <?php echo $offer[0]->offer_website; ?></a></div>
                  <div class="Title_event"><h2> Start Time </h2>  <?php echo $offer[0]->start_date." ".$offer[0]->start_time; ?></div>
                  <div class="Title_event"><h2> Description </h2> <?php echo $offer[0]->offer_description; ?></div>
                  <div class="Title_event"><h2> End Time </h2> <?php echo $offer[0]->end_date." ".$offer[0]->end_time; ?></div>
    
              <div class="clear"></div>
                    </div><!--description-->
            
                      </div><!--image_box-->
                      	</div><!--hero-unit-->
                          </div><!--container-->
          
 