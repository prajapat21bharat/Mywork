<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$address=site_url().'restaurant/offer/'; ?>
<div class="row-fluid resevent">
  <?php	
  
		if($offer){
		 foreach($offer as $offers){ 
          echo '<div id="image_box">'; 
	        foreach($photo as $photos){
				if($photos->offer_id==$offers->offer_id){?>
                   
                      <img src="<?php echo site_url().'uploadimages/offer_image/'.$photos->image;?>"/>
                 <?php }
	          }?>
          </div>
       <div class="event">
        <h4><?php echo $offers->offer_title; ?></h4>
         <p><?php echo $offers->offer_description; ?></p>
         <p> <span><?php echo $offers->start_date; ?></span> To <span><?php echo $offers->end_date; ?></span> </p>
     </div>
    <?php }
		}else{ echo '<div class="error"><h4>Sorry, there is no data for this restaurant listing.</h4></div>';}?>
</div>
