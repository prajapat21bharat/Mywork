<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$address=site_url().'restaurant/header_gallery/'; ?>
<style>
#image_box{clear:none !important}
</style>
<div class="row-fluid resevent">
  <?php	
  
		if($restaurant_banner){
		 foreach($restaurant_banner as $offers){ ?>
          <div id="image_box">
		 
                   
                     <a href="<?php echo site_url().'uploadimages/files/'.$offers->image;?>" rel="group" class="fancybox"> <img src="<?php echo site_url().'uploadimages/files/'.$offers->image;?>" height="200" width="300" /></a>
                 <?php
				 echo '</div>';
				  }
	         // }?>
          </div>
    
    <?php //}
		}else{ echo '<div class="error"><h4>Sorry, there is no data for this restaurant listing.</h4></div>';}?>
</div>
