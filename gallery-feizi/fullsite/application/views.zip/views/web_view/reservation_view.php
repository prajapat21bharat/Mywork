<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
?>
<div id="layout-content" class="menu_navigation">
<div class="row-fluid resevent reservation_rest">

<!--<script type="text/javascript" src="http://www.opentable.com/frontdoor/default.aspx?rid=49669&restref=49669&bgcolor=F6F6F3&titlecolor=0F0F0F&subtitlecolor=0F0F0F&btnbgimage=http://www.opentable.com/frontdoor/img/ot_btn_red.png&otlink=FFFFFF&icon=dark&mode=tall"></script>

<a style="color:#000" target="_blank" href="http://www.opentable.com/ray-js-american-grill-reservations-woodbury?rtype=ism&restref=49669" class="OT_ExtLink">Ray J&#39;s American Grill Reservations</a>
--><?php
if(!empty($reservation))
{
foreach($reservation as $reservation)
{
 echo $reservation->reservation_text;
}
}
?>

</div>
</div>