<!--  #####     Main Containt Navigation   ##########-->

<?php $navigation=site_url().'restaurant/'; ?>

<div class="nav-collapse collapse" id="main-menu">
<div class="menubutton"><a href="<?php echo $navigation;?>">About</a></div>
<div class="menubutton"><a href="<?php echo $navigation.'menu'; ?>">Menu</a></div>
<div class="menubutton"><a href="<?php echo $navigation.'events'; ?>">Events</a></div>
<div class="menubutton"><a href="<?php echo $navigation.'offer'; ?>">Special Offers</a></div>
<div class="menubutton"><a href="<?php echo $navigation.'favorite'; ?>">Add to Favorites</a></div>
<div class="menubutton"><a href="<?php echo $navigation.'reservation'; ?>">Reservations</a></div>

<!--  #####    END Main Containt Navigation   ##########-->