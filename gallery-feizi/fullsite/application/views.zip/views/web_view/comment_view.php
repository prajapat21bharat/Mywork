<script type="text/javascript">
function like(){
	var form_data = {
	gallery_image_id:'<?=$image_id?>',
	user_id:'<?=$this->session->userdata('user_id')?>',
	like:'1',
	restaurant_id:'<?=$this->session->userdata('restaurant')?>',
       };
		$.ajax({
			   url:'<?=site_url().'restaurant/like_photo';?>',
			   data:form_data,    
			   datatype:'json',
			   success:function(data){
			  $('#like_button').html('<a onclick="unlike()" id="unlike_value" href="javascript:void(0)">Unlike</a>');
			  <?
			  if($you_like==0){		
		         if($like!='0' && $like!='')
				 { ?>
					 $('#like_show_div').html('<?='You like this...!'?>');					 
			<? }
		       }else{
			     $count=$like-1;
			        if($count!='0' && $count!='')
					{?>
						//echo 'You and '.$count.' other like this...!'; 
						$('#like_show_div').html('<?='You and '.$count.' other like this...!'?>');
					<? }else{ ?>$('#like_show_div').html('<?='You like this...!'?>'); <? }
			     }
			  ?>
			  <!--$('#like_show_div').html('<?='You and '.$like.' other like this...!'?>');-->
				  }
		   });
	}
	
function unlike(){
	var form_data = {
	gallery_image_id:'<?=$image_id?>',
	user_id:'<?=$this->session->userdata('user_id')?>',
	restaurant_id:'<?=$this->session->userdata('restaurant')?>',
       };
		$.ajax({
			   url:'<?=site_url().'restaurant/unlike_photo';?>',
			   data:form_data,    
			   datatype:'json',
			   success:function(data){
			  $('#like_button').html('<a id="like_value" onclick="like()" href="javascript:void(0)">Like</a>')
			 
			 <?
			  if($you_like==0){		
		         if($like!='0' && $like!='')
				 { ?>
					  $('#like_show_div').html('<?='You like this...!'?>');	
					 
			<? }
		       }else{
			     $count=$like-1;
			        if($count!='0' && $count!='')
					{?>
						$('#like_show_div').html('<?=$count .' like this...!'?>');
					<? }else{ ?>$('#like_show_div').html('<?=''?>'); <? }
			     }
			  ?>
			 
				  }
		   });
	}
		
function comment()
{
	$("#comment_input").focus();
}
</script>
<?php
if($this->session->userdata('user_name')!=''){?>
<script>
function comment_photo()
{ 
var comment_input=$('#comment_input').val();
if(comment_input!='')
{
	var form_data = {
		gallery_image_id:'<?=$image_id?>',
		comment_user_id:'<?=$this->session->userdata('user_id')?>',
		comment:comment_input
		   };
			$.ajax({
				   url:'<?=site_url().'restaurant/comment_photo';?>',
				   data:form_data,    
				   datatype:'json',
				   success:function(data){
					  $('#error').html('');
					$('#comment_input').val('');   
				   $('#comment_show_main_div').append("<div id='comment_show_div_"+data+" class='comment_show_div'><img src='<?=base_url().'uploadimages/user/'.$user_info[0]->userfile;?>' height='20px' width='20px'/> " +comment_input+ "</div>");
					  }
			   });
}else{$('#error').html('Plz Enter Some words'); }
}

</script>
<? }

?>
<?php $address=base_url().'uploadimages/submitted_gallery/'; ?>

<div class="content">
  <div class="comment_box_left">
    <div class="comment_box_image"><img src="<?=$address.$photo[0]->image_url?>"/> </div>
  </div>
  <div class="comment_box_right">
  <h6><a class="fancybox fancybox.ajax" href="<?=site_url().'restaurant/add_gallery'?>">Add New Photo</a></h6>
    <?php if($this->session->userdata('user_name')!=''){?>
    <div id="like_button" class="like_button">
      <? if($you_like==0){?>
      <a id="like_value" onclick="like()" href="javascript:void(0)">Like</a>
      <? }else{?>
      <a onclick="unlike()" id="unlike_value" href="javascript:void(0)">Unlike</a>
      <? }?>
    </div>
    <div class="commment_butto"><a onclick="comment()" href="javascript:void(0)">Comment</a></div>
    <?php }?>
    <div class="like_show_main_div">
      <div id="like_show_div" class="liket_show_div">
        <? 
		if($you_like==0){		
		if($like!='0' && $like!='')echo $like .' like this...!'; 
		}else{
			$count=$like-1;
			if($count!='0' && $count!='')echo 'You and '.$count.' other like this...!'; 
			else{ echo 'You like this...!' ;}
			}
		?>
      </div>
    </div>
    <div id="comment_show_main_div" class="comment_show_main_div">
      <?php foreach($photo as $comment){?>
      <div id="comment_show_div_<?=$comment->comment_id?>" class="comment_show_div">
        <? if($comment->userfile!=''){ ?>
        <img src="<?php echo base_url().'uploadimages/user/'.$comment->userfile; ?>" height="20px" width="20px"/>
        <? } ?>
        <?=$comment->comment;?>
      </div>
      <?php }?>
    </div>
    <?php if($this->session->userdata('user_name')!=''){?>
    <div class="comment_box">
      <div class="cmt-field"> <img src="<?=base_url().'uploadimages/user/'.$user_info[0]->userfile; ?>" height="20px" width="20px"/>
        <form id="comment_form" onsubmit="comment_photo()" action="javascript:void(0)">
          <input type="text" name="comment" id="comment_input" placeholder="Write a comment"/>
          <div id="error" class="error"></div>
        </form>
      </div>
    </div>
    <?php }?>
  </div>
</div>
