<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>
<style type="text/css">
	a[href="<?php echo site_url('{{ module_path }}/group/delete/1');?>"]{
		visibility : hidden;
		pointer-events: none;
        cursor: default;
	}
</style>
<?php
	$asset = new CMS_Asset();
	foreach($css_files as $file){
		$asset->add_css($file);
	}
	echo $asset->compile_css();

	foreach($js_files as $file){
		$asset->add_js($file);
	}
	echo $asset->compile_js();
	echo $output;
	
	?>
<?php
    echo form_open('restaurant/getRestaurant');
    echo form_label('First Name');
    echo form_input('first_name', $first_name).br();
	echo form_label('Last Name');
    echo form_input('last_name', $last_name).br();
    echo form_label('Phone');
  	echo form_input('phone', $phone).br();
    echo form_label('Address');
    echo form_input('address', $address).br(); 
    echo form_submit('personal_profile_edit', 'update Profile');
    echo form_close(); 
?>
