<script type="text/javascript">
$().ready(function(){
	
	
	var form_data = {
	restaurant_id:'<?=$this->session->userdata('restaurant')?>',
	user_id:'<?=$this->session->userdata('user_id')?>'
       };
		$.ajax({
			   url:'<?=site_url().'restaurant/get_favorite';?>',
			   data:form_data,    
			   datatype:'json',
			   success:function(data){
				 var newdata= jQuery.parseJSON(data);
		       $.each(newdata,function(i,index){
				   if(index['favorite']=='1')
				   {
					   $('#yes').attr('checked', true);
				   }else{
					   $('#no').attr('checked', true);
					   }
				   
			 });
				   
			   }
		});
	
	});

function favroritres(id)
{ 
	var form_data = {
    value: id,
	restaurant_id:'<?=$this->session->userdata('restaurant')?>',
	user_id:'<?=$this->session->userdata('user_id')?>'
       };
		$.ajax({
			   url:'<?=site_url().'restaurant/favorite2';?>',
			   data:form_data,    
			   datatype:'json',
			   success:function(data){
				 
				 $('#favroritres').html('Successfully add');
							   
			   }
		});
}
</script> 
<?php

 if($this->session->userdata('user_name')){ ?>

<div class="favroritres" id="favroritres"> <span>Add to Favorites :</span> <b>
  <?=$restaurant[0]->restaurant_name?>
  </b>
  <div class="yes_no">
    <input type="radio" id="yes" name="favorites" onclick="favroritres(1)" value="1" />
    <span> Yes </span>
    <input type="radio" id="no" name="favorites" onclick="favroritres(0)" value="0" />
    <span> No </span> </div>
</div>
<? }else {?>
<span class="first_login">Please Login to Add Favorites</span>
<div id="not_login"></div>
<? }?>
<script>
$(function (){
	$.ajax({
type: "POST",
 url: "<?php echo site_url().'login/'; ?>",
data: {}
}).done(function( msg ) {
	$('#not_login').html(msg);
	})
});

</script>