<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 ?>

<!--  #####    START  Main Container   ##########-->

<div id="containt" class="span12">
  <div id="containt_heading" class="containt_heading">
    <h3>Location </h3>
  </div>
  <div id="image_box">
    <div id=""><?php echo $restaurant[0]->restaurant_address; ?></div>
    <div id=""><?php echo $restaurant[0]->restaurant_phone .' - '.$city[0]->city; ?></div>
    <div id=""><?php echo $restaurant[0]->state_id .' - '.$restaurant[0]->country_id; ?></div>
  </div>
  <!--image_box-->
  <div class="clear"></div>
  <iframe width="350" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;
                      geocode=&amp;q=<?=$restaurant[0]->latitude;?>,<?=$restaurant[0]->longitude?>&amp;aq=&amp;sll=<?=$restaurant[0]->latitude;?>,<?=$restaurant[0]->longitude?>&amp;sspn=0.008134,0.01929&amp;t=h&amp;g=<?=$restaurant[0]->latitude;?>,<?=$restaurant[0]->longitude?>&amp;ie=UTF8&amp;ll=<?=$restaurant[0]->latitude;?>,<?=$restaurant[0]->longitude?>&amp;spn=0.004067,0.009645&amp;z=14&amp;iwloc=A&amp;output=embed" style="width: 50% !important;"> </iframe>
</div>
<!--containt--> 

