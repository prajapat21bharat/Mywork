<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$address=site_url().'restaurant/events/'; ?>
<div class="row-fluid resevent" >
  <?php	
		if($event){
		 foreach($event as $events){ 
          echo '<div id="image_box">'; 
	        foreach($photo as $photos){
				if($photos->event_id==$events->event_id){?>
                  
                      <img src="<?php echo site_url().'uploadimages/events/'.$photos->image;?>"/>
                 <?php }
	          }?>
          </div>
       <div class="event">
        <h4><?php echo $events->event_title; ?></h4>
         <p><?php echo $events->event_vanue; ?></p>
         <p> <span><?php echo $events->start_date ; ?></span> To <span><?php echo $events->end_date; ?></span> </p>
     </div>
    <?php }
		}else{ echo '<div class="error"><h4>Sorry, there is no data for this restaurant listing.</h4></div>';}?>
</div>
