 <?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
  
  ?>

<div id="containt_heading" class="containt_heading">
  <h3>Contact Us </h3>
</div>
<div id="image_box">
  <div id="logo_image"><a class="fancybox" href="<?=site_url().'uploadimages/files/'.$restaurant[0]->restaurant_logo;?>"><img src="<?php echo site_url().'uploadimages/files/'.$restaurant[0]->restaurant_logo;?>" width="250px" height="200px"/></a></div>
  <div id=""><?php echo $restaurant[0]->restaurant_address; ?></div>
  <div id=""><?php echo $restaurant[0]->restaurant_phone .' - '.$city[0]->city; ?></div>
  <div id=""><?php echo $restaurant[0]->state_id .' - '.$restaurant[0]->country_id; ?></div>
</div>
<!--image_box-->
<div class="clear"></div>

<!--about_image-->

</div>
<!--containt--> 

