<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html" charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="keywords" content="">
<meta name="author" content="">
<title><?php echo  $restaurant[0]->restaurant_name;?></title>
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon" />
<link href="<?php echo base_url('assets/css/bootstrap.min.css') ?>" rel="stylesheet">
<link href="<?php echo base_url('assets/css/bootstrap.css') ?>" rel="stylesheet">
<link href="<?php echo base_url('assets/css/bootstrap-responsive.min.css') ?>" rel="stylesheet">
<link href="<?php echo base_url('assets/css/font-awesome.css') ?>" rel="stylesheet">
<link href="<?php echo base_url('assets/css/custom.css') ?>" rel="stylesheet">
<link href="<?php echo base_url('assets/css/flages.css') ?>" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/jquery.fancybox.css');?>"  media="screen" />
<?php /*?><link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/jquery.mCustomScrollbar.css');?>"  media="screen" /><?php */?>

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/lodash.js/1.2.1/lodash.min.js"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/bootstrap.min.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/custom.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/jquery.mousewheel-3.0.6.pack.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/jquery.fancybox.js?v=2.1.5') ?>"></script>
<?php /*?><script src="<?php echo base_url('assets/js/jquery.mCustomScrollbar.concat.min.js')?>"></script><?php */?>
<?php $slider=base_url().'assets/slider/'?>
    <script type="text/javascript" src="<?=$slider?>index_data/jquery_004.js"></script>
    <link rel="stylesheet" type="text/css" href="<?=$slider?>index_data/preview.css" media="screen">
    <link rel="stylesheet" type="text/css" href="<?=$slider?>index_data/settings.css" media="screen">
    <script type="text/javascript" src="<?=$slider?>index_data/jquery_003.js"></script> 
    <script type="text/javascript" src="<?=$slider?>index_data/jquery.js"></script>
    <link rel="stylesheet" href="<?=$slider?>index_data/jquery.css" type="text/css" media="screen">
    <script type="text/javascript" src="<?=$slider?>index_data/jquery_002.js"></script>
    <link href="<?=$slider?>index_data/css.css" rel="stylesheet" type="text/css">
    <link href="<?=$slider?>index_data/css_002.css" rel="stylesheet" type="text/css">
    <script type="text/javascript">

	jQuery(document).ready(function() {

		jQuery('#example1').showbizpro({
			dragAndScroll:"on",
			visibleElementsArray:[4,3,2,1],
			carousel:"on",
			entrySizeOffset:0,
			allEntryAtOnce:"off",
			speed:500,
			autoPlay:"on",
			rewindFromEnd:"on",
			delay:3000
		});

  //jQuery(".fancybox").fancybox();



				});
function getall_state(){
	if($('#country_result').is(':empty')){
	var form_data = {};
	$.ajax({
	   url:'<?=site_url().'home/countery_state';?>',
	   data:form_data,    
	   datatype:'json',
	   success:function(data){ 
	   $('#country_result').html(data);
	  // alert(data);
	   }
  });
	}else{ $('#country_result').toggle();}
	}
			</script>
            
   <style>
 #comment_show_main_div{
	 height:350px !important;
	 overflow:auto !important;
	 }
   </style>
</head>
<body>
<div id="page">
<div id="main">
<!--header-->
<div id="header">
<div class=" brdr"></div>
    <div class="container">
        <div class="row-fluid">
        <div class="span3">
            <div class="logo"> <a href="<?=site_url()?>"><img src="<?php echo base_url().'assets/images/logo.png'; ?>" alt="" border="0" /></a> </div>
          </div>
          
 <div class="span5 offset4">
            <div class="admin-block">
            <div class="row-fluid">
                <div class="span5 social-wrap">
                 <?php if($this->session->userdata('f_name')){ ?>
               <span> 
                <a class="fancybox" href="<?php echo $this->session->userdata('user_image'); ?>"><img src="<?php echo $this->session->userdata('user_image'); ?>" class="head_image"/></a>
              <?php /*?> <label>
               <a class="fancybox" href="<?php echo site_url()."uploadimages/user/".$user_info[0]->userfile; ?>"><img src="<?php echo site_url()."uploadimages/user/".$user_info['0']->userfile; ?>"/></a>
               </label><?php */?> <?php   echo $this->session->userdata('f_name').' '.$this->session->userdata('l_name');?>
               </span>
			   <?php }  
				$counter_name=$this->session->userdata('country_name');
				$counter_code=$this->session->userdata('country_code');   ?>
               <div class="f32 down_arrow">
  <a href="javascript:void(0)" class="flag <?php echo strtolower($counter_code);?>" onClick="getall_state()"><?php echo $this->session->userdata('state');?></a>
</div>
<div id="country_result" class="country_result"></div>
                <div class="social pull-right">
                    <ul>
                    <!--<li class="first"><a target="_blank" class="appstore" href="#">appstore</a></li>-->
                    <li class="last" id='facebook_info'></li>
                  </ul>
                  </div>
              </div>
                <div class="span7 login-wrap">
                <div class="login-user pull-right">
                    <ul>
                    <?php if($this->session->userdata('user_name')!=''){ ?>
                    <li class="first"><a class="login-btn" title="Login" href="javascript:void(0)" onClick="disconnect_Facebook()">Logout</a></li>
                    
                    <li class="last"><a class="login-btn" title="Signup" href="<?php echo site_url()."register/change_profile"; ?>">Profile</a>
                        <?php }else{?>
                      <li class="first" id="checkfb"><a class="login-btn fancybox fancybox.ajax"  title="Login" href="<?=site_url()."login" ?>">Login</a></li>
                    <li class="last" id="checkfbprofile"><a class="login-btn fancybox fancybox.ajax" title="Signup" href="<?php echo site_url()."register"; ?>">Signup</a></li>
                    <?php }?>
                  </ul>
                  </div>
              </div>
              </div>
          </div>
          </div>
      </div>
      </div>
  </div>
<!--end header--> 
<!--main-content-->
<div id="main-content">
<script src="http://connect.facebook.net/en_US/all.js"></script>
<script>
var FB_APPID = '{/literal}{$FB_APPID}{literal}';
$(document).ready(function() {
FB.init({
	    appId  : '509926562424311',
	    status : true, 
	    cookie : true, 
	    xfbml  : true
	  });

});

var accesstoken='';
var username='';
var name = '';
var id ='';
function FBlogin()  
{
	
	FB.login(function(response) {
	if (response.authResponse.accessToken) {
		$('#fbKey').val(response.authResponse.accessToken);
		accesstoken = response.authResponse.accessToken;
	}
	
	if (response.authResponse) {
		FB.api('/me', function(response) {
			id = response.message;
			username = response.username;
			name = response.name ;
			 
			 parent.location='<?php echo base_url().'login/facebook_login?id='; ?>'+username; 
		});
	}
	
 $("#facebook_info").addClass("facebook_login");

		FB.api('/me?fields=cover,name,picture', function(response) {
			var profHTML='';

      profHTML += "<img class=img_border align=\"left\" src=\"" + response.picture.data.url + "\"></a>";      
     
      profHTML += "<h2 class=myname_profile>" + response.name + "</a> </h2>";
	  profHTML += "<div class='disconnect'><input type='button' onclick='disconnect_Facebook()' value='Disconnect' /></div>";
      $("#facebook_info").html(profHTML);
	
		});	
		
	}, {scope: 'email,user_birthday,offline_access,read_stream,publish_stream,publish_actions'});
}

   function postOnFB(body)
{

	FB.api('/me/feed', 'post', { message: body }, function(response) {
		
	  if (!response || response.error) {
	    
	  } else {
	   
	  }
	});
}

    function disconnect_Facebook()

    {     
parent.location='<?php echo base_url().'login/logout'; ?>'

$("#facebook_info").removeClass("facebook_login");
	$("#facebook_info").html('<a class="facebook" href="javascript:void(0)" onClick="FBlogin();" style="display:none;>Facebook</a>'); 
	FB.logout(function(response) { parent.location='<?php echo base_url().'login/logout'; ?>'});
	setTimeout(loadwindow,3000);
	
}

$(function(){

	FB.getLoginStatus(function(response) {
		if (response.status === 'connected') {
		
		FB.api('/me?fields=cover,name,picture,username', function(response) {
		var profHTML='';
      profHTML += "<img class=img_border align=\"left\" src=\"" + response.picture.data.url + "\"></a>";      
      profHTML += "<h2 class=myname_profile>" + response.name + "</a> </h2>";
      $("#facebook_info").html(profHTML);
	  $("#facebook_info").addClass("facebook_login");
	 // $.post('login/fb_session',{username:response.username},function(){});
	  $('li#checkfb').html('<a class="login-btn" title="Login" href="javascript:void(0)" onClick="disconnect_Facebook()">Logout</a>');
	  $('li#checkfbprofile').html('<a class="login-btn" title="Signup" href="<?php echo site_url()."register/user_info"; ?>">Profile</a>');
	  
	  
	
		});	
      }
	}, true);
	});
	
	
</script>