<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
?>
<style>
#image_box {
	margin-bottom:10px;
}
#image_box img {
	height:250px;
	width:250px;
}
</style>
<div class="heading">
  <h3>Events</h3>
</div>
    <div id="image_box">
      <?php 								
					foreach($photo as $photo)
					{ 
					if($photo!=NULL)
                        {?>
      <a href="javascript:void(0)"><img src="<?php echo site_url().'uploadimages/events/'.$photo->image;?>" /></a>
      <?php }
					}?>
    </div>
    <div class="clear"></div>
    <div id="description">
    <div class="filed_row head">
      <div class="Title_event">
        <h2> Title </h2>
        <?php echo $event[0]->event_title; ?></div>
     
      <div class="venue">
        <h4> Venue </h4>
        <?php echo $event[0]->event_vanue; ?></div>
        
          </div>
         <div class="filed_row venue_time"> 
      <div class="start_time">
        <span> Start Time </span>
        <?php echo $event[0]->start_date." ".$event[0]->start_time;  ?></div>
    
      <div class="end_time">
        <span> End Time </span>
        <?php  echo $event[0]->end_date." ".$event[0]->end_time;  ?>
      </div>
      </div>
      <div class="filed_row desc">
        <div class="description">
        <p> Discription </p>
        <?php echo $event[0]->event_description; ?></div>
        </div>
      <div class="clear"></div>
    </div>
    <!--description--> 
