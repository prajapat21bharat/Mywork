
<script type="text/javascript">

function mob_no()
{ 

$("#loading").show();
	var form_data = {
       moblie_no:$("#mobl_no").val(),
	   app_url:'<?php echo $app_url; ?>',
	   restaurant_name:"<?php echo addslashes($restaurant[0]->restaurant_name); ?>"
       };
		$.ajax({
			   url:'<?=site_url().'restaurant/sms';?>',
			   data:form_data,    
			   datatype:'json',
			   success:function(data){
				 if(data==1){
				 $('#success').html('Successfully Send Mobile App');
				 $("#loading").hide();
				 //$.fancybox.close();
				 }
				else
				$('#success').html("Please Enter Valid Mobile No.");	
				 $("#loading").hide();	   
			   }
		});
}
</script> 
<?php

 if($this->session->userdata('user_name')){ ?>

<div class="favroritres" id="favroritres">
 <h3>Get the Mobile App</h3> 
<h4><?=$restaurant[0]->restaurant_name?></h4>


  <div class="moblie_sms">
  <label> Enter Your Mobile No.</label>
    <input type="text" id="mobl_no"  name="mobile_no"/> 
      <div id="success"></div>
    <div class="login_button">
    <input type="button" value="Submit" onclick="mob_no()" />
    </div>
  </div>
  <div id="loading" style="display:none"><img src="<?php echo base_url() ?>ajax-loader.gif"></div>
  
  
<? }else {?>
<span class="first_login">Please Login to Get the Mobile App</span>
<div id="not_login"></div>
<script>
$(function (){
	$.ajax({
type: "POST",
 url: "<?php echo site_url().'login/'; ?>",
data: {}
}).done(function( msg ) {
	$('#not_login').html(msg);
	})
});

</script>

<? }?>
