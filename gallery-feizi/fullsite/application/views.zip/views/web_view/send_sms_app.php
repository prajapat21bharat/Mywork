
<script type="text/javascript">

function mob_no()
{ 

$("#loading").show();
	var form_data = {
       moblie_no:$("#mobl_no").val(),
	   app_url:'<?php echo $app_url; ?>',
	   restaurant_name:"<?php echo addslashes($restaurant[0]->restaurant_name); ?>"
       };
		$.ajax({
			   url:'<?=site_url().'restaurant/sms';?>',
			   data:form_data,    
			   datatype:'json',
			   success:function(data){
				 if(data==1){
				 $('#success').html('Successfully Send Mobile App');
				 $("#loading").hide();
				 //$.fancybox.close();
				 }
				else
				$('#success').html("Please Enter Valid Mobile No.");	
				 $("#loading").hide();	   
			   }
		});
}
</script> 



<div class="favroritres" id="favroritres">
<h4><?=$restaurant[0]->restaurant_name?></h4>
 <span>Get the Mobile App</span> <b>
  
  </b>
  <div id="success"></div>
  <div class="moblie_sms">
  <label> Enter Your Mobile No.</label>
    <input type="text" id="mobl_no"  name="mobile_no"/>
    <input type="button" value="Submit" onclick="mob_no()" />
  </div>
  <div id="loading" style="display:none"><img src="<?php echo base_url() ?>ajax-loader.gif"></div>
  
  

