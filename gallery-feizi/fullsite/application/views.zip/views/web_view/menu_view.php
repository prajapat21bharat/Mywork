<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$url=site_url().'restaurant/';
?>

<script type="text/javascript">

function menu_cat(id){
	//$("#menu_cat").html('<img  src="<?php echo base_url().'/ajax-loader.gif'; ?>"/>');
	
	 $(".dont_active").removeClass('active');
	 $("#active_"+id).addClass('active');
	
	var form_data = {
    menu_id: id
	}
	
	
	$.ajax({
       url:'<?=$url.'get_menu_cat';?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		   
		   var newdata= jQuery.parseJSON(data);
		   $("#"+id).empty();
		   $("#menu_cat").empty();
		   if(newdata!=''){
			   $.each(newdata,function(i,index){
					//alert(index['city']+'state code'+index['state_code']);
					htmlString="<li><a class='dropdown-toggle' data-toggle='dropdown' href='javascript:void(0)' onclick='menu_item("+index['menu_cate_id']+")'> "+index['menu_categorie_name']+"</a></li>"
					
					
					$("#"+id).append(htmlString);
			   });
			   
		   }else{
			   $("#menu_cat").append('<div class="error">No Data Found</div>');
		   }
       }
});
}


function menu_item(id){
	
	
	$("#menu_item").html('<img  src="<?php echo base_url().'/ajax-loader.gif'; ?>"/>');
	var form_data = {
    menu_cate_id: id
	}
	
	$.ajax({
       url:'<?=$url.'get_menu_item';?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		   
		   var newdata= jQuery.parseJSON(data);
		   $("#menu_item").empty();
		   if(newdata!=''){
				$.each(newdata,function(i,index){
					//alert(index['city']+'state code'+index['state_code']);
					htmlString="<div class='menu_list'><div class='image'>";
					
					if(index['menu_item_image']!=''){
					htmlString +="<a class='fancybox' href='<?php echo base_url().'uploadimages/menu_image/'?>"+index['menu_item_image']+"'><img src='<?=base_url().'uploadimages/menu_image/'?>"+index['menu_item_image']+"' height='200' width='200'/></a>"
					}else{
						htmlString +="<img src='<?=base_url()."uploadimages/files/".$this->input->cookie("restaurant_logo")?>' height='200' width='200'/>";
						}
						
					htmlString +="</div><div class='title'>"+index['title']+" </div>";
					
					if(index['menu_item_price']!='0'){
					htmlString +="<div class='price'>Price : "+index['menu_item_price']+" $ </div>";
					}
					
					
					htmlString +="<div class='description'>"+index['menu_item_discription']+"</div></div>";
					
					$("#menu_item").append(htmlString);
			   });
		   
		   }else{
			   $("#menu_item").append('<div class="error">Sorry, there is no data for this restaurant listing.</div>');
		   }
       }
});
}

</script>


    
    <div id="layout-content" class="menu_navigation">
      <div class="nav-collapse collapse" id="main-menu">
      
       <ul class="nav nav-pills">
      
        <?php
		$i=0;
		 if(!empty($main_menu)){
		foreach($main_menu as $main_menu){
			if($i==0){$class='active';}else{$class='';}
		?>
       
        <li class="dropdown">
        <a class="dropdown-toggle dont_active <?php echo $class;?>" id="active_<?=$main_menu->menu_id?>" data-toggle="dropdown" href="javascript:void(0)" onclick="menu_cat('<?=$main_menu->menu_id?>')">
        <?=$main_menu->menu_name?><b class="caret"></b>
        </a>
        
        <ul id="<?php echo $main_menu->menu_id?>" class="dropdown-menu dropdown-inr">
              
         </ul>
        
        
        </li>
        <?php
		$i=$i+1;
		 }
		 }
		 
		 else{$error='<div class="error"><h4>Sorry, there is no data for this restaurant listing.</h4></div>';}?>
        
         </ul>
      </div>
     
      <div class="clear_both" id="menu_cat"></div>
     
      <div class="clear_both" id="menu_item">
      
      <?php  
	  //if($error){echo $error;}
	  if(!empty($item)){foreach($item as $item){?>
		  
          
          <div class='menu_list'>
          <div class='image'>
            <?php if(!empty($item->menu_item_image)){?>
          <a class='fancybox' href='<?=base_url().'uploadimages/menu_image/'.$item->menu_item_image?>'>
          
          <img src='<?=base_url().'uploadimages/menu_image/'.$item->menu_item_image?>' height='200' width='200'/></a>
        <?php } 
		
		else{ ?>
             <img src='<?=base_url().'uploadimages/files/'.$this->input->cookie('restaurant_logo')?>' height='200' width='200'/>
			
		<?php 	}
		
		
		?> </div>
		  
			  
			  
			<?php //  } ?>
          <div class='title'><?=$item->title?></div>
          <?php if($item->menu_item_price>0){?>
          <div class='price'>Price :  <?=$item->menu_item_price?> $ </div><?php }?>
          <div class='description'><?=$item->menu_item_discription?></div>
          
          </div>
		  
		  
		  <?php }} ?>
      
      
      </div>
       </div>


