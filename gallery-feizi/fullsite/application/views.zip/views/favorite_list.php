<div class="profile_form white_bg">
<?php 
$i=1; 
$url=site_url().'restaurant/index/';
if(!empty($favorites_list)){
foreach($favorites_list as $list)
{   ?>
	<span class="fav_list_rest"> 
    <a target="_blank" href="<?php echo site_url().$list->slug;?>"><?php echo $i;?> &nbsp;&nbsp;<?php echo $list->restaurant_name;?></a></span>
<? $i++;}
}else{ echo "No Favorites Restaurant";}

 ?>
 </div>


