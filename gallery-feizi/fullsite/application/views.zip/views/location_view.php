<script language="JavaScript" src="http://j.maxmind.com/app/geoip.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script language="JavaScript">

var form_data = {
    state:geoip_region_name(),
	city:geoip_city(),
       };
		$.ajax({
			   url:'<?=site_url().'home/location_get';?>',
			   data:form_data,    
			   datatype:'json',
			   success:function(data){ }
		});
</script>
