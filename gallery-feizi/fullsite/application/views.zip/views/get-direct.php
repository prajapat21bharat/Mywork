<html>
<?php 
$arrayReplacewith = array(' ', ',');
$arrayReplace = array('_', '+');
$toAddress =  str_replace($arrayReplace,$arrayReplacewith,$toaddress); 
?>

<body>
 <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
  <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
<script type="text/javascript">


var directionDisplay;
var directionsService = new google.maps.DirectionsService();

if (navigator.geolocation) {
  navigator.geolocation.getCurrentPosition(success, error);
} else {
  error('not supported');
}
function showLocation() {
 // var latitude = position.coords.latitude;
  //var longitude = position.coords.longitude;
  
  var latitude = '<?php echo $latitude; ?>';
  var longitude = '<?php echo $longitude; ?>';
 
  //alert("Latitude : " + latitude + " Longitude: " + longitude);
  var geocoder = new google.maps.Geocoder();
  // alert(geocoder);
   //var latLng = new google.maps.LatLng(position.coords.latitude,position.coords.longitude);
    var latLng = new google.maps.LatLng(latitude,longitude);
 
//alert("hello");
   if (geocoder) {
      geocoder.geocode({ 'latLng': latLng}, function (results, status) {
         if (status == google.maps.GeocoderStatus.OK) {
            console.log(results[1].formatted_address);
			var name=results[1].formatted_address;
			//alert(name);
			initialize(name);
         }
         else {
            console.log("Geocoding failed: " + status);
         }
      });
   }  
  
}

function errorHandler(err) {
  if(err.code == 1) {
    alert("Error: Access is denied!");
  }else if( err.code == 2) {
    alert("Error: Position is unavailable!");
  }
}
function getLocation(){

   if(navigator.geolocation){
      // timeout at 60000 milliseconds (60 seconds)
      var options = {timeout:60000};
      navigator.geolocation.getCurrentPosition(showLocation, 
                                               errorHandler,
                                               options);
   }else{
      alert("Sorry, browser does not support geolocation!");
   }
}





function initialize(name) {
	
		//alert(name);
  var latlng = new google.maps.LatLng(22.719569,75.857726);
  // set direction render options
  var rendererOptions = { draggable: true };
  directionsDisplay = new google.maps.DirectionsRenderer(rendererOptions);
  var myOptions = {
    zoom: 14,
    center: latlng,
    mapTypeId: google.maps.MapTypeId.ROADMAP,
    mapTypeControl: false
  };
  // add the map to the map placeholder
  var map = new google.maps.Map(document.getElementById("map_canvas"),myOptions);
  directionsDisplay.setMap(map);
  directionsDisplay.setPanel(document.getElementById("directionsPanel"));
  // Add a marker to the map for the end-point of the directions.
 
  calcRoute(name);
}
function calcRoute(name) {
	
	
	
	
	
	
	
  // get the travelmode, startpoint and via point from the form  
  var travelMode = "WALKING";
  
  var start = name;
  //alert(start);
  var via = '<?php echo $toAddress?>';
 //alert(via);
  if (travelMode == 'TRANSIT') {
    via = ''; // if the travel mode is transit, don't use the via waypoint because that will not work
  }
  var end = "51.764696,5.526042"; // endpoint is a geolocation
  var waypoints = []; // init an empty waypoints array
 
  if (via != '') {
    // if waypoints (via) are set, add them to the waypoints array
    waypoints.push({
      location: via,
      stopover: true
    });
  }
  var request = {
    origin: name,
    destination: '<?php echo  $toAddress?>',
   
	
    unitSystem: google.maps.UnitSystem.IMPERIAL,
    travelMode: google.maps.DirectionsTravelMode[travelMode]
  };
  directionsService.route(request, function(response, status) {
    if (status == google.maps.DirectionsStatus.OK) {
      $('#directionsPanel').empty(); // clear the directions panel before adding new directions
      directionsDisplay.setDirections(response);
    } else {
      // alert an error message when the route could nog be calculated.
      if (status == 'ZERO_RESULTS') {
        alert('No route could be found between the origin and destination.');
      } else if (status == 'UNKNOWN_ERROR') {
        alert('A directions request could not be processed due to a server error. The request may succeed if you try again.');
      } else if (status == 'REQUEST_DENIED') {
        alert('This webpage is not allowed to use the directions service.');
      } else if (status == 'OVER_QUERY_LIMIT') {
        alert('The webpage has gone over the requests limit in too short a period of time.');
      } else if (status == 'NOT_FOUND') {
        alert('At least one of the origin, destination, or waypoints could not be geocoded.');
      } else if (status == 'INVALID_REQUEST') {
        alert('The DirectionsRequest provided was invalid.');        
      } else {
        alert("There was an unknown error in your request. Requeststatus: nn"+status);
      }
    }
  });
}
</script>

<body onLoad="showLocation()">
<div id="map_canvas" style="width:500px; height:300px"></div> <br>
 <div id="directionsPanel">
   
  </div>
</div>
</body>