<?php $site=site_url().'admin/admin_home/'; ?>
<script type="text/javascript">

function restaurant_delete(id)
{
var r=confirm('Are Sure Delete This Restaurant');
if (r==true)
	{
	var form_data = {
		 restaurant:id
		  };
    $.ajax({
       url:'<?php echo $site.'delete_retaurant';?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		  $('#'+id).hide();
		  $('#msg').html('Success Fully Deleted');
       }
     });
}

}


function active(value,rest_id)
{

var form_data = {
		 active:value,
		 rest_id:rest_id
		  };
    $.ajax({
       url:'<?php echo $site.'active_inactive';?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		   
		   if(data!='1')
		   {
			   
            $('#actve_deactive_'+rest_id).html("<a title='Enable' onclick='active(1,"+rest_id+")' href='javascript:void(0)'><img src='<?php echo base_url().'assets/img/btn-red1.png'?>'/></a>");
			   
		   }else{
			       $('#actve_deactive_'+rest_id).html("<a title='Enable' onclick='active(0,"+rest_id+")' href='javascript:void(0)'><img src='<?php echo base_url().'assets/img/btn-green.png'?>'/></a>");
		   }
		  
		
       }
     });


}

$(document).ready(function(){
$('#pagination .active').html('<a href="<?php echo $site.'restaurant/'; ?>">1</a>');
$("#pagination a:last").remove();	
	});
</script>

<div class="container">
  <div class="hero-unit"> <a href="<?php echo $site ?>">Add Restaurant</a>
    <div id="msg"></div>
    <table width="100%" class="table table-striped table-bordered">
      <thead>
        <tr>
          <th width="">State</th>
          <th width="">City</th>
          <th width="">Restaurant</th>
          <th width="">Action</th>
        </tr>
      </thead>
      <?php foreach ($records as $restaurant): 
	  print_r($restaurant);
	  die;
	  ?>
      
      <?php  //echo $restaurant->state_id;
	 // die;?>
      <tr id='<?php echo $restaurant->ID; ?>'>
        <td><a href="<?php // echo $site.'edit_retaurant/'.$restaurant->ID; ?>"><?php echo $restaurant->state_id;?></a></td>
        <td><?php echo $restaurant->city_id;?></td>
        <td><?php echo $restaurant->state_id;?></td>
        <td>
        
        <?php if($restaurant->restaurant_is_active==1){
			  echo "<span id='actve_deactive_$restaurant->ID'><a title='Disable' onclick='active(0,$restaurant->ID)' href='javascript:void(0)'><img src='".base_url()."assets/img/btn-green.png'  /></a></span>";
			 
		}else{
			echo  "<span id='actve_deactive_$restaurant->ID'><a title='Enable'  onclick='active(1,$restaurant->ID)' href='javascript:void(0)'><img src='".base_url()."assets/img/btn-red1.png' /></a></span>"; 
             } ?>
             |
        <a href="<?php echo $site.'edit_retaurant/'.$restaurant->ID; ?>"> <img src="<?php echo base_url().'uploadimages/site_image/edit.png';?>"/></a> | <a href="javascript:void(0)" onclick="restaurant_delete(<?php echo $restaurant->ID; ?>)"> <img src="<?php echo base_url().'uploadimages/site_image/delete.png';?>"/></a></td>
      </tr>
      <?php endforeach; ?>
    </table>
    <?php echo $links;?> </div>
</div>
