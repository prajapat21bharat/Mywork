<?php $site=site_url().'admin/home/'; ?>
<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>
<script type="text/javascript">
  $().ready(function() {
	  //alert('sada');
	
	 basic();
	  
   $('#add').click(function() {
    return !$('#select1 option:selected').remove().appendTo('#select2');
   });
   
   
   
   
   $('#remove').click(function() {
    return !$('#select2 option:selected').remove().appendTo('#select1');
   });
   
   
   
   $('#add_new_menu').click(function() {
	   var menu_val=$('#menu_add').val()
	   if(menu_val!='')
	   {
	    var form_data = {
          menu_name: menu_val
	     };
	    $.ajax({
          url:'<?php echo $site.'add_menu';?>',
            data:form_data,    
              datatype:'json',
                success:function(data){
				$('#menu_add').val("");
		         $('#select1').append('<option value='+data+'>'+menu_val+'</option>');
				 $('#menu_msg').html('Success Fully Add  Menu')
			   }//End Success
	      }); //End Ajax
	  } //End If
	  else{
		  $('#menu_msg').html('Plz Enter Menu Name')
		  }
	  
   });
   
  
 
   
   
  });
 </script>
<script type="text/javascript">

function state(){
	
 var form_data = {
    state: $('#state_id').val()
   
 };

$("#loder").show();
$.ajax({
       url:'<?php echo $site.'get_city';?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		   
		  
		   var newdata= jQuery.parseJSON(data);
		   $("#loder").hide();
		   $("#city").empty();
		   var i=0
		   $.each(newdata,function(i,index){
			    /***--This If use to find cluster--****/
				   if(i==0){ clusters(index['city_id']);}
				   i=1; /***--END find cluster--****/
                //alert(index['city']+'state code'+index['state_code']);
				htmlString="<option value='"+index['city_id']+"'>"+index['city']+"</option>"
				$("#city").append(htmlString);
           });
		   
       }
});
}

function basic(){
	  
	  var type=$("#restaurant_type").val();
	  if(type=='Basic') {
		  $(".basic_hide").hide();
	  }else{
		   $(".basic_hide").show();
		  }
  }

function add_photo()
{ 
	var id=$('#counter').val();
	photo='<input type="file" name="userfile'+id+'" value=""  /><br>';	
	  $('#counter').val(Number(id)+1)
	  $('#more_photo').append(photo);
	
}

function delete_image(id)
{var r=confirm('Are you Sure Delete This Image');
if (r==true)
	{
	var form_data = {
    photo_id: id
       };
		$.ajax({
			   url:'<?php echo $site.'delete_restaurant_gallery';?>',
			   data:form_data,    
			   datatype:'json',
			   success:function(data){
				   $('#'+id).remove();
				   
			   }
		});
	}
}



/***--This Fuction Use Get Cluster Accroding to city ID----****/

function clusters(city_id)
{ 
	var form_data = {state: $('#state_id').val(),
						city_id: city_id};
	$.ajax({
       url:'<?php echo $site.'get_cluster';?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		   if(data==0){ 
		       $("#cluster").show();
		       $("#cluster_select").hide();
			   $("#cluster_add").show();
			   $("#cluster_select_option").html('');
			 }else if(data==1){
				 $("#cluster").hide();
				 $("#cluster_select_option").html('');
				 $("#cluster_name").val('');
				 
			}else{
			   $("#cluster_add").hide() 
			   $("#cluster").show()
			   $("#cluster_select").show(); 
			   $("#cluster_name").val('');
			   $("#cluster_select_option").html('');	
			   var newdata= jQuery.parseJSON(data);
			    $.each(newdata,function(i,index){
					 htmlString="<option value='"+index['cluster_id']+"'>"+index['cluster_name']+"</option>"
				$("#cluster_select_option").append(htmlString);
               });
			   
			   
			   }
	   }
	});
	
	
}
/***--END GET CLUSTER--*****/
function more_cluster()
{
	 $("#cluster").show();
     $("#cluster_select").hide();
	 $("#cluster_add").show();
	 $("#cluster_select_option").html('')
}
</script>

<div class="container-fluid content-wrapper cluster_container mob-right-part span10">
<div class="hero-unit">
  <?php $this->load->view('admin/restaurant_preview/edit_resturant_header.php'); ?>
  <?php $att=array('class'=>'edit_form white_bg');
 echo form_open_multipart('admin/home/edit_retaurant/'.$this->uri->segment(4),$att); ?>
  <div class="wit">
    <label>Restaurant Type</label>
    <select onchange="basic()" id="restaurant_type" name="restaurant_type">
      <option value="<?php echo $restaurant[0]->restaurant_type; ?>"><?php echo $restaurant[0]->restaurant_type; ?></option>
      <?php if($restaurant[0]->restaurant_type!='Basic'){?>
      <option value="Basic">Basic</option>
      <?php }?>
      <?php if($restaurant[0]->restaurant_type!='Standard'){?>
      <option value="Standard">Standard</option>
      <?php }?>
      <?php if($restaurant[0]->restaurant_type!='Premium'){?>
      <option value="Premium">Premium</option>
      <?php }?>
    </select>
    <?php echo form_error('restaurant_type'); ?></div>
  <div class="wit">
    <label>Cuisines Type</label>
    <input type="text" name="restaurant_cuisines" value="<?php echo $restaurant[0]->restaurant_cuisines; ?>"  />
    <?php echo form_error('restaurant_cuisines'); ?></div>
  <div class="wit">
    <label>Owner name</label>
    <select name="owner_id">
      <option value="<?php echo $restaurant[0]->user_id; ?>"><?php echo $restaurant[0]->user_name; ?></option>
      <?php
foreach($owner as $user)
if($restaurant[0]->user_name!=$user->user_name)
echo '<option value="'.$user->user_id.'" >'.$user->user_name.'</option>';?>
    </select>
    <?php echo form_error('owner_id'); ?> </div>
  <div class="wit">
    <label>Restaurant Name</label>
    <input type="text" name="restaurant_name" value="<?php echo $restaurant[0]->restaurant_name?>"  />
    <?php echo form_error('restaurant_name'); ?></div>
  <div class="wit">
    <label>Restaurant Logo</label>
    <img src="<?php echo base_url().'uploadimages/files/'.$restaurant[0]->restaurant_logo; ?>" width="100" height="100" />
    <input type="file"  name="userfile1" value=""  />
    <?php if(!empty($error)) echo $error; ?>
  </div>
  <div class="wit basic_hide">
    <label>Website</label>
    <input type="text" name="restaurant_website" value="<?php echo $restaurant[0]->restaurant_website; ?>"  />
    <span>Don't use http:// in url</span> <?php echo form_error('restaurant_website'); ?> <?php echo form_error('country_id'); ?></div>
  <div class="wit">
    <label>State</label>
    <select name="state_id" onchange="state()" id="state_id">
      <?php
foreach($state as $state){
  if($state->state_code== $restaurant[0]->state_id){
	  echo '<option selected="selected" value="'.$state->state_code.'" >'.$state->state.'</option>';
	  }else{
	  echo '<option value="'.$state->state_code.'" >'.$state->state.'</option>';
	  }
}?>
    </select>
    <div id='loder' style="display:none;"><img  src="<?php echo base_url().'ajax-loader.gif'; ?>"/></div>
    <?php echo form_error('state_id'); ?></div>
  <div class="wit">
    <label>City</label>
    <select name="city_id" onchange="clusters($(this).val())" id="city">
      <?php foreach($city as $city) {
		
		if($city->city_id== $restaurant[0]->city_id){
		?>
      <option selected="selected" value="<?php echo $city->city_id; ?>"><?php echo $city->city; ?></option>
      <?php
		}else{?>
      <option  value="<?php echo $city->city_id; ?>"><?php echo $city->city; ?></option>
      <?php }
		}?>
    </select>
    <?php echo form_error('city_id'); ?></div>
  <div id="cluster" style="display:none" class="wit">
    <label>Cluster Name</label>
    <div id="cluster_select" style="display:none">
      <select name="cluster_name_slect" id="cluster_select_option">
      </select>
      <span class="add_more_cluster" onclick="more_cluster()">Add New Cluster</span> </div>
    <div id="cluster_add" style="display:none">
      <textarea id="cluster_name"  name="cluster_name"><?php echo set_value('cluster_name'); ?></textarea>
      <?php echo form_error('cluster_name'); ?> </div>
  </div>
  <div class="wit">
    <label>Zip Code</label>
    <input type="text" name="zip_code" value="<?php echo $restaurant[0]->zip_code; ?>"  />
    <?php echo form_error('zip_code'); ?> </div>
  <div class="wit">
    <label>Address</label>
    <textarea name="restaurant_address" id="address" ><?php echo $restaurant[0]->restaurant_address; ?></textarea>
    <?php echo form_error('restaurant_address'); ?></div>
  <div class="wit basic_hide">
    <label>FaceBook Url</label>
    <input type="text" name="restaurant_facebook_url" value="<?php echo $restaurant[0]->restaurant_facebook_url; ?>"  />
    <span>Don't use http:// in url</span> <?php echo form_error('restaurant_facebook_url'); ?></div>
  <div class="wit basic_hide">
    <label>Twitter Url </label>
    <input type="text" name="restaurant_twitter_url" value="<?php echo $restaurant[0]->restaurant_twitter_url; ?>"  />
    <span>Don't use http:// in url</span> <?php echo form_error('restaurant_twitter_url'); ?> </div>
  <div class="wit basic_hide">
    <label>Mobile App Url</label>
    <input type="text" name="mobile_app_url" value="<?php echo $restaurant[0]->mobile_app_url; ?>"  />
    <span>Don't use http:// in url</span> <?php echo form_error('mobile_app_url'); ?> </div>
  <div class="wit">
    <label>Contact No</label>
    <input type="text" name="restaurant_phone" value="<?php echo $restaurant[0]->restaurant_phone; ?>"  />
    <?php echo form_error('restaurant_phone'); ?></div>
  <div class="wit">
    <label>Active</label>
    <span class="radio-active">Yes</span>
    <input type="radio" name="restaurant_is_active" value="1" <?php if($restaurant[0]->restaurant_is_active==1){?>checked="checked"; <? }?> />
    <span class="radio-active">No</span>
    <input type="radio" name="restaurant_is_active" value="0" <?php if($restaurant[0]->restaurant_is_active==0){?>checked="checked"; <? }?> />
    <?php echo form_error('restaurant_is_active'); ?></div>
  <div class="wit">
    <label>Gallery Image</label>
    <input type="file"  multiple name="userfile[]" size="20" />
    <?php echo form_error('userfile'); ?>
    <?php
    if(!empty($restaurant_photo))
    {?>
    <div id="example1" class="showbiz-container">
      <?php
if(!empty($restaurant_photo))
{?>
      <div class="showbiz-navigation center sb-nav-grey owner"> <a id="showbiz_left_1" class="sb-navigation-left owner_prev"><i class="sb-icon-left-open"></i></a> <a id="showbiz_right_1" class="sb-navigation-right owner_next"><i class="sb-icon-right-open"></i></a>
        <div class="sbclear"></div>
      </div>
      <?php } ?>
      <!-- END OF THE NAVIGATION -->
      
      <div class="divide20"></div>
      <div id="sbiz9283" class="showbiz" data-left="#showbiz_left_1" data-right="#showbiz_right_1" data-play="#showbiz_play_1">
        <div style="height: 250;" class="overflowholder">
          <ul style="width: 1200; left: 0px; height: 250;">
            <?php
foreach($restaurant_photo as $photo)
{?>
            <li style="width: 180px;" class="sb-grey-skin" id="<?php echo $photo->photo_id; ?>">
              <div class="mediaholder">
                <div class="mediaholder_innerwrap"> <img style="height:150px; width:100%;" alt="" src="<?php echo base_url().'thumimage/'.$photo->thumbimage; ?>" >
                  <div style="opacity: 0;" class="hovercover"> <a class="fancybox" rel="group" href="<?php echo base_url().'/uploadimages/files/'.$photo->image; ?>">
                    <div class="lupeicon notalone"><i class="sb-icon-search"></i></div>
                    </a> </div>
                </div>
              </div>
              <div class="detailholder">
                <h4 class="showbiz-title txt-center delete_btn"><a  class="login-btn" href="javascript:void(0)"  onclick="delete_image(<?php echo $photo->photo_id; ?>)">Delete</a></h4>
              </div>
            </li>
            <?php } ?>
          </ul>
          <div class="sbclear"></div>
        </div>
        <!-- END OF OVERFLOWHOLDER -->
        <div class="sbclear"></div>
      </div>
    </div>
    <?php }?>
  </div>
  <div class="wit">
    <div class="login_button space_btn">
      <input class="login-btn" type="submit" name='' value="Save" />
    </div>
  </div>
</div>
<?php $slider=base_url().'assets/slider/'?>
<script type="text/javascript" src="<?=$slider?>index_data/jquery_004.js"></script>
<link rel="stylesheet" type="text/css" href="<?=$slider?>index_data/preview.css" media="screen">
<link rel="stylesheet" type="text/css" href="<?=$slider?>index_data/settings.css" media="screen">
<script type="text/javascript" src="<?=$slider?>index_data/jquery_003.js"></script> 
<script type="text/javascript" src="<?=$slider?>index_data/jquery.js"></script>
<link rel="stylesheet" href="<?=$slider?>index_data/jquery.css" type="text/css" media="screen">
<script type="text/javascript" src="<?=$slider?>index_data/jquery_002.js"></script>
<link href="<?=$slider?>index_data/css.css" rel="stylesheet" type="text/css">
<link href="<?=$slider?>index_data/css_002.css" rel="stylesheet" type="text/css">
<script type="text/javascript">

	jQuery(document).ready(function() {

		jQuery('#example1').showbizpro({
			dragAndScroll:"on",
			visibleElementsArray:[4,3,2,1],
			carousel:"off",
			entrySizeOffset:0,
			allEntryAtOnce:"off",
			speed:500,
			autoPlay:"on",
			rewindFromEnd:"on",
			delay:3000
		});

  jQuery(".fancybox").fancybox();



				});

			</script> 