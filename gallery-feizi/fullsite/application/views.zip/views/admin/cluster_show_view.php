<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$site=site_url()."admin/cluster/";
 ?>
<script>

<!----Get All city accroding to State ------>
function state(){
 var form_data ={state: $('#input_ststes').val()};

$("#loder").html('<img  src="<?php echo base_url().'/ajax-loader.gif'; ?>"/>');
$.ajax({
       url:'<?=$site.'get_city'?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		    var newdata= jQuery.parseJSON(data);
		   $("#loder").empty();
		   $("#input_city").empty();
		   $.each(newdata,function(i,index){
                htmlString="<option value='"+index['city_id']+"'>"+index['city']+"</option>"
				$("#input_city").append(htmlString);
           });
        }
    });
}
<!---END---->

<!----Get All Cluster accroding to city ------>
function cluster_result(){
	var form_data ={city_id: $('#input_city').val()};
 
  $("#sortable1").html('<div><img src="<?php echo base_url().'/loader.gif'; ?>"/></div>');

  $.ajax({
       url:'<?=$site.'index'?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		var newdata= jQuery.parseJSON(data);
		if(newdata!='')
		  {
			 $("#sortable1").empty();
			 var j=0;
			 var html='';
           $.each(newdata,function(i,index){
			     html = '<li class="ui-state-default"  id="'+index['cluster_id']+'">';
                 html += '<span class="restaurant_name span3"><a href="<?php echo site_url().'admin/cluster/edit/';?>'+index['cluster_id']+'">'+index['cluster_name']+'</a></span>';
         		 html += '<span class="user_name span3">'+index['count']+'</span> ';
				 html +='<span class="active_details span3">';
				 html += '<span class="user_name" id="span_'+index['cluster_id']+'">';
				 if(index['active']==1){
					html += '<a onclick="active(0,'+index['cluster_id']+')" href="javascript:void(0)"><img src="<?php echo base_url();?>/assets/img/btn-green.png"></a>'
			
				}else{
				   html += '<a onclick="active(1,'+index['cluster_id']+')" href="javascript:void(0)"><img src="<?php echo base_url();?>/assets/img/btn-red1.png"></a>';
				 
				 }
				 html += '</span> ';
				 html +=' | <a href="<?php echo site_url().'admin/cluster/edit/';?>'+index['cluster_id']+'"><img src="<?php echo base_url().'uploadimages/site_image/edit.png';?>"/></a>'
				 html +='|<a href="javascript:void(0)" onclick="delete_cluster('+index['cluster_id']+')"><img src="<?php echo base_url().'uploadimages/site_image/delete.png';?>"/></a>';
				 html +='</span></li>';
				 
				 $("#sortable1").append(html);
				});
		}else
		   {$("#sortable1").html('<div class="error"><h4>No Data Found</h4></div>'); }
		
		 }
	});
}
<!---END------->

<!--- THis Function use to  Cluster Sorting--->
$(function() {
	$( "#sortable1" ).sortable({
	connectWith: ".connectedSortable"
	}).disableSelection();
});
<!------END----->



<!----This Function use to Active and deactive cluster------>

function active(active_val,cluster_id){
var form_data ={active_val:active_val,cluster_id:cluster_id};
$.ajax({
       url:'<?=$site.'active'?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		   var html;
		   if(active_val==1){
			   html = '<a onclick="active(0,'+cluster_id+')" href="javascript:void(0)"><img src="<?php echo base_url();?>/assets/img/btn-green.png"></a>'
			   
			   }else{
				    html = '<a onclick="active(1,'+cluster_id+')" href="javascript:void(0)"><img src="<?php echo base_url();?>/assets/img/btn-red1.png"></a>'
				   }
				$("#span_"+cluster_id).html(html);   
		 }
  });


}
<!----END----->


<!----This Function use to DELETE cluster------>

function delete_cluster(cluster_id){
var form_data ={cluster_id:cluster_id};
$.ajax({
       url:'<?=$site.'delete'?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		  $("#"+cluster_id).remove(); 
		 }
  });


}
<!----END----->



<!----This Function use to Sorting cluster------>

function sort_cluster(){
	
	var data_array = new Array();
	var oder_no=0;
	$( "#sortable1 li" ).each( function( index, element ){
	  var id=this.id;
	    data_array[index] = {cluster_id: id,
						order_no:$('#'+id).index()+1 };
						
	     }); 
		 
	
var form_data ={data:data_array};
$.ajax({
       url:'<?=$site.'sort_cluster'?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		  $("#msg").html("Successfully Sorted"); 
		 }
  });

}
<!----END----->
</script>

<div class="container-fluid content-wrapper cluster_container mob-right-part span10">
  <div class="hero-unit" id="dragable">
  <h3 class="title">Cluster</h3> 
    <div class="back_color">
  <a href="<?php echo $site.'add_cluster'?>">Add Cluster</a>
    <div id="msg"></div>
    <div class="rest_search"> 
    
    <div class="rest_fliter_city ">
    <label>State</label>
        <select id="input_ststes" class="select-State" onChange="state()">
          <?php	
			   echo '<option value=""> Select State </option>';
				foreach($states as $data){
				echo '<option value="'.$data->state_code.'">'.$data->state.'</option>';
			   }?>
        </select>
    </div>
    <div id="loder"></div>
    <div class="rest_fliter_type cluster_search">
     <label>City</label>
      <select id="input_city" class="select-city">
        </select>
    </div>
    
   <input class="login-btn" type="button" onClick="cluster_result()" value="Search"/>
    
 </div>
    <div id="msg"></div>
    <table width="100%" class="table table-striped table-bordered">
      <thead>
        <tr>
          <th width="40%">Cluster Name</th>
          <th width="30%">No of Restaurant</th>
          <th width="30%">Action</th>
          
        </tr>
      </thead>
    </table>
   
    <div id="restaurant_result">
      <div id="sortable1"  class="connectedSortable" >
       <?php 
	  if(!empty($cluster))
	  {
	  foreach ($cluster as $cluster){ ?>
       
       <li class="ui-state-default"  id="<?php echo $cluster->cluster_id ?>">
       <span class="restaurant_name rep_divider span3">
       <a href="<?php echo site_url().'admin/cluster/edit/'.$cluster->cluster_id;?>"><?php echo $cluster->cluster_name ?></a>
       </span>
       <span class="user_name span3"><?php echo $cluster->count ?></span>
	  <span class="active_details span3">
	  <span class="user_name" id="span_<?php echo $cluster->cluster_id ?>">
	 
     <?php if($cluster->active==1){?>
			<a onclick="active(0,<?php echo $cluster->cluster_id ?>)" href="javascript:void(0)"><img src="<?php echo base_url();?>/assets/img/btn-green.png"></a>
			
		<?php }else{ ?>
			<a onclick="active(1,<?php echo $cluster->cluster_id ?>)" href="javascript:void(0)"><img src="<?php echo base_url();?>/assets/img/btn-red1.png"></a>
			<?php  } ?>
            
		</span> 
			<a class="divider1" href="<?php echo site_url().'admin/cluster/edit/'.$cluster->cluster_id ;?>"><img src="<?php echo base_url().'uploadimages/site_image/edit.png';?>"/></a>
            
			<a class="divider1" href="javascript:void(0)" onclick="delete_cluster(<?php echo $cluster->cluster_id ?>)"><img src="<?php echo base_url().'uploadimages/site_image/delete.png';?>"/></a>
			</span></li>
        
        <?php } }?>
        
      </div>
      
    </div>
    <div class="update_btn"><input type="button" value="Submit" onClick="sort_cluster()"/></div>
  </div>
  <?php //echo $links;?> 
  </div>
  </div>
</div>