<?php $site=site_url().'admin/csvupload/logoupload';?>

<div class="container">
  <div class="hero-unit">
  
     <h4>CSV file SuccessFully upload  plz Upload Restaurant Logo</h4>
     <br />
    <form class="edit_form" action="<?=$site;?>" method="post" enctype="multipart/form-data">
      <h5>Select Restaurant Logo files</h5>
      <input type="file" name="userfile" class="fileUpload" multiple >
      <input id="px-submit" type="submit" value="Upload" />
      <br />
      <?php if(!empty($error)){echo $error;} ?>
    </form>
  </div>
</div>
