<?php $site=site_url().'admin/admin_home/'; ?>
<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>
<script type="text/javascript">

function state(){
	
 var form_data = {
    state: $('#state_id').val()
   
 };

$("#loder").show();
$.ajax({
       url:'<?php echo $site.'get_city';?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		   
		  
		   var newdata= jQuery.parseJSON(data);
		   $("#loder").hide();
		   $("#city").empty();
		   $.each(newdata,function(i,index){
                //alert(index['city']+'state code'+index['state_code']);
				htmlString="<option value='"+index['city_id']+"'>"+index['city']+"</option>"
				$("#city").append(htmlString);
           });
		   
       }
});
}


function add_photo()
{ 
	var id=$('#counter').val();
	photo='<input type="file" name="userfile'+id+'" value=""  /><br>';	
	  $('#counter').val(Number(id)+1)
	  $('#more_photo').append(photo);
	
}

/*
function add(address){
		var geocoder;
		var map;
		function initialize() {
		  geocoder = new google.maps.Geocoder();
		  var latlng = new google.maps.LatLng(-34.397, 150.644);
		  var mapOptions = {
			zoom: 8,
			center: latlng,
			mapTypeId: google.maps.MapTypeId.ROADMAP
		  }
		  map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);
		}
		
		var geocoder = new google.maps.Geocoder();
		
		geocoder.geocode( { 'address': address}, function(results, status) {
		  var location = results[0].geometry.location;
		 $('#latitude').val(location.lat());
		  $('#longitude').val(location.lng());
		});

 }*/
</script>

<!--Menu Functionalty -->
<script type="text/javascript">
  $().ready(function() {
	  
	
	
	  
   $('#add').click(function() {
    return !$('#select1 option:selected').remove().appendTo('#select2');
   });
   
   
   
   
   $('#remove').click(function() {
    return !$('#select2 option:selected').remove().appendTo('#select1');
   });
   
   
   
   $('#add_new_menu').click(function() {
	   var menu_val=$('#menu_add').val()
	   if(menu_val!='')
	   {
	    var form_data = {
          menu_name: menu_val
	     };
	    $.ajax({
          url:'<?php echo $site.'add_menu';?>',
            data:form_data,    
              datatype:'json',
                success:function(data){
				$('#menu_add').val("");
		         $('#select1').append('<option value='+data+'>'+menu_val+'</option>');
				 $('#menu_msg').html('Success Fully Add  Menu')
			   }//End Success
	      }); //End Ajax
	  } //End If
	  else{
		  $('#menu_msg').html('Plz Enter Menu Name')
		  }
	  
   });
   
   
   
   
  });
 </script>

<div class="container">
  <div class="hero-unit">
    <h3>ADD Restaurants </h3>
    <br />
    <?php 
	$att=array('class'=>'edit_form');
	echo form_open_multipart('admin/admin_home/index',$att); ?>
    <h5>Restaurant Type</h5>
    <select name="restaurant_type">
      <?php if(set_value('restaurant_type')!=''){ ?>
      <option value="<?php echo set_value('restaurant_type'); ?>"><?php echo set_value('restaurant_type'); ?></option>
      <?php }?>
      <option value="Basic">Basic</option>
      <option value="Standard">Standard</option>
      <option value="Premium">Premium</option>
    </select>
    <?php echo form_error('restaurant_type'); ?>
    <h5>Owner name</h5>
    <select name="owner_id">
      <option value="<?php echo set_value('owner_id'); ?>"> Select Resturant Owner</option>
      <?php
foreach($owner as $user)
echo '<option value="'.$user->user_id.'" >'.$user->user_name.'</option>';?>
    </select>
    <?php echo form_error('owner_id'); ?>
    <h5>Restaurant Name</h5>
    <input type="text" name="restaurant_name" value="<?php echo set_value('restaurant_name'); ?>"  />
    <?php echo form_error('restaurant_name'); ?>
    
    <h5>Restaurant Logo</h5>
    <input type="file" name="userfile" value=""  />
    <?php if(!empty($error)) echo $error; ?>
    <br />
    <br />
    <h5>Website</h5>
    <input type="text" name="restaurant_website" value="<?php echo set_value('restaurant_website'); ?>"  />
    <?php echo form_error('restaurant_website'); ?>
    <h5>Address</h5>
        
    <textarea id="address"   name="restaurant_address"><?php echo set_value('restaurant_address'); ?></textarea>
    <?php echo form_error('restaurant_address'); ?>
    <h5>State</h5>
    <select name="state_id" onchange="state()" id="state_id">
      <option value="<?php echo set_value('state_id'); ?>"> Select State</option>
      <?php
foreach($state as $state)
echo '<option value="'.$state->state_code.'" >'.$state->state.'</option>';?>
    </select>
    <div id='loder' style="display:none;"><img  src="<?php echo base_url().'ajax-loader.gif'; ?>"/></div>
    <?php echo form_error('state_id'); ?>
    <h5>City</h5>
    <select name="city_id" id="city">
      <option value="<?php echo set_value('city_id'); ?>"> Select City</option>
    </select>
    <?php echo form_error('city_id'); ?>
    <h5>Zip Code</h5>
    <input type="text" name="zip_code" value="<?php echo set_value('zip_code'); ?>"  />
    <?php echo form_error('zip_code'); ?>
    
    <h5>FaceBook Url</h5>
    <input type="text" name="restaurant_facebook_url" value="<?php echo set_value('restaurant_facebook_url'); ?>"  />
    <?php echo form_error('restaurant_facebook_url'); ?>
    <h5>Twitter Url </h5>
    <input type="text" name="restaurant_twitter_url" value="<?php echo set_value('restaurant_twitter_url'); ?>"  />
    <?php echo form_error('restaurant_twitter_url'); ?> 
    
    <!--#########--MULTI SELECT MENUS DIV--##################-->
    
   <?php /*?> <h5>Restaurant Menus</h5>
    <div style="float:left">
      <select multiple id="select1">
        <?php  foreach($menus as $menus){?>
        <option value="<?=$menus->menu_id;?>">
        <?=$menus->menu_name;?>
        </option>
        <?php }?>
      </select>
      <br />
      <a href="javascript:void(0)" id="add">add &gt;&gt;</a> </div>
    <div style="float:left">
      <select multiple id="select2" name="select_menu[]">
      </select>
      <br />
      <a href="javascript:void(0)" id="remove">&lt;&lt; remove</a> </div>
    <?php echo form_error('select_menu'); ?>
    <div style="clear:both"> <span id=menu_msg></span><br />
      <h5>Add New Menu</h5>
      <input type="text"  value="" id="menu_add" />
      <input class="btn btn-primary btn-large" id="add_new_menu" type='button' value="Submit" />
    </div><?php */?>
    <!--#########--END MULTI SELECT MENUS DIV--##################--> 
    
   
    <h5>Contact No</h5>
    <input type="text" name="restaurant_phone" value="<?php echo set_value('restaurant_phone'); ?>"  />
    <?php echo form_error('restaurant_phone'); ?>
    <h5>Discription</h5>
     
     <textarea name="restaurant_desc" id="content" ><?php echo set_value('restaurant_desc'); ?></textarea>
<?php echo display_ckeditor($ckeditor); ?> <br />
    <?php echo form_error('restaurant_desc'); ?>
    <h5>Active</h5>
    <span>Yes</span>
    <input type="radio" name="restaurant_is_active" checked="checked" value="1" />
    <span>No</span>
    <input type="radio" name="restaurant_is_active"  value="0" />
    <?php echo form_error('restaurant_is_active'); ?>
    <br />
    <h5>Gallery Image</h5>
    <input type="file" name="userfile1"  />
    <?php echo form_error('userfile1'); ?>
    <input type="hidden" id='counter' value="2"  />
     <br>
    <br />
    <div class="more_photo" id="more_photo"></div>
   <br>
    <div class="add_photo btn btn-primary" id="add_photo" onclick="add_photo()">Add more Photo</div>
    <br />
    <br>
    <div>
      <input class="btn btn-primary btn-large" type="submit" name='' value="Submit" />
    </div>
  </div>
</div>
