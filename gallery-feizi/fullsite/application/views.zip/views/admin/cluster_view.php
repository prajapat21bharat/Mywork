<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$site=site_url()."admin/cluster/";
 ?>
<script>

<!----Get All Cluster accroding to State Code ------>
function cluster(){
 var form_data ={state: $('#input_ststes').val()};

$("#loder").html('<img  src="<?php echo base_url().'/ajax-loader.gif'; ?>"/>');
$.ajax({
       url:'<?=$site.'index'?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		    var newdata= jQuery.parseJSON(data);
		   $("#loder").empty();
		   $("#sortable1").empty();
		   if(newdata!=''){
		   $.each(newdata,function(i,index){
                html = '<li class="ui-state-default"  id="'+index['cluster_id']+'">';
                 html += '<span class="restaurant_name span3"><a href="<?php echo site_url().'admin/cluster/edit/';?>'+index['cluster_id']+'">'+index['cluster_name']+'</a></span>';
				  html += '<span class="user_name span3">'+index['city_count']+'</span> ';
         		 html += '<span class="user_name span3">'+index['restaurant_count']+'</span> ';
				 html +='<span class="active_details span3">';
				 html += '<span class="user_name action_menu" id="span_'+index['cluster_id']+'">';
				 if(index['active']==1){
					html += '<a onclick="active(0,'+index['cluster_id']+')" href="javascript:void(0)" class="replace-border"><img src="<?php echo base_url();?>/assets/img/btn-green.png"></a>'
			
				}else{
				   html += '<a onclick="active(1,'+index['cluster_id']+')" href="javascript:void(0)"><img src="<?php echo base_url();?>/assets/img/btn-red1.png"></a>';
				 
				 }
				 html += '</span>';
				 html +='<a href="<?php echo site_url().'admin/cluster/edit/';?>'+index['cluster_id']+'"><img src="<?php echo base_url().'uploadimages/site_image/edit.png';?>"/></a>'
				 html +='<a href="javascript:void(0)" onclick="delete_cluster('+index['cluster_id']+')"><img src="<?php echo base_url().'uploadimages/site_image/delete.png';?>"/></a>';
				 html +='</span></li>';
				$("#sortable1").append(html);
		    });
		 }else{$("#sortable1").html('<div class="error"><h4>No Data Found</h4></div>'); }
        }
    });
}
<!---END---->


<!--- THis Function use to  Cluster Sorting--->
$(function() {
	$( "#sortable1" ).sortable({
	connectWith: ".connectedSortable"
	}).disableSelection();
});
<!------END----->



<!----This Function use to Active and deactive cluster------>

function active(active_val,cluster_id){
var form_data ={active_val:active_val,cluster_id:cluster_id};
$.ajax({
       url:'<?=$site.'active'?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		   var html;
		   if(active_val==1){
			   html = '<a onclick="active(0,'+cluster_id+')" href="javascript:void(0)"><img src="<?php echo base_url();?>/assets/img/btn-green.png"></a>'
			   
			   }else{
				    html = '<a onclick="active(1,'+cluster_id+')" href="javascript:void(0)"><img src="<?php echo base_url();?>/assets/img/btn-red1.png"></a>'
				   }
				$("#span_"+cluster_id).html(html);   
		 }
  });


}
<!----END----->


<!----This Function use to DELETE cluster------>

function delete_cluster(cluster_id){
	var r=confirm("Delete This Cluster !");
if (r==true)
  {
var form_data ={cluster_id:cluster_id};
$.ajax({
       url:'<?=$site.'delete'?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		  $("#"+cluster_id).remove(); 
		 }
  });
  }


}
<!----END----->


<!----This Function use to Sorting cluster------>

function sort_cluster(){
	
	var data_array = new Array();
	var oder_no=0;
	$( "#sortable1 li" ).each( function( index, element ){
	  var id=this.id;
	    data_array[index] = {cluster_id: id,
						order_no:$('#'+id).index()+1 };
						
	     }); 
		 
	
var form_data ={data:data_array};
$.ajax({
       url:'<?=$site.'sort_cluster'?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		  $("#msg").html("Cluster Successfully Sorted ! "); 
		 }
  });


}
<!----END----->
</script>

<div class="container-fluid content-wrapper cluster_container mob-right-part span10">
  <div class="hero-unit" id="dragable">
    <h3 class="title">Cluster</h3>
    <div class="white_bg back_color">
   
     <a class="add_restaurant_btn" href="<?php echo $site.'add_cluster'?>">Add Cluster</a>
     
      <div class="rest_search">
        <div class="rest_fliter_city ">
          <label>State</label>
          <select id="input_ststes" class="select-State" onChange="cluster()">
            <?php	
			
				foreach($states as $data){
					if($this->uri->segment('4')!='')
					{ 
					
					 if($this->uri->segment('4')==$data->state_code)
						echo '<option selected="selected" value="'.$data->state_code.'">'.$data->state.'</option>';
					else{ echo '<option value="'.$data->state_code.'">'.$data->state.'</option>';  }
					
					
					}else{
				echo '<option value="'.$data->state_code.'">'.$data->state.'</option>';
					}
			   }?>
          </select>
        </div>
         <div id="msg" class="success"></div>
        <div id="loder"></div>
      </div>
      <div id="msg"></div>
      <table width="100%" class="table table-striped table-bordered table-radmin">
        <thead>
          <tr>
            <th width="40%">Cluster Name</th>
            <th width="20%">No of City</th>
            <th width="20%">No of Restaurant</th>
            <th width="20%">Action</th>
          </tr>
        </thead>
      </table>
      <div id="cluster_result">
        <div id="sortable1"  class="connectedSortable" >
          <?php
	  if(!empty($cluster))
	  {
	  foreach ($cluster as $cluster){ ?>
          <li class="ui-state-default"  id="<?php echo $cluster->cluster_id ?>"> <span class="restaurant_name span3"> <a href="<?php echo site_url().'admin/cluster/edit/'.$cluster->cluster_id;?>"><?php echo $cluster->cluster_name ?></a> </span> <span class="user_name span3 "><?php echo $cluster->city_count ?></span> <span class="user_name span3"><?php echo $cluster->restaurant_count ?></span> <span class="active_details span3"> <span class="user_name action_menu" id="span_<?php echo $cluster->cluster_id ?>">
            <?php if($cluster->active==1){?>
            <a onclick="active(0,<?php echo $cluster->cluster_id ?>)" href="javascript:void(0)" class="replace-border"><img src="<?php echo base_url();?>/assets/img/btn-green.png"></a>
            <?php }else{ ?>
            <a onclick="active(1,<?php echo $cluster->cluster_id ?>)" href="javascript:void(0)"><img src="<?php echo base_url();?>/assets/img/btn-red1.png"></a>
            <?php  } ?>
            </span><a href="<?php echo site_url().'admin/cluster/edit/'.$cluster->cluster_id ;?>"><img src="<?php echo base_url().'uploadimages/site_image/edit.png';?>"/></a> <a href="javascript:void(0)" onclick="delete_cluster(<?php echo $cluster->cluster_id ?>)"><img src="<?php echo base_url().'uploadimages/site_image/delete.png';?>"/></a> </span></li>
          <?php } }else echo '<div class="error"><h4>No Data Found</h4></div>' ?>
        </div>
      </div>
      <div id="sub_btn">
        <input type="button" class="login-btn" value="Order Update" onClick="sort_cluster()"/>
      </div>
    </div>
    <?php //echo $links;?>
  </div>
</div>
</div>
