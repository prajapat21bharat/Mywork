<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>


<link rel="stylesheet" href="<?php echo base_url('assets/css/jquery.datepick.css') ?>">
<script type="text/javascript" src="<?php echo base_url('assets/js/jquery.datepick.js') ?>"></script>
<script type="text/javascript">

$(function() {
    $('#popupDatepicker').datepick();
});
</script>
<div class="container-fluid content-wrapper cluster_container mob-right-part span10">
  <div class="hero-unit">
   
      <h3 class="title">User Information</h3>
   
  <div class="success_msg"> 
    <?php if(!empty($success)){
           echo $success;
	       } ?>
  </div>    
            


       <?php if($user_info){
		  if(!empty($user_info[0]->userfile)){	
		  $image=site_url()."uploadimages/user/".$user_info[0]->userfile; 
		  }else{
		 	$image=$this->session->userdata('user_image');
			 }
	   }?>

     
      <?php if(!empty($error)) echo $error; ?>

         


<!---its is a Profile EDIT Div---> 

  
  <?php $edit=array('class'=>'edit_form white_bg');
    echo form_open_multipart(site_url().'admin/home/user_profile_view/'.$this->uri->segment(4),$edit);?>
  <div class="wit">
    <input type="hidden" name="user_id" value="<?php if($user_info){echo $user_info[0]->user_id;} ?>" />
    
    <label>First Name </label>
    <?php 
	if(set_value('first_name')!=''){
		$name=set_value('first_name');}
	else{
		if($user_info){$name=$user_info[0]->first_name;
		}else{$name='';}
	 }
	?>
    <input type="text" id="firstName" name="first_name" value="<?php echo $name?>"/>
    <?php echo form_error('first_name'); ?></span></p>
    
     <?php 
	if(set_value('last_name')!=''){
		$last_name=set_value('last_name');}
	else{
		if($user_info){$last_name=$user_info[0]->last_name;
		}else{$last_name='';}
	 }
	?>
    </div>
    
    <div class="wit">
    <label>Last Name <sup>*</sup>:</label>
    <input type="text"  id="lastName" name="last_name" value="<?php echo $last_name ?>"/>
   <?php echo form_error('last_name'); ?>
   </div>
   
   
    <?php 
	if(set_value('email')!=''){
		$email=set_value('email');}
	else{
		if($user_info){$email=$user_info[0]->email;
		}else{$email='';}
	 }
	?>
    <div class="wit">
    <label>Email <sup>*</sup>:</label>
    <input type="text"  id="email" name="email" value="<?php echo $email ?>"/>
   <?php echo form_error('email'); ?>
   </div>
   
   <div class="wit">
    <label>Profile Image :</label>
    <input type="file" name="userfile" value="" />
    <img class="profile" src="<?php echo $image?>" height="100px" width="100px"/>
      <?php if($user_info){
		  if(!empty($user_info[0]->userfile)){	
		     $image=site_url()."uploadimages/user/".$user_info[0]->userfile; 
		  }else{ $image=$this->session->userdata('user_image');
			 }
	   }?>
   
    
    
    <?php if(!empty($error)) echo $error; ?>
    <?php echo form_error('userfile'); ?>
    </div>
    
    <div class="wit">
     <?php 
	if(set_value('gender')!=''){
		$gender=set_value('gender');}
	else{
		if($user_info){$gender=$user_info[0]->gender;
		}else{$gender='';}
	 }
	?>    
    <label>Gender :</label>
	
    <input type="radio" name="gender" value="male" <?php if($gender=='male'){ echo 'checked="checked"';}?> />
    <span class="radio-active">Male</span>
    
    
     <input type="radio" name="gender" value="female" <?php if($gender=='female'){ echo 'checked="checked"';}?> />
     <span class="radio-active">Female</span>
     
      </div>
	  
      <div class="wit">
	  <?php 
	if(set_value('date')!=''){
		$date=set_value('date');}
	else{
		if($user_info){$date=$user_info[0]->date;
		}else{$date='';}
	 }
	?>
    <label>Date of Birth <sup>*</sup>:</label>
    <input type="text"  value="<?php echo $date;?>" name="date" id="popupDatepicker"/>
     <?php echo form_error('date'); ?>
     </div>
    
    <div class="wit">
    <?php 
	if(set_value('city')!=''){
		$city=set_value('city');}
	else{
		if($user_info){$city=$user_info[0]->city;
		}else{$city='';}
	 }
	?> 
    <label>City<sup>*</sup>:</label>
    <input type="text" id="city" value="<?php echo $city;?>" name="city"/>
    <?php echo form_error('city');?>
   </div>
   
 <div class="wit">
   <?php 
	if(set_value('state')!=''){
		$state=set_value('state');}
	else{
		if($user_info){$state=$user_info[0]->states;
		}else{$state='';}
	 }
	?> 
    <label>State<sup>*</sup>:</label>
    <input type="text" id="state" value="<?php echo $state;?>" name="state"/>
    <?php echo form_error('state'); ?>
    </div> 
     
     <div class="wit">
      <?php 
	if(set_value('zip')!=''){
		$zip=set_value('zip');}
	else{
		if($user_info){$zip=$user_info[0]->zip;
		}else{$zip='';}
	 }
	?> 
    <label>Zip code<sup>*</sup>:</label>
    <input type="text" id="zip" value="<?php echo $zip; ?>" name="zip"/>
     <?php echo form_error('zip'); ?>
    </div>
    
   <div class="wit">
     <?php 
	if(set_value('user_phone')!=''){
		$user_phone=set_value('user_phone');}
	else{
		if($user_info){$user_phone=$user_info[0]->user_phone;
		}else{$user_phone='';}
	 }
	?> 
    <label>Mobile Number for notifications <sup>*</sup>:</label>
    <input type="text" name="user_phone" value="<?php echo $user_phone; ?>"  />
     <?php echo form_error('user_phone');?>
    </div>
   <div class="login_button">
    <input type="submit" value="Save" name=" " class="login-btn " />
    
    </div>
    <?php echo  form_close();?>
    
  
          
            
      </div>      

 </div>
 </body>
</html>
