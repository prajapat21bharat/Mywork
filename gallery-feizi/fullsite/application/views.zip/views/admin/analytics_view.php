<?php $site=site_url().'admin/csvupload/csv_upload';?>
<div class="container-fluid content-wrapper mob-right-part span10">
  <div class="hero-unit">
  <h4 class="title">Analytics</h4>
    
   <iframe src="<?php echo site_url(); ?>/analytics/index.php?module=Widgetize&action=iframe&moduleToWidgetize=Dashboard&actionToWidgetize=index&idSite=1&period=week&date=yesterday" frameborder="0" marginheight="0" marginwidth="0" width="100%" height="1200px"></iframe>
     
  </div>
</div>

