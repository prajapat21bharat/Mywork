<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

<div class="container-fluid content-wrapper mob-right-part span10">
<div class="hero-unit">
  <?php $this->load->view('admin/restaurant_preview/edit_resturant_header.php') ?>
  <h4 class="title">Restaurant Reservation</h4>
  <div class="white_bg">
    <div id="hide_form" >
      <?php 
   
     echo form_open(site_url().'admin/reservation/');?>
      <div id="disp" class="error"></div>
      <label>Restaurant Reservation Link </label>
      <textarea name="reservation_link" id="reservation_link"><?php if(!empty($reservation[0]))echo $reservation[0]->reservation_text?>
</textarea>
      <span id="reservation_link"> <?php echo form_error('reservation_link'); ?></span>
      <input type="submit"  name="reservation" value="Save" class="login-btn" id="reservation"/>
      <?php echo form_close();
 	   ?> </div>
  </div>
</div>
