<?php $site=site_url().'admin/menu_item/'; ?>
<script type="text/javascript">
  $().ready(function() {
	  
	$("#select1").change(menu_item_val);
    menu_item_val();
   
   
   /*############################################################################
     #   THIS Fnnction Use To Delete Menu Item In Menu Table Accoroding To menu #
	 ############################################################################*/
   /*$('#remove').click(function() {
	   var menu_item_id = $("#select2").val() || [];
	   //var   menu_id=$("#select1").val()
	     var form_data = {menu_item_id:menu_item_id,
		                  menu_id:$("#select1").val()
		 					
						};
						$.ajax({
							  url:'<?php echo $site.'delete_menu_item';?>',
								data:form_data,    
								  datatype:'json',
									success:function(data){
										
									 $("#select2").empty();
									var newdata=jQuery.parseJSON(data);
									 $.each(newdata,function(i,index){
									 htmlString="<option value='"+index['menu_item_id']+"'>"+index['menu_item_name']+"</option>"
								     $("#select2").append(htmlString);
									   });
								   }//End Success
							  }); //End Ajax
	
   });*/
   /*############################################################################
     #  END DELETE MENU FUNCTION                                                #
	 ############################################################################*/
   
   
   $('#add_new_menu_item').click(function() {
	  var menu_item_name= $('#menu_item_add').val();
	   if(menu_item_name!='')
	   {
	    var form_data = {
          menu_item_name: menu_item_name,
		  menu_id:$('#select1 option:selected').val()
	     };
	    $.ajax({
          url:'<?php echo $site.'add_menu_item';?>',
            data:form_data,    
              datatype:'json',
                success:function(data){
					$('#menu_item_add').val("");
				 $('#select2').append('<option value='+data+'>'+menu_item_name+'</option>');
				 $('#menu_msg').html('Success Fully Add  Menu')
			   }//End Success
	      }); //End Ajax
	  } //End If
	  else{
		  $('#menu_msg').html('Plz Enter Menu Name')
		  }
	  
   });
   
   
   
   
  });
  
  
function menu_item_val() {
				
				var form_data = {
							   menu_id:$("#select1").val()
							 };
							$.ajax({
							  url:'<?php echo $site.'get_menu_item';?>',
								data:form_data,    
								  datatype:'json',
									success:function(data){
										$("#select2").empty();
										
									var newdata=jQuery.parseJSON(data);
									 $.each(newdata,function(i,index){
									 htmlString="<option value='"+index['menu_item_id']+"'>"+index['menu_item_name']+"</option>"
								     $("#select2").append(htmlString);
									   });
								   }//End Success
							  }); //End Ajax
		}
  
  
  
  
  
 </script>

<div class="container">
  <div class="hero-unit"> <?php echo form_open() ?>
    <div style="float:left">
      <select id="select1" >
        <?php  foreach($menus as $menus){?>
        <option value="<?=$menus->menu_id;?>">
        <?=$menus->menu_name;?>
        </option>
        <?php }?>
      </select>
      <br />
    </div>
    <div style="float:left">
      <select multiple id="select2" name="select_menu[]" style="height:200px">
      </select>
      <br />
      <?php /*?>  <a href="javascript:void(0)" id="remove">&lt;&lt; remove</a><?php */?>
    </div>
    </form>
    <div style="clear:both"> <?php echo form_open() ?>
      <h3>Add New Menu_item</h3>
      <span id=menu_msg></span><br />
      <input type="text"  value="" id="menu_item_add" />
      <input class="btn btn-primary btn-large" id="add_new_menu_item" type='button' value="Submit" />
      </form>
    </div>
  </div>
</div>
