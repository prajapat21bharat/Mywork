<?php $site=site_url().'admin/cluster/'; ?>
<script type="text/javascript">
<!--- THis Function use to Get All city Accroding to state--->
function state(){
	
 var form_data = {state: $('#input_ststes').val()};
$("#loder").html('<img  src="<?php echo base_url().'/ajax-loader.gif'; ?>"/>');
$.ajax({
       url:'<?=$site.'cluster_city'?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		    var newdata= jQuery.parseJSON(data);
		   $("#loder").empty();
		   $("#sortable1").empty();
		   $.each(newdata,function(i,index){
                htmlString="<li  class='ui-state-default' id='"+index['city_id']+"'>"+index['city']+"</li>"
				$("#sortable1").append(htmlString);
           });
       }
});
}
<!--- END--->



$(function() {
$( "#sortable1, #sortable2" ).sortable({
connectWith: ".connectedSortable"
}).disableSelection();

});


function update(){
	
	
	var input_city = new Array();
	var oder_no=0;
   $( "#sortable2 li" ).each( function( index, element ){
	  var id=this.id;
	    input_city[index] = {city_id: id };
	 });
	 
var form_data = {input_city: input_city,
				cluster_id:'<?php echo $this->uri->segment('4');?>',
				cluster_name:$("#cluster_name").val(),
				input_ststes:$("#input_ststes").val()};
 $.ajax({
       url:'<?=$site.'update_cluster'?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		 //$("#success").html("Successfully Update");  
		 window.location.href="<?php echo $site.'index/'?>"+$("#input_ststes").val();
       }
   });
}

</script>

<div class="container-fluid content-wrapper mob-right-part span10">
  <div class="hero-unit" id="dragable">
  
  
  <h4 class="title">Edit Cluster</h4>
  
  <div class="">
    <div id="success" class="success"></div>
   
    
    
    <form  class="edit_form white_bg" action="" method="post">
    
   <div class="wit">
    <label>Cluster Name</label>
    <input type="text"  name="cluster_name" value="<?php echo $cluster[0]->cluster_name; ?>" id="cluster_name"  />
     <?php echo form_error('cluster_name'); ?>
   </div>
   
   <div class="wit">
    <label>State</label>
     <select id="input_ststes" name="input_ststes" class="connectedSortable select-State" onChange="state()">
          <?php	
			  
				foreach($states as $data){
					if($data->state_code==$cluster[0]->cluster_state_code)
					echo '<option selected="selected" value="'.$data->state_code.'">'.$data->state.'</option>';
					else
				echo '<option value="'.$data->state_code.'">'.$data->state.'</option>';
			   }?>
        </select>
        <?php echo form_error('input_ststes'); ?>
        <div id="loder" class="loder_add_cluster"></div>
        </div>
   
    
 
     <label class="city_label">City</label>
     
     <div id="sortable2" class="connectedSortable cluster_edit_city city_answer1">
     <?php foreach($cluster as $cluster){ ?>
     <li class="ui-state-default" id="<?php echo $cluster->city_id ?>"><?php echo $cluster->city ?></li>
      <?php }?>
      </div>
       <?php echo form_error('input_city'); ?>
       
       
       
       <div id="sortable1" class="connectedSortable cluster_edit_city city_answer" >
       <?php foreach($city as $city){ ?>
         <li  class="ui-state-default" id="<?php echo $city->city_id ?>"><?php echo $city->city ?></li>
      <?php }?> 
       </div>
       
       
      
     <div class="login_button">
     
      <input type="button" onclick="update()" value="Submit" name="" class="login-btn">
      <a href="<?php echo $site.'index/'.$cluster->cluster_state_code; ?>"><input type="button" onclick="update()" value="Cancel" name="" class="login-btn"></a> 
    </div>
   
  </form>
    
    
    
     </div>
</div>
