<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<script>
$(function(){
	$('body').addClass('bg_image');
	});
</script>
<div class="container">
	<div class="hero-unit" id="log_in">
    <h2>Restaurant Owner Login</h2>
 <?php echo form_open('owner/login/check_login');
 if(!empty($error))
 echo $error;
 
 ?>
 <div id="" class="log_in">
    <label>User Name </label>
   <input type="text" id="user_name" name="user_name" value="<?php echo set_value('user_name'); ?>"/>
    <p><span id="txtFirstName"> <?php echo form_error('user_name'); ?></span></p>
    
    
  <label>Password</label>
   <input type="password" name="password" value="<?php echo set_value('password'); ?>" />
   <p><span id="password"> <?php echo form_error('password'); ?> </span></p></td>
  <label></label> <input type="submit" name="login" value="Login" class="btn btn-primary" />  
 </div>
 <?php echo form_close();
  ?>
 
 </div>
 </div>