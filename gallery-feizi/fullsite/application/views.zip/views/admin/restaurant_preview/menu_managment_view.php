<?php $site=site_url().'owner/'; ?>
<script type="text/javascript">
  $().ready(function() {
	  //alert('sada');
	
	$('#add').click(function() {
    return !$('#select1 option:selected').remove().appendTo('#select2');
   });
   
   
   
   
   $('#remove').click(function() {
    return !$('#select2 option:selected').remove().appendTo('#select1');
   });
   
   
   
   $('#add_new_menu').click(function() {
	   var menu_val=$('#menu_add').val()
	   if(menu_val!='')
	   {
	    var form_data = {
          menu_name: menu_val
	     };
	    $.ajax({
          url:'<?php echo $site.'home/add_menu';?>',
            data:form_data,    
              datatype:'json',
                success:function(data){
				$('#menu_add').val("");
		         $('#select1').append('<option value='+data+'>'+menu_val+'</option>');
				 $('#menu_msg').html('Success Fully Add  Menu')
			   }//End Success
	      }); //End Ajax
	  } //End If
	  else{
		  $('#menu_msg').html('Plz Enter Menu Name')
		  }
	  
   });
   
  
 
   
   
  });
	
		function menu(){
		   var opt_vals = [];
		
		     $('#select2 option').each(function() {
		       opt_vals.push($(this).val());
		     });
		
		  var dataToSend = {'select_menu' : opt_vals} ;
		      $.ajax({
		            type: "post",
		              url:'<?php echo $site.'home/menu_update';?>',
		               data:dataToSend,    
		                datatype:'json',
		                success:function(data){
		                   $('#menu_update').html('Success Fully  Menu Update');
		                  }
		        });
		
		}
 </script>

<div class="container-fluid content-wrapper">
  <div class="hero-unit"> 
   <?php include('edit_resturant_header.php') ?>
    <h3 id="menu_update">  </h3>
    
    <h4>Edit Restaurant Menus:</h4>
    <?php echo form_open_multipart('owner/home/menu_manage/'.$this->uri->segment(4)); ?> 
    
    <!--#########--MULTI SELECT MENUS DIV--##################-->
    
    <h5>Restaurant Menus</h5>
    <div style="float:left">
      <select multiple id="select1">
        <?php  foreach($menus as $menus){?>
        <option value="<?=$menus->menu_id;?>">
        <?=$menus->menu_name;?>
        </option>
        <?php }?>
      </select>
      <br />
      <a href="javascript:void(0)" id="add">add &gt;&gt;</a> </div>
    <div style="float:left">
      <select multiple id="select2" name="select_menu[]">
        <?php  foreach($restaurant_menu as $restaurant_menu){?>
        <option selected="selected" value="<?=$restaurant_menu->menu_id;?>">
        <?=$restaurant_menu->menu_name;?>
        </option>
        <?php }?>
      </select>
      <br />
      <a href="javascript:void(0)" id="remove">&lt;&lt; remove</a> </div>
    <?php echo form_error('select_menu'); ?>
    <div style="clear:both"> <span id=menu_msg></span><br />
      <h5>Add New Menu</h5>
      <input type="text" name="menu_name" value="" id="menu_add" />
      <input class="btn btn-primary" id="add_new_menu" type='button' value="Submit" />
    </div>
    <!--#########--END MULTI SELECT MENUS DIV--##################-->
    
    <div>
      <input class="btn btn-primary btn-large" type="button" onclick="menu()" name='' value="Submit" />
    </div>
  </div>
</div>
