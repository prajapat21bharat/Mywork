<?php $site=site_url().'admin/'; ?>

<script type="text/javascript">
function smsquota(){
	
	if($.isNumeric($('#no_sms').val())) {
		var form_data = {no_sms:$("#no_sms").val()};
		$.ajax({
			   url:'<?=$site.'/smsquota/updatesmsquota';?>',
			   data:form_data,    
			   datatype:'json',
			   success:function(data){
				   if(data==1)
				   {
			      $(".Success_msg").html('SMS Quota Successfully Inserted');
				   }else{$(".Success_msg").html('SMS Quota Successfully Inserted');}
			 }
		   });
		   }
		
	else       {
				$(".Success_msg").html('Please enter only Numeric value');
				}
	}
		
</script>
<div class="container-fluid content-wrapper mob-right-part span10">
  <div class="hero-unit">
    <?php $this->load->view('admin/restaurant_preview/edit_resturant_header.php'); ?>

     <h4 class="title">SMS Quota</h4>
      <div class="white_bg">
    <span class="Success_msg"></span>
  
    <div class="count_subscribe">Sent SMS : <?php if(!empty($no_sms[0]->sent_sms)) echo $no_sms[0]->sent_sms;else{ echo 0;}?></div>
  
   	SMS Quota
     <input type="text" id="no_sms" value="<?php if(!empty($no_sms[0]->no_of_sms)){echo $no_sms[0]->no_of_sms;}?>" />
     <input type="button" value="Update" onclick="smsquota()" class="login-btn" />
     </div>
  </div>
</div>
