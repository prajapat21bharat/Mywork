<?php $site=site_url().'admin/offers/'; ?>

<!--------------Date and Time ---------------->

<link href="<?php echo base_url('assets/'); ?>/css/jquery.timepicker.css" rel="stylesheet" />

<link href="<?php echo base_url('assets/'); ?>/css/base.css" rel="stylesheet"/>

<!--------------END Date and Time ---------------->

<script type="text/javascript" src="<?php echo base_url('assets/js/toltip.js') ?>"></script>

<!--------------Date and Time ---------------->

<script src="<?php echo base_url('assets/js/date_time.js') ?>"></script>

<script type="text/javascript" src="<?php echo base_url('assets/js/jquery.timepicker.js') ?>"></script>

<script type="text/javascript" src="<?php echo base_url('assets/js/base.js') ?>"></script>

<!--------------END Date and Time ---------------->

<script type="text/javascript">



$(function() {

			$('#basicExample').timepicker();

		  });



function delete_image(id)

{

	var form_data = {

    photo_id: id

       };

		$.ajax({

			   url:'<?php echo $site.'delete_offer_gallery';?>',

			   data:form_data,    

			   datatype:'json',

			   success:function(data){

				   $('#'+id).empty();

				   

			   }

		});

}

 </script>



<div class="container-fluid content-wrapper mob-right-part span10">

  <div class="hero-unit"> 

    <?php $this->load->view('admin/restaurant_preview/edit_resturant_header.php') ?><br />

     <h4 class="title">Offer Edit</h4>

    <span id=menu_msg></span><br />

    <?php 

  foreach($offers as $offers){

		  $attr=array('class'=>'edit_form');

 echo form_open_multipart($site.'edit_offer/'.$this->uri->segment(4),$attr)?>

    

    <input type="hidden" name="restaurant_id" value="<?php echo $offers->ID; ?>" />

    <div class="wit"> <label>Date</label>

    <span data-language="javascript" class="datepair">

      <input type="text" class="date start" name="start_date" value="<?php echo $offers->start_date; ?>">

     

      <input type="hidden" class="time start ui-timepicker-input" value="<?php echo $offers->start_time; ?>" autocomplete="off" name="start_time">

       to

      <input type="hidden" class="time end ui-timepicker-input" value="<?php echo $offers->end_time; ?>" autocomplete="off" name="end_time">

     

      <input type="text" class="date end" value="<?php echo $offers->end_date; ?>" name="end_date">

     </span>

      <?php echo form_error('start_date'); ?> <?php echo form_error('start_time'); ?> <?php echo form_error('end_time'); ?> <?php echo form_error('end_date'); ?></div>

   <div class="wit"> <label>Title</label>

    <input type="text" name="offer_title" value="<?php echo $offers->offer_title; ?>" />

    <?php echo form_error('offer_title'); ?></div>

   

   <div class="wit"> <label>Web Site</label>

    <input type="text" name="offer_website" value="<?php echo $offers->offer_website; ?>" />

    <?php echo form_error('offer_website'); ?></div>

   <div class="wit"> <label>Description</label>    

    <textarea name="offer_description" id="content" ><?php echo $offers->offer_description; ?>

    </textarea>

<?php echo display_ckeditor($ckeditor); ?> <br />

    <?php echo form_error('offer_description'); ?></div>

   <div class="wit">
    <label>Event Image</label>

    <input type="file" name="userfile1"  />

    <?php if(!empty($error))echo $error; ?>

   

            <?php

foreach($offers_photo as $photo)

{?>
               <div id="<?php echo $photo->offers_photo_id; ?>" class="show_image_tag">
                  <div class="mediaholder_innerwrap"> <img style="height:150px; width:100%;" alt="" src="<?=base_url().'uploadimages/offer_image/'.$photo->image?>" ></div>
               
                <div class="detailholder">
                  <h4 class="showbiz-title txt-center delete_btn"><a class="login-btn" href="javascript:void(0)"  onclick="delete_image(<?=$photo->offers_photo_id?>)">Delete</a></h4>
                </div>
                </div>
                
 <?php } ?>

         
    </div>

   <div class="wit"> <label>Active</label>

   <span class="radio-active">Yes</span>

    <input type="radio" name="active" <? if($offers->active=='1')echo 'checked="checked"';?> value="1" />

   <span class="radio-active"> No</span>

    <input type="radio" name="active" <? if($offers->active=='0')echo 'checked="checked"';?>  value="0" />

    </div>

    <div id="sub_btn">

    <input class="login-btn" type="submit"  value="Save" />

     <a href="<?php echo $site;?>"><input class="login-btn" type="button"  value="Cancel" /></a>

     </div>

    </form>

    <?php }?>

  </div>

</div>