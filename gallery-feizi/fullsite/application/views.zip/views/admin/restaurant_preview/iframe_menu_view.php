<?php $site=site_url().'admin/iframe/color_update' ?>
<script>
function color(){

	  var form_data = {menu_color: $("#colorpickerField1").val(),
		  				sub_menu:$("#colorpickerField2").val()};
	    $.ajax({
          url:'<?php echo $site;?>',
            data:form_data,    
              datatype:'json',
                success:function(data){
				 var iframe = document.getElementById('phonePreview')
   				iframe.innerHTML = iframe.innerHTML;
			   }//End Success
	      }); //End Ajax
	 
}


</script>

<div class="container-fluid content-wrapper mob-right-part span10">
  <div class="hero-unit">
    <?php $this->load->view('admin/restaurant_preview/edit_resturant_header.php');
	$sagment=$this->uri->segment('3');
$WidgetMenuIcon=site_url()."iPhoneSpringboard/images/icon_menu.png";	
$Widget_url=site_url().'widget_iframe/'.$widget_id.'/'.str_replace('=','',base64_encode($this->session->userdata('restaurant_id')));
	 ?>
    <h4 class="title">Widget</h4>
    <div class="white_bg">
      <div class="menu_itemshow"> 
      <a class="login-btn <? if($sagment==''){echo 'active';}?> login-btn" href="<?php echo site_url().'admin/iframe/' ?>">Menu Widget</a> 
      <a class="<? if($sagment=='special_offer'){echo 'active';}?> login-btn" href="<?php echo site_url().'admin/iframe/special_offer'; ?>">Special Offer Widget</a>
       <a class="<? if($sagment=='events'){echo 'active';}?> login-btn" href="<?php echo site_url().'admin/iframe/events';?>">Events Widget</a> 
       <a class="<? if($sagment=='gallery'){echo 'active';}?> login-btn" href="<?php echo site_url().'admin/iframe/gallery' ;?>">Gallery Widget</a> 
       <a class="<? if($sagment=='about_us'){echo 'active';}?> login-btn" href="<?php echo site_url().'admin/iframe/about_us' ;?>">About us Widget</a> 
       </div>
      <div class="iframe_div">
        <div class="form_div span3">
          <?php if($widget_id=='menu'){ 
	
	if(!empty($manu_color)){
		$menu=$manu_color[0]->menu_colour;
		$submenu=$manu_color[0]->sub_menu_colour;
	}else{$menu='FF6600';
		$submenu='333';}
	?>
          <label>Menu background color</label>
          <input type="text" maxlength="6"  size="6" id="colorpickerField1" value="<?php echo $menu ; ?>" />
          <label>Sub Menu color</label>
          <input type="text" maxlength="6"  size="6" id="colorpickerField2" value="<?php echo $submenu ; ?>" />
          <?php } ?>
          <label>HTML Code :</label>
          <textarea rows="10px" id="iframe_value"  class="html_code">
 <iframe width="100%" height="575" frameborder="0" src="<?php echo site_url().'Widget_iframe/'.$widget_id.'/'.str_replace('=','',base64_encode($this->session->userdata('restaurant_id')));?>"></iframe>
 
 </textarea>
        </div>
        <div id="phonePreview" class="span5" style="height:720px; float:right">
          <iframe runat="server" id="frameGranite" style="width:100%; height:100%; border:0px solid #fff;" src="<?php echo site_url(); ?>/iPhoneSpringboard/index.php?title=<?php echo $widget_id?>&amp;href=<?php echo $Widget_url;?>&amp;image=<?php echo $WidgetMenuIcon; ?>"> </iframe>
        </div>
      </div>
    </div>
  </div>
</div>
<link rel="stylesheet" href="<?php echo base_url().'color_picker/' ?>css/colorpicker.css" type="text/css" />
<script type="text/javascript" src="<?php echo base_url().'color_picker/' ?>js/colorpicker.js"></script> 
<script type="text/javascript" src="<?php echo base_url().'color_picker/' ?>js/eye.js"></script> 
<script type="text/javascript" src="<?php echo base_url().'color_picker/' ?>js/utils.js"></script> 
<script type="text/javascript" src="<?php echo base_url().'color_picker/' ?>js/layout.js?ver=1.0.2"></script>