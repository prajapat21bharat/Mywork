<?php $site=site_url().'admin/offers/'; ?>
<!--------------Date and Time ---------------->
<link href="<?php echo base_url('assets/'); ?>/css/jquery.timepicker.css" rel="stylesheet" />
<link href="<?php echo base_url('assets/'); ?>/css/base.css" rel="stylesheet"/>
<!--------------END Date and Time ---------------->
<script type="text/javascript" src="<?php echo base_url('assets/js/toltip.js') ?>"></script>
<!--------------Date and Time ---------------->
<script src="<?php echo base_url('assets/js/date_time.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/jquery.timepicker.js') ?>"></script>
<script type="text/javascript" src="<?php echo base_url('assets/js/base.js') ?>"></script>
<!--------------END Date and Time ---------------->
<script type="text/javascript">

$(function() {
			$('#basicExample').timepicker();
		  });
 
 function add_photo()
{ 
	var id=$('#counter').val();
	photo='<input type="file" name="userfile'+id+'" value=""  /><br>';	
	  $('#counter').val(Number(id)+1)
	  $('#more_photo').append(photo);
	
}
 </script>

<div class="container-fluid content-wrapper mob-right-part span10">
  <div class="hero-unit">
    <?php $this->load->view('admin/restaurant_preview/edit_resturant_header.php') ?>
     <h3 class="title">Add New  Offer </h3>
    
    <span id=menu_msg></span>
    
    <?php 
	$attr=array('class'=>'edit_form');
	echo  form_open_multipart($site.'add_offer',$attr)?>
    
     <input type="hidden" name="restaurant_id" value="<?php echo $this->session->userdata('restaurant_id'); ?>" />
     <div class="wit"> <label>Date</label>
    <span data-language="javascript" class="datepair">
      <input type="text" class="date start" name="start_date"  value="<?php echo set_value('start_date'); ?>">
      <input type="hidden" class="time start ui-timepicker-input" name="start_time" value="12:00am" <?php /*?>value="<?php echo set_value('start_time'); ?>"<?php */?> autocomplete="off" >
      to
      <input type="hidden" class="time end ui-timepicker-input" name="end_time" value="11:59pm" <?php /*?>value="<?php echo set_value('end_time'); ?>"<?php */?> autocomplete="off" >
      <input type="text" class="date end" value="<?php echo set_value('end_date'); ?>" name="end_date">
    </span>
    <?php echo form_error('start_date'); ?> <?php echo form_error('start_time'); ?> <?php echo form_error('end_time'); ?> <?php echo form_error('end_date'); ?></div>
   <div class="wit"> <label>Title</label>
    <input type="text" name="offer_title" value="<?php echo set_value('offer_title'); ?>" />
    <?php echo form_error('offer_title'); ?></div>
   
   <div class="wit"> <label>Web Site</label>
    <input type="text" name="offer_website" value="<?php echo set_value('offer_website'); ?>" />
    <?php echo form_error('offer_website'); ?></div>
   <div class="wit"> <label>Description</label>
   
    
    <textarea name="offer_description" id="content" ><?php echo set_value('offer_description'); ?>
    </textarea>
<?php echo display_ckeditor($ckeditor); ?> <br />
    <?php echo form_error('offer_description'); ?></div>
    
    
   <div class="wit"> <label>Event Image</label>
    <input type="file" name="userfile1"  />
    <?php echo form_error('userfile1'); ?>
    <input type="hidden" id='counter' value="2"  />
    <?php /*?><?php if(!empty($error))echo $error; ?>
    <div class="more_photo" id="more_photo"></div>
    <br>
    <div class="add_photo btn btn-primary" id="add_photo" onclick="add_photo()">Add more Photo</div><?php */?>
    </div>
    <div class="wit"><label>Active</label>
   <span class="radio-active"> Yes</span>
    <input type="radio" name="active" checked="checked" value="1" />
   <span class="radio-active"> No</span>
    <input type="radio" name="active"  value="0" /></div>
   
    <div id="sub_btn">
    <input class="login-btn" type="submit"  value="Submit" />
     <a href="<?php echo $site;?>"><input class="login-btn" type="button"  value="Cancel" /></a>
     </div>
    </form>
  </div>
</div>
