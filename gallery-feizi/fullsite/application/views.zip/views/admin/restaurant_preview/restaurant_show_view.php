<?php $site=site_url().'owner/home/'; ?>
<script type="text/javascript">

function restaurant_delete(id)
{
var r=confirm('Are Sure Delete This Restaurant');
if (r==true)
	{
	var form_data = {
		 restaurant:id
		  };
    $.ajax({
       url:'<?php echo $site.'delete_retaurant';?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		  $('#'+id).hide();
		  $('#msg').html('Success Fully Deleted');
       }
     });
}

}

function active(value,rest_id)
{

var form_data = {
		 active:value,
		 rest_id:rest_id
		  };
    $.ajax({
       url:'<?php echo $site.'active_inactive';?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		   
		   if(data!='1')
		   {
			   
            $('#actve_deactive_'+rest_id).html("<a title='Enable' onclick='active(1,"+rest_id+")' href='javascript:void(0)'><img src='<?php echo base_url().'assets/img/btn-red1.png'?>'/></a>");
			   
		   }else{
			       $('#actve_deactive_'+rest_id).html("<a title='Enable' onclick='active(0,"+rest_id+")' href='javascript:void(0)'><img src='<?php echo base_url().'assets/img/btn-green.png'?>'/></a>");
		   }
		  
		
       }
     });


}

$(document).ready(function(){
$('#pagination .active').html('<a href="<?php echo $site.'index/'; ?>">1</a>');
$("#pagination a:last").remove();	
	});
</script>

<div class="container">
  <div class="hero-unit">
    <div id="msg"></div>
    <h4>Restaurant List :</h4>
    <table width="100%" class="table table-striped table-bordered">
      <thead>
        <tr>
          <th width="">Name</th>
          <th class="hidden-tablet hidden-phone" width="">Address</th>
          <th width="">Action</th>
        </tr>
      </thead>
      <?php foreach ($records as $restaurant): ?>
      <tr id='<?php echo $restaurant->ID; ?>'>
        <td><a href="<?php echo $site.'review/'.$restaurant->ID; ?>"><?php echo $restaurant->restaurant_name; ?></a></td>
        <td class="hidden-tablet hidden-phone"><?php echo $restaurant->restaurant_address; ?></td>
          </td>
        <td>
		
		<?php if($restaurant->restaurant_is_active==1){
			
			$active="\"Enable\"";
			$dactive="\"Disable\"";
			
			
			  echo "<span onmouseover='tooltip.show($dactive);' onmouseout='tooltip.hide();'  id='actve_deactive_$restaurant->ID'><a title='Disable' onclick='active(0,$restaurant->ID)' href='javascript:void(0)'><img src='".base_url()."assets/img/btn-green.png'  /></a></span>";
			 
		}else{
			echo  "<span onmouseover='tooltip.show($active);' onmouseout='tooltip.hide();' id='actve_deactive_$restaurant->ID'><a title='Enable'  onclick='active(1,$restaurant->ID)' href='javascript:void(0)'><img src='".base_url()."assets/img/btn-red1.png' /></a></span>"; 
             } ?>
        |
        <a title="Edit" onmouseover='tooltip.show("Edit");' onmouseout='tooltip.hide();' href="<?php echo $site.'review/'.$restaurant->ID; ?>"><img  src="<?php echo base_url().'uploadimages/site_image/edit.png';?>" />
        </a>
        
          <?php /*?>|<a href="javascript:void(0)" onclick="restaurant_delete(<?php echo $restaurant->ID; ?>)">
        <img src="<?php echo base_url().'uploadimages/site_image/delete.png';?>"/></a><?php */?>
        
        
        </td>
      </tr>
      <?php endforeach; ?>
    </table>
    <?php echo $links;?> </div>
</div>
