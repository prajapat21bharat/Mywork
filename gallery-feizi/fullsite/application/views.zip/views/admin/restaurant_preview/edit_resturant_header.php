<h3 class="title"><?php echo $this->session->userdata('restaurant_name'); ?></h3>
<?php $sagment=$this->uri->segment(3);
$sagment2=$this->uri->segment(2)

?>
<div class="menu_itemshow">
<a class="login-btn" href="<?php echo site_url().'admin/preview/review/'.$this->session->userdata('restaurant_id'); ?>">Preview</a>

<a class="login-btn <? if($sagment=='edit_retaurant'){echo 'active';}?>" href="<?php echo site_url().'admin/home/edit_retaurant/'.$this->session->userdata('restaurant_id'); ?>">Restaurant Info</a>
<a class="<? if($sagment2=='header_banner'){echo 'active';}?> login-btn" href="<?php echo site_url().'admin/header_banner'; ?>">Header Banner</a>
 
  <a class="<? if($sagment2=='menu_item'){echo 'active';}?> login-btn" href="<?php echo site_url().'admin/menu_item/index/';?>">Menu Item</a>
 <a class="<? if($sagment2=='about_restaurant'){echo 'active';}?> login-btn" href="<?php echo site_url().'admin/about_restaurant'; ?>">About Restaurant</a>
 
 <a class="<? if($sagment2=='event'){echo 'active';}?> login-btn" href="<?php echo site_url().'admin/event/' ?>">Event</a>
  <a class="<? if($sagment2=='offers'){echo 'active';}?> login-btn" href="<?php echo site_url().'admin/offers/' ?>">Special Offers</a>
  <a class="<? if($sagment2=='reservation'){echo 'active';}?> login-btn" href="<?php echo site_url().'admin/reservation/' ?>">Reservation</a>
   <a class="<? if($sagment2=='iframe'){echo 'active';}?> login-btn" href="<?php echo site_url().'admin/iframe/' ?>">Menu Widget</a>
    <a class="<? if($sagment2=='smscota'){echo 'active';}?> login-btn" href="<?php echo site_url().'admin/smsquota/' ?>">SMS Quota</a>
 </div>
 
 
 