<script type="text/javascript">
function delete_comment(id){
	var form_data = {
	comment_id:id };
		$.ajax({
			   url:'<?=site_url().'owner/gallery/delete_comment';?>',
			   data:form_data,    
			   datatype:'json',
			   success:function(data){
			  $("#comment_show_div_"+id).remove();
			 }
		   });
	}
		
</script>
<?php $address=base_url().'uploadimages/submitted_gallery/'; ?>

<div class="content">
  <div class="comment_box_left">
    <div class="comment_box_image"><img src="<?=$address.$photo[0]->image_url?>"/> </div>
  </div>
  <div class="comment_box_right"> 
    <div id="comment_show_main_div" class="comment_show_main_div">
      <?php foreach($photo as $comment){?>
      <div id="comment_show_div_<?=$comment->comment_id?>" class="comment_show_div">
        <?php if($comment->comment_id!='') 
	 {?>
        <span><a  onclick="delete_comment(<?=$comment->comment_id?>)" href="javascript:void(0)">Delete</a></span>
        <? }?>
        <img src="<?php echo base_url().'uploadimages/user/'.$comment->userfile; ?>" height="20px" width="20px"/>
        <?=$comment->comment;?>
      </div>
      <?php }?>
    </div>
  </div>
</div>
