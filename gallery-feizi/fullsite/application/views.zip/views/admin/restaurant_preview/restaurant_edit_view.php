<?php $site=site_url().'admin/'; ?>
<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>
<script type="text/javascript">

function state(){
	
 var form_data = {
    state: $('#state_id').val()
   
 };

$("#loder").show();
$.ajax({
       url:'<?php echo $site.'preview/get_city';?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		   
		  
		   var newdata= jQuery.parseJSON(data);
		   $("#loder").hide();
		   $("#city").empty();
		   $.each(newdata,function(i,index){
                //alert(index['city']+'state code'+index['state_code']);
				htmlString="<option value='"+index['city_id']+"'>"+index['city']+"</option>"
				$("#city").append(htmlString);
           });
		   
       }
});
}


function add_photo()
{ 
	var id=$('#counter').val();
	photo='<input type="file" name="userfile'+id+'" value=""  /><br>';	
	  $('#counter').val(Number(id)+1)
	  $('#more_photo').append(photo);
	
}

function delete_image(id)
{
	var r=confirm('Are you Sure Delete This Image');
if (r==true)
	{
	var form_data = {
    photo_id: id
       };
		$.ajax({
			   url:'<?php echo $site.'preview/delete_restaurant_gallery';?>',
			   data:form_data,    
			   datatype:'json',
			   success:function(data){
				   $('#'+id).empty();
				   
			   }
		});
	}
}

function add(address){
		var geocoder;
		var map;
		function initialize() {
		  geocoder = new google.maps.Geocoder();
		  var latlng = new google.maps.LatLng(-34.397, 150.644);
		  var mapOptions = {
			zoom: 8,
			center: latlng,
			mapTypeId: google.maps.MapTypeId.ROADMAP
		  }
		  map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);
		}
		
		var geocoder = new google.maps.Geocoder();
		
		geocoder.geocode( { 'address': address}, function(results, status) {
		  var location = results[0].geometry.location;
		 $('#latitude').val(location.lat());
		  $('#longitude').val(location.lng());
		});

 }
</script>

<div class="container">
  <div class="hero-unit">
    <?php $this->load->view('admin/restaurant_preview/edit_resturant_header.php'); ?>
    <br />
    <h3>Edit Restaurant </h3>
    <?php 
 $attributes = array('class' => 'edit_form');
 echo form_open_multipart('admin/preview/edit_retaurant/'.$this->session->userdata('restaurant_id'),$attributes); ?>
    <div class="wit">
      <h5>Restaurant Name</h5>
      <input type="text" name="restaurant_name" value="<?php echo $restaurant[0]->restaurant_name?>"  />
      <?php echo form_error('restaurant_name'); ?></div>
    <div class="wit">
      <h5>Restaurant Logo</h5>
      <img src="<?php echo base_url().'uploadimages/files/'.$restaurant[0]->restaurant_logo; ?>" width="100" height="100" />
      <input type="file" name="userfile1" value=""  />
      <?php if(!empty($error)) echo $error; ?>
    </div>
    <div class="wit">
      <h5>Cuisines Type</h5>
      <input type="text" name="restaurant_cuisines" value="<?php echo $restaurant[0]->restaurant_cuisines; ?>"  />
      <?php echo form_error('restaurant_cuisines'); ?> </div>
    <div class="wit">
      <h5>Website</h5>
      <input type="text" name="restaurant_website" value="<?php echo $restaurant[0]->restaurant_website; ?>"  />
      <span>Don't use http:// in url</span> <?php echo form_error('restaurant_website'); ?></div>
    <div class="wit">
      <h5>State</h5>
      <select name="state_id" onchange="state()" id="state_id">
        <option value="<?php echo $restaurant[0]->state_id; ?>"><?php echo $restaurant[0]->state; ?></option>
        <?php
foreach($state as $state)
echo '<option value="'.$state->state_code.'" >'.$state->state.'</option>';?>
      </select>
      <div id='loder' style="display:none;"><img  src="<?php echo base_url().'ajax-loader.gif'; ?>"/></div>
      <?php echo form_error('state_id'); ?></div>
    <div class="wit">
      <h5>City</h5>
      <select name="city_id" id="city">
        <option value="<?php echo $restaurant[0]->city_id; ?>"><?php echo $restaurant[0]->city; ?></option>
      </select>
      <?php echo form_error('city_id'); ?></div>
    <div class="wit">
      <h5>Zip Code</h5>
      <input type="text" name="zip_code" value="<?php echo $restaurant[0]->zip_code; ?>"  />
      <?php echo form_error('zip_code'); ?>
      <input type="hidden" id="longitude" name="longitude" value="<?php echo $restaurant[0]->longitude; ?>"  />
      <input type="hidden" id="latitude" name="latitude" value="<?php echo $restaurant[0]->latitude; ?>"  />
      <input type="hidden"  name="country_id" value="USA"  />
    </div>
    <div class="wit">
      <h5>Address</h5>
      <textarea id="address" onChange="add(this.value)" name="restaurant_address" ><?php echo $restaurant[0]->restaurant_address; ?></textarea>
      <?php echo form_error('restaurant_address'); ?></div>
    <div class="wit">
      <h5>FaceBook Url</h5>
      <input type="text" name="restaurant_facebook_url" value="<?php echo $restaurant[0]->restaurant_facebook_url; ?>"  />
      <span>Don't use http:// in url</span> <?php echo form_error('restaurant_facebook_url'); ?></div>
    <div class="wit">
      <h5>Twitter Url </h5>
      <input type="text" name="restaurant_twitter_url" value="<?php echo $restaurant[0]->restaurant_twitter_url; ?>"  />
      <span>Don't use http:// in url</span></div>
    <div class="wit">
      <h5>Mobile App Url</h5>
      <input type="text" name="mobile_app_url" value="<?php echo $restaurant[0]->mobile_app_url; ?>"  />
      <span>Don't use http:// in url</span> <?php echo form_error('mobile_app_url'); ?> <?php echo form_error('restaurant_twitter_url'); ?></div>
    <div class="wit">
      <h5>Contact No</h5>
      <input type="text" name="restaurant_phone" value="<?php echo $restaurant[0]->restaurant_phone; ?>"  />
      <?php echo form_error('restaurant_phone'); ?></div>
    <div class="wit">
      <h5>Active</h5>
      <span>Yes</span>
      <input type="radio" name="restaurant_is_active" value="1" <?php if($restaurant[0]->restaurant_is_active==1){?>checked="checked"; <? }?> />
      <span>No</span>
      <input type="radio" name="restaurant_is_active" value="0" <?php if($restaurant[0]->restaurant_is_active==0){?>checked="checked"; <? }?> />
      <?php echo form_error('restaurant_is_active'); ?> </div>
    <div class="wit">
      <h5>Gallery Image</h5>
      <div id="example1" class="showbiz-container"> 
        
        <!-- THE NAVIGATION -->
        <?php
if($restaurant_photo)
{?>
        <div class="showbiz-navigation center sb-nav-grey owner"> <a id="showbiz_left_1" class="sb-navigation-left owner_prev"><i class="sb-icon-left-open"></i></a> <a id="showbiz_right_1" class="sb-navigation-right owner_next"><i class="sb-icon-right-open"></i></a>
          <div class="sbclear"></div>
        </div>
        <?php }?>
        <!-- END OF THE NAVIGATION -->
        
        <div class="divide20"></div>
        <div id="sbiz9283" class="showbiz" data-left="#showbiz_left_1" data-right="#showbiz_right_1" data-play="#showbiz_play_1">
          <div style="height: 250;" class="overflowholder">
            <ul style="width: 1200; left: 0px; height: 250;">
              <?php
foreach($restaurant_photo as $photo)
{?>
              <li style="width: 180px;" class="sb-grey-skin" id="<?php echo $photo->photo_id; ?>">
                <div class="mediaholder">
                  <div class="mediaholder_innerwrap"> <img style="height:150px; width:100%;" alt="" src="<?php echo base_url().'thumimage/'.$photo->thumbimage; ?>" >
                    <div style="opacity: 0;" class="hovercover"> <a class="fancybox" rel="group" href="<?php echo base_url().'/uploadimages/files/'.$photo->image; ?>">
                      <div class="lupeicon notalone"><i class="sb-icon-search"></i></div>
                      </a> </div>
                  </div>
                </div>
                <div class="detailholder">
                  <h4 class="showbiz-title txt-center"><a href="javascript:void(0)"  onclick="delete_image(<?php echo $photo->photo_id; ?>)">Delete</a></h4>
                </div>
              </li>
              <?php } ?>
            </ul>
            <div class="sbclear"></div>
          </div>
          <!-- END OF OVERFLOWHOLDER -->
          <div class="sbclear"></div>
        </div>
      </div>
      <input type="file" multiple name="userfile[]"  />
      <?php echo form_error('userfile1'); ?> </div>
    <div id="sub_btn">
      <input class="btn btn-primary btn-large" type="submit" name='' value="Save" />
    </div>
  </div>
</div>
<?php $slider=base_url().'assets/slider/'?>
<script type="text/javascript" src="<?=$slider?>index_data/jquery_004.js"></script>
<link rel="stylesheet" type="text/css" href="<?=$slider?>index_data/preview.css" media="screen">
<link rel="stylesheet" type="text/css" href="<?=$slider?>index_data/settings.css" media="screen">
<script type="text/javascript" src="<?=$slider?>index_data/jquery_003.js"></script> 
<script type="text/javascript" src="<?=$slider?>index_data/jquery.js"></script>
<link rel="stylesheet" href="<?=$slider?>index_data/jquery.css" type="text/css" media="screen">
<script type="text/javascript" src="<?=$slider?>index_data/jquery_002.js"></script>
<link href="<?=$slider?>index_data/css.css" rel="stylesheet" type="text/css">
<link href="<?=$slider?>index_data/css_002.css" rel="stylesheet" type="text/css">
<script type="text/javascript">

	jQuery(document).ready(function() {

		jQuery('#example1').showbizpro({
			dragAndScroll:"on",
			visibleElementsArray:[4,3,2,1],
			carousel:"off",
			entrySizeOffset:0,
			allEntryAtOnce:"off",
			speed:500,
			autoPlay:"on",
			rewindFromEnd:"on",
			delay:3000
		});

  jQuery(".fancybox").fancybox();



				});

			</script> 