<?php $site=site_url().'owner/menu/'; ?>
<script type="text/javascript">
  $().ready(function() {
	  
	
	
	  
   $('#add').click(function() {
    return !$('#select1 option:selected').remove().appendTo('#select2');
   });
   
   
   
   
   $('#remove').click(function() {
    return !$('#select2 option:selected').remove().appendTo('#select1');
   });
   
   
   
   $('#add_new_menu').click(function() {
	   var menu_val=$('#menu_add').val()
	   if(menu_val!='')
	   {
	    var form_data = {
          menu_name: menu_val
	     };
	    $.ajax({
          url:'<?php echo $site.'add_menu';?>',
            data:form_data,    
              datatype:'json',
                success:function(data){
				$('#menu_add').val("");
		         $('#select1').append('<option value='+data+'>'+menu_val+'</option>');
				 $('#menu_msg').html('Success Fully Add  Menu')
			   }//End Success
	      }); //End Ajax
	  } //End If
	  else{
		  $('#menu_msg').html('Plz Enter Menu Name')
		  }
	  
   });
   
   
   
   
  });
 </script>

<div class="container">
  <div class="hero-unit"> <?php echo form_open() ?>
    <div style="float:left">
      <select multiple id="select1">
        <?php  foreach($menus as $menus){?>
        <option value="<?=$menus->menu_id;?>">
        <?=$menus->menu_name;?>
        </option>
        <?php }?>
      </select>
      <br />
      <a href="javascript:void(0)" id="add">add &gt;&gt;</a> </div>
    <div style="float:left">
      <select multiple id="select2" name="select_menu[]">
        <?php  foreach($restaurant as $restaurant){?>
        <option value="<?=$restaurant->menu_id;?>">
        <?=$restaurant->menu_name;?>
        </option>
        <?php }?>
      </select>
      <br />
      <a href="javascript:void(0)" id="remove">&lt;&lt; remove</a> </div>
    <input class="btn btn-primary btn-large" type="submit" value="Submit" />
    </form>
    <div style="clear:both"> <?php echo form_open() ?>
      <h3>Add New Menu</h3>
      <span id=menu_msg></span><br />
      <input type="text" name="menu_name" value="" id="menu_add" />
      <input class="btn btn-primary btn-large" id="add_new_menu" type='button' value="Submit" />
      </form>
    </div>
  </div>
</div>
