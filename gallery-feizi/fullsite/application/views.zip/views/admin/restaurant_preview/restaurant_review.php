<div class="container-fluid content-wrapper mob-right-part span10">
  <div class="hero-unit">
  <h4 class="title"><?php echo $this->session->userdata('restaurant_name'); ?></h4>
  <div class="back_color">
  <div><a class="login-btn active" href="<?php echo site_url().'admin/home/city/'.$city.'/'.$cluster[0]->cluster_id; ?>">Back</a>
<a class="login-btn active" href="<?php echo site_url().'admin/home/edit_retaurant/'.$this->session->userdata('restaurant_id'); ?>">Edit</a></div>
  
  <br />
<iframe width="100%" height="1300px" frameborder="0" src="<?php echo site_url().$rest_id ;?>"></iframe></div>
</div></div>