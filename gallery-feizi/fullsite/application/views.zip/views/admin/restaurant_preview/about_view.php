<?php $site=site_url().'admin/about_restaurant/'; ?>
<div class="container-fluid content-wrapper mob-right-part span10">
  <div class="hero-unit"> 
   <?php include('edit_resturant_header.php') ?>

    <h3 id="menu_update">  </h3>
   <h3 class="title">About Us</h3>
      <div class="white_bg">
<?php echo form_open($site.'values') ?>
<textarea name="content" id="content" ><? if(!empty($s)) foreach($s as $s){ echo $s->about;}?>
</textarea>
<?php echo display_ckeditor($ckeditor); ?> <br />

<input class="login-btn" type="submit" name="submit" value="Submit" />
</form></div>
</div></div>