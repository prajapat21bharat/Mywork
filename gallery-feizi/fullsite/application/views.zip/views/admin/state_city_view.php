<?php $site=site_url().'admin/home/'; ?>
<script type="text/javascript">

function restaurant_delete(id)
{
var r=confirm('Are Sure Delete This Restaurant');
if (r==true)
	{
	var form_data = {
		 restaurant:id
		  };
    $.ajax({
       url:'<?php echo $site.'delete_retaurant';?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		  $('#'+id).hide();
		  $('#msg').html('Success Fully Deleted');
       }
     });
}

}


function active(value,rest_id)
{

var form_data = {
		 active:value,
		 rest_id:rest_id
		  };
    $.ajax({
       url:'<?php echo $site.'active_inactive';?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		   
		   if(data!='1')
		   {
			   
            $('#actve_deactive_'+rest_id).html("<a title='Enable' onclick='active(1,"+rest_id+")' href='javascript:void(0)'><img src='<?php echo base_url().'assets/img/btn-red1.png'?>'/></a>");
			   
		   }else{
			       $('#actve_deactive_'+rest_id).html("<a title='Enable' onclick='active(0,"+rest_id+")' href='javascript:void(0)'><img src='<?php echo base_url().'assets/img/btn-green.png'?>'/></a>");
		   }
		  
		
       }
     });


}

function sort_r()
{
	var data_array = new Array();
	var data_array2 = new Array();
	var oder_no=0;
	$( "#sortable2 li" ).each( function( index, element ){
	  var id=this.id;
	    data_array[index] = {restaurant_id: id,
						order_no:$('#'+id).index()+1
						
		                 };
						
						 
      });
	
	var sec_n=7;
	$( "#sortable1 li" ).each( function( index, element ){
	  var id=this.id;
	    data_array2[index] = {restaurant_id: id,
						order_no:$('#'+id).index()+sec_n
		                 };
						
      });
	   var form_data = {data_value: data_array,data_value2: data_array2};
	  $.ajax({
			   url:'<?=site_url()."admin/sort/update_order"?>',
			   data:form_data,    
			   datatype:'json',
			   success:function(data){
				   alert("Updated Successfully !");
			   }
			  });
	  
}





</script>
<script>
$(document).ready(function(){
$('#pagination .active').html('<a href="<?php echo $site.'city/'.$city_id; ?>">1</a>');
$("#pagination a:last").remove();	
	});

$(function() {
$( "#sortable2" ).sortable({
connectWith: ".connectedSortable",
 receive: function(event, ui) {
            if ($(this).children().length > 6) {
                $(ui.sender).sortable('cancel');
				alert('select only 6 Premium Restaurant');
            }
        }


}).disableSelection();


$( "#sortable1" ).sortable({
connectWith: ".connectedSortable"
}).disableSelection();




});


function filters(){
	
	
	
	var restaurant=$("#restaurant_type").val();
	var city=$("#city_code").val();
	var res=$("#res_name").val();
	
	var form_data = {restaurant_type: restaurant,city_code: city,res_name: res};
	  $.ajax({
			   url:'<?=site_url()."admin/sorting/index/"?>',
			   data:form_data,    
			   datatype:'json',
			   success:function(data){
				 $("#sortable1").html('');
			    if(data!=0){
					$("#sortable1").html(data);
				}else{ 
			    $("#sortable1").html('<div class="error">No Data Found</div>');
			    }
			   }
			  });
	
	
	}


</script>

<div class="container-fluid content-wrapper">
  <div class="hero-unit" id="dragable"> <a href="<?php echo $site ?>">Add Restaurant</a>
    <div id="filter" class="filter"></div>
    <div class="rest_search"> 
  
   
	<input type="hidden" id="city_code" name="city_code" value="<?php echo $this->uri->segment(4); ?>"/>
	   <div class="rest_fliter_city">
    <h5>City</h5>
     <select id="city_type" name="city_type">
      <?php foreach ($records as $restaurant){?>
      
       <option value="<?php echo $restaurant->city_id;?>"><?php echo $restaurant->city;?></option>
     <?php } ?>
      
    </select>
    </div>
    <div class="rest_fliter_type">
    <h5>Restaurant Type</h5>
     <select id="restaurant_type" name="restaurant_type">
      <option value="Basic">Basic</option>
      <option value="Standard">Standard</option>
      <option value="Premium">Premium</option>
    </select>
    </div>
    <div class="rest_fliter_name">
    <h5>Restaurant Name</h5>
    <input type="text"  name="res_name" id="res_name"/>
    </div>
    <input class="rest_fliter_submit" type="button" onclick="filters()"  value="Search"/>
    
    </div>
    <div id="msg"></div>
    <table width="100%" class="table  table-striped table-bordered">
      <thead>
        <tr>
          <th width="">Name</th>
          <th width="">Owner</th>
          <th width="">Restaurant Type</th>
          <th width="">Action</th>
        </tr>
      </thead>
    </table>
    <div class="fetured_restaurant">Featured Restaurant</div>
    <div id="restaurant_result">
      <ul id="sortable1" class="connectedSortable" >
    <?php
       
       
        foreach ($records as $restaurant){
		  
		  ?>
        <li class="ui-state-default"  id="<?php echo $restaurant->ID; ?>"> <span class="restaurant_name span3"> <a href="<?php echo $site.'edit_retaurant/'.$restaurant->ID; ?>"><?php echo $restaurant->restaurant_name; ?></a></span> <span class="user_name span3"><?php echo $restaurant->user_name;?></span> <span class="user_name"><?php echo $restaurant->restaurant_type; ?></span> <span class="active_details span3">
          <?php if($restaurant->restaurant_is_active==1){
			  echo "<span id='actve_deactive_$restaurant->ID'><a title='Disable' onclick='active(0,$restaurant->ID)' href='javascript:void(0)'><img src='".base_url()."assets/img/btn-green.png'  /></a></span>";
			 
		}else{
			echo  "<span id='actve_deactive_$restaurant->ID'><a title='Enable'  onclick='active(1,$restaurant->ID)' href='javascript:void(0)'><img src='".base_url()."assets/img/btn-red1.png' /></a></span>"; 
             } ?>
          <a href="<?php echo $site.'edit_retaurant/'.$restaurant->ID; ?>"> <img src="<?php echo base_url().'uploadimages/site_image/edit.png';?>"/></a> | <a href="javascript:void(0)" onclick="restaurant_delete(<?php echo $restaurant->ID; ?>)"> <img src="<?php echo base_url().'uploadimages/site_image/delete.png';?>"/></a> </span> </li>
        <?php  } ?>
      </ul>
      
      <div id="sortable2"  class="connectedSortable" >
        <?php foreach ($records as $restaurant){
		  
		  if($restaurant->order_no < 7){
		  ?>
        <li class="ui-state-default"  id="<?php echo $restaurant->ID; ?>"> <span class="restaurant_name span3"> <a href="<?php echo $site.'edit_retaurant/'.$restaurant->ID; ?>"><?php echo $restaurant->restaurant_name; ?></a></span> <span class="user_name span3"><?php echo $restaurant->user_name;?></span> <span class="user_name"><?php echo $restaurant->restaurant_type; ?></span> <span class="active_details span3">
          <?php if($restaurant->restaurant_is_active==1){
			  echo "<span id='actve_deactive_$restaurant->ID'><a title='Disable' onclick='active(0,$restaurant->ID)' href='javascript:void(0)'><img src='".base_url()."assets/img/btn-green.png'  /></a></span>";
			 
		}else{
			echo  "<span id='actve_deactive_$restaurant->ID'><a title='Enable'  onclick='active(1,$restaurant->ID)' href='javascript:void(0)'><img src='".base_url()."assets/img/btn-red1.png' /></a></span>"; 
             } ?>
          <a href="<?php echo $site.'edit_retaurant/'.$restaurant->ID; ?>"> <img src="<?php echo base_url().'uploadimages/site_image/edit.png';?>"/></a> | <a href="javascript:void(0)" onclick="restaurant_delete(<?php echo $restaurant->ID; ?>)"> <img src="<?php echo base_url().'uploadimages/site_image/delete.png';?>"/></a> </span> </li>
        <?php } } ?>
      </div>
    </div>
    <div class="update_btn"><input type="button" value="Update" onClick="sort_r()"/></div>
  </div>
  <?php echo $links;?> </div>
</div>
