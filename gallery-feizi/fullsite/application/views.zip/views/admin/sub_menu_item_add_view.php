<?php $site=site_url().'admin/sub_menu_item/'; ?>
<script type="text/javascript">
  $().ready(function() {
	  
	$("#select1").change(menu_item_val);
    
   
  });
  
  
function menu_item_val() {
				
				var form_data = {
							   menu_id:$("#select1").val()
							 };
							$.ajax({
							  url:'<?php echo $site.'get_menu_item';?>',
								data:form_data,    
								  datatype:'json',
									success:function(data){
										$("#select2").empty();
										
									var newdata=jQuery.parseJSON(data);
									 $.each(newdata,function(i,index){
									 htmlString="<option value='"+index['menu_item_id']+"'>"+index['menu_item_name']+"</option>"
								     $("#select2").append(htmlString);
									   });
								   }//End Success
							  }); //End Ajax
		}
  
 
  
  
 </script>

<div class="container">
  <div class="hero-unit">
    <h3>Add New  Menu item</h3>
    <span id=menu_msg></span><br />
    <?php echo  form_open_multipart($site.'add_menu')?>
    <h5>Select Menu Type</h5>
    <select id="select1" name="menu_id" >
      <option value="<?php echo set_value('menu_id'); ?>">Select Menu Type</option>
      <?php  foreach($menus as $menus){?>
      <option value="<?=$menus->menu_id;?>">
      <?=$menus->menu_name;?>
      </option>
      <?php }?>
    </select>
    <?php echo form_error('menu_id'); ?>
    <h5>Select Menu</h5>
    <select  id="select2" name="menu_item_id">
      <option value="<?php echo set_value('menu_item_id'); ?>">Select Menu</option>
    </select>
    <?php echo form_error('menu_item_id'); ?>
    <h5>Title</h5>
    <input type="text" name="title" value="<?php echo set_value('title'); ?>" />
    <?php echo form_error('title'); ?>
    <h5>Description</h5>
    <textarea name="menu_item_discription"><?php echo set_value('menu_item_discription'); ?></textarea>
    <?php echo form_error('menu_item_discription'); ?>
    <h5>Price</h5>
    <input type="text" name="menu_item_price" value="<?php echo set_value('menu_item_price'); ?>" />
    <?php echo form_error('menu_item_price'); ?>
    <h5>Image</h5>
    <input type="file" name="userfile" value="" />
    <?php if(!empty($error))echo $error; ?>
    <h5>Active</h5>
    Yes
    <input type="radio" name="active" checked="checked" value="1" />
    No
    <input type="radio" name="active"  value="0" />
    <br />
    <br />
    <input class="btn btn-primary btn-large" type="submit"  value="Submit" />
    </form>
  </div>
</div>
