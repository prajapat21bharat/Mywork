<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$site=site_url()."admin/sort/";
 ?>
<script>

function state(){
	
 var form_data = {
    state: $('#input_ststes').val()
   
 };

$("#loder").html('<img  src="<?php echo base_url().'/ajax-loader.gif'; ?>"/>');
$.ajax({
       url:'<?=$site.'get_city'?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		    var newdata= jQuery.parseJSON(data);
		   $("#loder").empty();
		   $("#input_city").empty();
		   $.each(newdata,function(i,index){
                htmlString="<option value='"+index['city_id']+"'>"+index['city']+"</option>"
				$("#input_city").append(htmlString);
           });
       }
});
}

function resturent_result()
{
	var form_data = {
    city_id: $('#input_city').val()
   
 };
 
$("#sortable").html('<div><img src="<?php echo base_url().'/loader.gif'; ?>"/></div>');

$.ajax({
       url:'<?=$site.'getRestaurant'?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		var newdata= jQuery.parseJSON(data);
		 if(newdata!='')
		  {
			 $("#sortable").empty();
			 var j=0;
			 var html='';
           $.each(newdata,function(i,index){
			   var active='';
			   if(index['restaurant_is_active']==1)
			   {active='yes';
			   }else{ active='No'}
			   
			  html='<li class="ui-state-default" onclick="sort_r()" id="'+index['ID']+'"><span class="restaurant_name span3">'+index['restaurant_name']+'</span><span class="user_name span3">'+index['user_name']+'</span><span class="active_details span3">'+active+'</span></li>';
				$("#sortable").append(html);
			});
				
		   }else
		   {$("#sortable").html('<div class="error"><h4>No Data Found</h4></div>'); }
		
		 }
});
	
	
}

</script>
<link rel="stylesheet" href="<?=base_url().'assets/css/'?>smoothness_jquery-ui.css" />
<script src="<?=base_url().'assets/css/'?>1.10.3_jquery-ui.js"></script>
<script>
$(function() {
$( "#sortable" ).sortable();
$( "#sortable" ).disableSelection();
});

function sort_r()
{
	var data_array = new Array();
	$( "#sortable li" ).each( function( index, element ){
	  var id=this.id;
	    data_array[index] = {restaurant_id: id,
						order_no:$('#'+id).index()+1
		                 };
      });
	   var form_data = {data_value: data_array};
	  $.ajax({
			   url:'<?=$site.'update_order'?>',
			   data:form_data,    
			   datatype:'json',
			   success:function(data){
			  
			    }
			  });
	  
}
</script>
<style>
#restaurant_result {
	background: none repeat scroll 0 0 #EEEEEE;
	overflow: hidden;
	width: 100%;
}
#sortable li {
	float: left;
	margin: 0 3px 15px;
	padding: 0.4em 0.4em 0.4em 1.5em;
	width: auto;
}
#sortable {
	list-style-type: none;
	margin: 0;
	padding: 0;
	width:100%;
}
</style>
<div class="container">
  <div class="hero-unit">
    <div id="msg" class="span12"> <?php echo form_open(); ?>
      <div class="span3">
        <label>State</label>
        <select id="input_ststes" class="select-State" onChange="state()">
          <?php	
			   echo '<option value=""> Select State </option>';
				foreach($states as $data){
				echo '<option value="'.$data->state_code.'">'.$data->state.'</option>';
			   }?>
        </select>
      </div>
      <div class="span3">
        <label>City</label>
        <select id="input_city" class="select-city">
        </select>
      </div>
      <div class="span2">
        <input type="button" onClick="resturent_result()" value="Submit" class="btn btn-warning"/>
      </div>
      </form>
    </div>
    <div id="loder"></div>
    <div id="restaurant_result">
      <ul id="sortable">
      </ul>
    </div>
  </div>
</div>
