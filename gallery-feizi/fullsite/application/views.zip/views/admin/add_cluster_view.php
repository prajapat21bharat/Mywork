<?php $site=site_url().'admin/cluster/'; ?>
<script type="text/javascript">
<!--- THis Function use to Get All city Accroding to state--->
function state(){
	
 var form_data = {
    state: $('#input_ststes').val()
   
 };

$("#loder").html('<img  src="<?php echo base_url().'/ajax-loader.gif'; ?>"/>');
$.ajax({
       url:'<?=$site.'cluster_city'?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		    var newdata= jQuery.parseJSON(data);
		   $("#loder").empty();
		   $("#input_city").empty();
		   $.each(newdata,function(i,index){
                htmlString="<option value='"+index['city_id']+"'>"+index['city']+"</option>"
				$("#input_city").append(htmlString);
           });
       }
});
}
<!--- END--->

</script>

<div class="container-fluid content-wrapper mob-right-part span10">
  <div class="hero-unit" id="dragable">
  
  
  <h3 class="title">Add Cluster</h3>
  
  <div class="">
    <div id="success" class="success"></div>
   
    
    
    <form  class="edit_form white_bg" action="" method="post">
   <div class="wit">
    <label>Cluster Name</label>
    <input type="text"  name="cluster_name" value="<?php echo set_value('cluster_name'); ?>" id="cluster_name"  />
     <?php echo form_error('cluster_name'); ?>
   </div>
   
   <div class="wit">
    <label>State</label>
     <select id="input_ststes" name="input_ststes" class="select-State" onChange="state()">
          <?php	
			   echo '<option value="'.set_value('input_ststes').'"> Select State </option>';
				foreach($states as $data){
				echo '<option value="'.$data->state_code.'">'.$data->state.'</option>';
			   }?>
        </select>
        <?php echo form_error('input_ststes'); ?>
        <div id="loder" class="loder_add_cluster"></div>
        </div>
   
    
   <div class="wit">
     <label>City</label>
     <select id="input_city" name="input_city[]" multiple>
     <option value="<?php echo set_value('input_city'); ?>"> Select City </option>
      </select>
       <?php echo form_error('input_city'); ?>
      </div>
      
     <div class="wit">
      <div id="sub_btn">
      <input type="submit" value="Submit" name="" class="login-btn">
      <a href="<?php echo $site; ?>"><input type="button" value="Cancel" name="" class="login-btn"></a>
      </div>
    </div>
  </form>
    
    
    
     </div>
</div>
