
<?php $site=site_url().'admin/home/'; ?>
<script type="text/javascript">
$(function(){	
$('#pagination .active').html('<a href="<?php echo $base_url; ?>">1</a>');
$("#pagination a:last").remove();
var val_loc=window.location;

var arr = String(val_loc).split("/");
var size=arr.length-1;

if(arr[size])
{
	var par_page='<?php echo $per_page; ?>';
	var page=Math.ceil(arr[size]/par_page)+1;
	$("#pagination >li.active").removeClass("active");
	$("#pagination li:nth-child("+page+") a ").addClass("active");

}
});
</script>

<div class="container-fluid content-wrapper mob-right-part span10">
  <div class="hero-unit"> 

  
 <h4 class="title">Add Restaurant</h4>
  
  <div class="">
    <div id="msg"></div>
    <table width="100%" class="table table-striped table-bordered table-radmin">
      <thead>
        <tr> 
          <th width="">Cluster</th>
          <th width="">Number of City</th>
          <th width="">Number of Restaurant</th>
         
        </tr>
      </thead>
      <?php foreach ($records as $cluster): 
	
	  ?>
      
     
      <tr>
        <td><a href="<?php echo $site.'city/'.$cluster->city_id.'/'.$cluster->cluster_id;?>/"><?php echo $cluster->cluster_name;?></a></td> 
        <td><?php echo $cluster->city_count;?></td>
        <td><?php echo $cluster->restaurant_count;?></td>
    
      </tr>
      <?php endforeach; ?>
    </table>
    <?php echo $links;?>
    </div>
    
     </div>
</div>
