<?php $site=site_url().'admin/home/'; ?>
<script type="text/javascript">

function restaurant_delete(id)
{
var r=confirm('Are Sure Delete This Restaurant');
if (r==true)
	{
	var form_data = {
		 restaurant:id
		  };
    $.ajax({
       url:'<?php echo $site.'delete_retaurant';?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		  $('#'+id).hide();
		  $('#msg').html('Deleted Successfully');
       }
     });
}

}


function active(value,rest_id)
{

var form_data = {
		 active:value,
		 rest_id:rest_id
		  };
    $.ajax({
       url:'<?php echo $site.'active_inactive';?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		   
		   if(data!='1')
		   {
			   
            $('#actve_deactive_'+rest_id).html("<a title='Enable' onclick='active(1,"+rest_id+")' href='javascript:void(0)'><img src='<?php echo base_url().'assets/img/btn-red1.png'?>'/></a>");
			   
		   }else{
			       $('#actve_deactive_'+rest_id).html("<a title='Enable' onclick='active(0,"+rest_id+")' href='javascript:void(0)'><img src='<?php echo base_url().'assets/img/btn-green.png'?>'/></a>");
		   }
		  
		
       }
     });


}

function sort_r()
{
	var data_array = new Array();
	var data_array2 = new Array();
	var oder_no=0;
	$( "#sortable2 li" ).each( function( index, element ){
	  var id=this.id;
	    data_array[index] = {restaurant_id: id,
						order_no:$('#'+id).index()+1
						
		                 };
						
						 
      });
	
	var sec_n=7;
	$( "#sortable1 li" ).each( function( index, element ){
	  var id=this.id;
	    data_array2[index] = {restaurant_id: id,
						order_no:$('#'+id).index()+sec_n
		                 };
						
      });
	   var form_data = {data_value: data_array,data_value2: data_array2};
	  $.ajax({
			   url:'<?=site_url()."admin/sort/update_order"?>',
			   data:form_data,    
			   datatype:'json',
			   success:function(data){
				   alert("Updated Successfully !");
			   }
			  });
	  
}





</script>
<script>



$(function() {
	
$( "#sortable2" ).sortable({
connectWith: ".connectedSortable",
 receive: function(event, ui) {
            if ($(this).children().length > 6) {
                $(ui.sender).sortable('cancel');
				alert('select only 6 Premium Restaurant');
            }
        }


}).disableSelection();


$( "#sortable1" ).sortable({
connectWith: ".connectedSortable"
}).disableSelection();




});


function filters(){
	
	
	
	var restaurant=$("#restaurant_type").val();
	var city=$("#city_code").val();
	var res=$("#res_name").val();
	
	var form_data = {restaurant_type: restaurant,city_code: city,res_name: res};
	  $.ajax({
			   url:'<?=site_url()."admin/sorting/index/"?>',
			   data:form_data,    
			   datatype:'json',
			   success:function(data){
				 $("#sortable1").html('');
			    if(data!=0){
					$("#sortable1").html(data);
				}else{ 
			    $("#sortable1").html('<div class="error">Sorry!, No results found for the selected search option.</div>');
			    }
			   }
			  });
	
	
	}


</script>
<script type="text/javascript">
        $(document).ready(function() {
            $ ('ul#sortable1 li:even').addClass('even');
            $ ('ul#sortable1 li:odd').addClass('odd');
			$ ('ul#sortable2 li:even').addClass('even');
            $ ('ul#sortable2 li:odd').addClass('odd');
			
        });
    </script>
<div class="container-fluid content-wrapper mob-right-part span10">
  <div class="hero-unit" id="dragable">
    <div class="white_bg">
      <?php $sort_city_id=$this->uri->segment(4);
  		$sort_cluster=$this->uri->segment(5);
  ?>
      <a href="<?php echo $site.'/'.'index'.'/'.$sort_city_id?>" class="add_restaurant_btn">Add Restaurant</a>
      <div id="filter" class="filter"></div>
      <div class="rest_search">
        <input type="hidden" id="city_code" name="city_code" value="<?php echo $sort_city_id; ?>"/>
        <div class="rest_fliter_city">
          <h5>Group</h5>
          <select id="city_type" name="city_type" onchange="changeUrl();">
            <option value="<?php echo $sort_city_id;?>"><?php echo $sort_city_code;?></option>
            <?php foreach ($states as $states){
		  if($sort_city_id!=$states->city_id)
		  {
		  ?>
            <option value="<?php echo $states->city_id;?>"><?php echo $states->city;?></option>
            <?php } 
	  }?>
          </select>
        </div>
        <div class="rest_fliter_type">
          <h5>Restaurant Type</h5>
          <select id="restaurant_type" name="restaurant_type">
            <option value="Basic">Basic</option>
            <option value="Standard">Standard</option>
            <option value="Premium">Premium</option>
          </select>
        </div> 
        <div class="rest_fliter_name">
          <h5>Restaurant Name</h5>
          <input type="text"  name="res_name" id="res_name"/>
        </div>
        <input class="login-btn admin_search" type="button" onclick="filters()"  value="Search"/>
      </div>
      <div id="msg"></div>
      <table width="100%" class="add_cluster_table table table-striped table-bordered table-radmin">
        <thead>
          <tr>
            <th width="">Name</th>
            <th width="">Owner</th>
            <th width="">Restaurant Type</th>
            <th width="">Action</th>
          </tr>
        </thead>
      </table>
      <div class="fetured_restaurant">Featured Restaurant</div>
      <div id="restaurant_result">
        <ul id="sortable1" class="connectedSortable" >
          <?php
       
      $preview=site_url().'admin/preview/review/';
        foreach ($records_left as $restaurant){ ?>
          <li class="ui-state-default"  id="<?php echo $restaurant->ID; ?>"> <span class="restaurant_name span3"> <a href="<?php echo $preview.$restaurant->ID; ?>" class="replace-border"><?php echo $restaurant->restaurant_name; ?></a></span> <span class="user_name span3"><?php echo $restaurant->user_name;?></span> <span class="user_name"><?php echo $restaurant->restaurant_type; ?></span> <span class="active_details span3">
            <?php if($restaurant->restaurant_is_active==1){
			  echo "<span id='actve_deactive_$restaurant->ID'><a title='Disable' onclick='active(0,$restaurant->ID)' href='javascript:void(0)' class='replace-border'>
			  <img src='".base_url()."assets/img/btn-green.png'  />
			  </a></span> ";
			 
		}else{
			echo  "<span id='actve_deactive_$restaurant->ID'><a title='Enable'  onclick='active(1,$restaurant->ID)' href='javascript:void(0)'>
			<img src='".base_url()."assets/img/btn-red1.png' /></a></span> "; 
             } ?>
           <a href="<?php echo $preview.$restaurant->ID; ?>"> <img src="<?php echo base_url().'uploadimages/site_image/edit.png';?>"/></a><a href="javascript:void(0)" onclick="restaurant_delete(<?php echo $restaurant->ID; ?>)"> <img src="<?php echo base_url().'uploadimages/site_image/delete.png';?>"/></a> </span> </li>
          <?php } ?>
        </ul>
        <ul id="sortable2"  class="connectedSortable" >
          <?php foreach ($records_right as $restaurant){ ?>
          <li class="ui-state-default"  id="<?php echo $restaurant->ID; ?>"> <span class="restaurant_name span3"> <a href="<?php echo $preview.$restaurant->ID; ?>" class="replace-border"><?php echo $restaurant->restaurant_name; ?></a></span> <span class="user_name span3"><?php echo $restaurant->user_name;?></span> <span class="user_name"><?php echo $restaurant->restaurant_type; ?></span> <span class="active_details span3">
            <?php if($restaurant->restaurant_is_active==1){
			  echo "<span class='on-off-btn' id='actve_deactive_$restaurant->ID'><a title='Disable' onclick='active(0,$restaurant->ID)' href='javascript:void(0)' ><img src='".base_url()."assets/img/btn-green.png'  /></a></span> ";
			  
		}else{
			echo  "<span class='on-off-btn' id='actve_deactive_$restaurant->ID'><a title='Enable'  onclick='active(1,$restaurant->ID)' href='javascript:void(0)'><img src='".base_url()."assets/img/btn-red1.png' /></a></span> "; 
             } ?>
           <a href="<?php echo $preview.$restaurant->ID; ?>"> <img src="<?php echo base_url().'uploadimages/site_image/edit.png';?>"/></a> 
           <a href="javascript:void(0)" onclick="restaurant_delete(<?php echo $restaurant->ID; ?>)"> <img src="<?php echo base_url().'uploadimages/site_image/delete.png';?>"/></a> </span> </li>
          <?php }?>
        </ul>
        
        <div class="pull-left pagination-link">
       		<?php echo $links;?> 
        </div>
        
      </div>
      <div id="sub_btn">
        <input type="button" value="Update" onClick="sort_r()" class="login-btn"/>
      </div>
      
          
      </div>
  </div>
</div>
</div>
<script>
function changeUrl() {
	

var city_val = $('#city_type').val();
//alert(city_val);
window.location.href = "<?php echo site_url().'admin/home/city/';?>"+city_val+'/<?php echo $sort_cluster; ?>/';

}

$(function(){	
$('#pagination .active').html('<a href="<?php echo $base_url; ?>/0">1</a>');
$("#pagination a:last").remove();
var val_loc=window.location;

var arr = String(val_loc).split("/");
var size=arr.length-1;

if(arr[size])
{
	var par_page='<?php echo $per_page; ?>';
	var page=Math.ceil(arr[size]/par_page)+1;
	$("#pagination >li.active").removeClass("active");
	$("#pagination li:nth-child("+page+") a ").addClass("active");

}
});
</script> 
