<?php $site=site_url().'admin/menu_item/'; ?>
<script type="text/javascript">
function sort_r()
{
	var data_array = new Array();
	var oder_no=0;
	$( "#sortable1 li" ).each( function( index, element ){
	  var id=this.id;
	    data_array[index] = {menu_item_id: id,
						    order_no:$('#'+id).index()+1
						 };
	});
 var form_data = {data_value: data_array};
	  $.ajax({
				url:'<?php echo $site.'menu_item_order'?>',
				data:form_data,    
				datatype:'json',
				success:function(data){
				  $("#msg").html('Updated Successfully !');
				}
			 });
	  
}

function sub_menu(){
	
	var form_data = {menu_id: $("#menu_type").val()};
	  $.ajax({
				url:'<?php echo $site.'get_menu_item'?>',
				data:form_data,    
				datatype:'json',
				success:function(data){
				 $("#sub_menu").empty();	
				 $("#sub_menu").append('<option>Select Sub Menu</option>');				
			  	 var newdata=jQuery.parseJSON(data);
				 $.each(newdata,function(i,index){
				 htmlString="<option value='"+index['menu_cate_id']+"'>"+index['menu_categorie_name']+"</option>"
				 $("#sub_menu").append(htmlString);
				   });
				}
			 });
	
 }
function menu_item(){
	
	var form_data = {sub_menu_id: $("#sub_menu").val()};
	  $.ajax({
				url:'<?php echo $site.'sub_menu_item'?>',
				data:form_data,    
				datatype:'json',
				success:function(data){
				  $("#sortable1").empty();
				  
				 var newdata=jQuery.parseJSON(data);
				 if(newdata!=0){
				 $.each(newdata,function(i,index){
				 htmlString ="<li class='ui-state-default'  id='"+index['menu_item_id']+"'>";
				 htmlString +="<span class='restaurant_name span3'>"+index['title']+"</span> </li>";
				 
				 $("#sortable1").append(htmlString);
				   });
				 }else{ $("#sortable1").html('<div class="error"><h4>No Data Found</h4></div>');}
				   odd_even();
				}
			 });
	
 }

function odd_even(){
	
	$ ('ul#sortable1 li:even').addClass('even');
    $ ('ul#sortable1 li:odd').addClass('odd');
	
	}

</script>
<script type="text/javascript">
        $(document).ready(function() {
          odd_even();
		  			
    $( "#sortable1" ).sortable({
      connectWith: ".connectedSortable"
       }).disableSelection();
  });
    </script>

<div class="container-fluid content-wrapper">
  <div class="hero-unit" id="dragable">
  <?php $this->load->view('admin/restaurant_preview/edit_resturant_header.php') ?>
  
   <h4 class="title">Sort Menu Item</h4>
    <div class="white_bg">
      
   <div id="msg"></div>
      <div class="rest_search sorting-menu">
        <div class="rest_fliter_city">
          <h5>Menu Type</h5>
          <select id="menu_type" name="menu_type" onchange="sub_menu()">
            <?php 
			if(!empty($menu_type)){
			foreach ($menu_type as $menu_type){?>
            <option value="<?php echo $menu_type->menu_id;?>"><?php echo $menu_type->menu_name;?></option>
            <?php } }?>
	 
          </select>
        </div>
        <div class="rest_fliter_type">
          <h5>Sub Menu</h5>
          <select id="sub_menu" name="sub_menu" onchange="menu_item()" >
            <?php 
			if(!empty($sub_menu)){
			foreach ($sub_menu as $sub_menu){?>
            <option value="<?php echo $sub_menu->menu_cate_id;?>"><?php echo $sub_menu->menu_categorie_name;?></option>
            <?php } }?>
          </select>
        </div>
       
      </div>
    
      
      <div id="restaurant_result">
      
        <ul id="sortable1" class="connectedSortable" >
          <?php
		  if(!empty($menu_item)){
         foreach ($menu_item as $menu_item){ ?>
          <li class="ui-state-default"  id="<?php echo $menu_item->menu_item_id; ?>"> 
          <span class="restaurant_name span3"><?php echo $menu_item->title; ?>
          </span> </li>
          <?php }  }?>
          </ul>
        </div>
       
      </div>
       <div class="login_button space_btn">
        <input type="button" class="login-btn" value="Update" onClick="sort_r()"/>
        <a href="<?php echo $site ?>"><input class="login-btn" type="button" value="Cancel" /></a>
      </div>
     </div>
  </div>
</div>
</div>

