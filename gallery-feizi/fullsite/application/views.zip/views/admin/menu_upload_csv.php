<?php $site=site_url().'admin/menu_item/'; ?>

<div class="container-fluid content-wrapper">
<div class="hero-unit">
 <?php $this->load->view('admin/restaurant_preview/edit_resturant_header.php') ?>

 <h4 class="title">Upload Menu</h4>
   <div class="white_bg">
<div id="msg"></div>


<form class="edit_form" action="<?php echo $site.'menu_upload';?>" method="post" enctype="multipart/form-data">
<h5>Select Csv file</h5>
  <input type="file" name="userfile" class="fileUpload" >
  <input id="px-submit" type="submit" class="login-btn" value="Upload" />

</form>


<div class="instruction">
   <span class="formate_span">
   <a class="login-btn" href="<?php echo $site.'download'; ?>">File Format</a>
   </span>
</div>

<div class="csv_error">
   <?php if(!empty($error)){
	          echo $error; }
	   
	   if(!empty($csv_error)){
		  foreach($csv_error as $csv_error){
			 if(!empty($csv_error['row']))echo '<br>'.$csv_error['row'].' -  ';
			    if(!empty($csv_error['error']))echo $csv_error['error'].' <br>';	  
		 }
		 echo '<span>Please upload again  Only Error Row Not all row</span>';
		}		
		?>
</div>

</div>
</div>
</div>

