<?php $site=site_url().'admin/home/'; ?>
<script type="text/javascript">


$(function(){	
$('#pagination .active').html('<a href="<?php echo $base_url; ?>">1</a>');
$("#pagination a:last").remove();
var val_loc=window.location;

var arr = String(val_loc).split("/");
var size=arr.length-1;

if(arr[size])
{
	var par_page='<?php echo $per_page; ?>';
	var page=Math.ceil(arr[size]/par_page)+1;
	$("#pagination >li.active").removeClass("active");
	$("#pagination li:nth-child("+page+") a ").addClass("active");

}
});
</script>

<div class="container-fluid content-wrapper cluster_container mob-right-part span10">
  <div class="hero-unit"> 

  <h4 class="title">Add Restaurant</h4>
  
  
  <div class="">
    <div id="msg"></div>
    <table width="100%" class="table table-striped table-bordered table-radmin">
      <thead>
        <tr>
          <th width="">State</th>
           <th width="">Number of Cluster</th>
          <th width="">Number of City</th>
          <th width="">Number of Restaurant</th>
         
        </tr> 
      </thead>
      <?php foreach ($records as $restaurant): 
	
	  ?>
      
      <?php  //echo $restaurant->state_id;
	 // die;?>
      <tr id='<?php //echo $restaurant->ID; ?>'>
        <td><a href="<?php echo $site.'retaurant_cluster/'.$restaurant->state_id;?>/"><?php echo $restaurant->state;?></a></td>
        <td><?php echo $restaurant->cluster;?></td>
        <td><?php echo $restaurant->city_id;?></td>
        <td><?php echo $restaurant->restaurant_count;?></td>
    
      </tr>
      <?php endforeach; ?>
    </table>
    <?php echo $links;?>
    </div>
    
     </div>
</div>
