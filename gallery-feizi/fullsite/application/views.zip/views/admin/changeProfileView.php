<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" />
<script>
$(document).ready(function() {
$("#datepicker").datepicker();
$("#datepick").datepicker();
});
 </script>

<div class="hero-unit">
  <?php
$this->load->helper('form');
$this->load->library('form_validation');
$this->load->helper('url');

 echo form_open_multipart('admin/register/change_profile');
 foreach($user_info as $user)
 {
  if(!empty($success)) echo $success;
?>
  <input type="hidden" name="user_id" value="<?php echo $user->user_id; ?>" />
  <label>First Name </label>
  <input type="text" id="firstName" name="first_name" value="<?php echo $user->first_name; ?>"/>
  <p><span id="txtFirstName"> <?php echo form_error('first_name'); ?></span></p>
  <label>Last Name </label>
  <input type="text"  id="lastName" name="last_name" value="<?php echo $user->last_name; ?>"/>
  <p><span id="txtLastName"> <?php echo form_error('last_name'); ?> </span></p>
  <label>Profile Image </label>
  <a class="fancybox" href="<?php echo site_url()."uploadimages/user/".$user->userfile; ?>"><img src="<?php echo site_url()."uploadimages/user/".$user->userfile; ?>" height="100px" width="100px"/></a>
  <input type="file" name="userfile" value="" />
  <?php if(!empty($error)) echo $error; ?>
  <p><span id="userfile"> <?php echo form_error('userfile'); ?> </span></p>
  <label>Gender </label>
  <tr>
    <td><input type="radio" name="gender" value="Male"    <?php if($user->gender=='Male') echo 'checked="checked"';?> />
      <h5>Male</h5></td>
    <td><input type="radio" name="gender" value="Female" <?php if($user->gender=='Female') echo 'checked="checked"';?>  />
      <h5>Female</h5></td>
  </tr>
  <label>Date of Birth </label>
  <input type="text" id="datepicker" value="<?php echo $user->date; ?>" name="date"/>
  <p><span id="txtAge"> <?php echo form_error('date'); ?> </span></p>
  <label>Address </label>
  <textarea rows="4" cols="50" name="user_address"  id="address"><?php echo $user->user_address; ?></textarea>
  <p><span id="txtAddress"><?php echo form_error('user_address'); ?></span></p>
  <label>Contact No </label>
  <input type="text" name="user_phone" value="<?php echo $user->user_phone; ?>"  />
  <p><span id="txtTelephone"><?php echo form_error('user_phone'); ?> </span></p>
  <input type="submit" value="update" name=" " class="btn btn-primary btn-large"/>
  <?php }
echo  form_close();
?>
</div>
</body></html>