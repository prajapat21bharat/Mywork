<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<div class="container-fluid content-wrapper mob-right-part span10">
<div class="hero-unit">
  <h3 class="title">Owner Registration</h3>
  <div class="">
    <?php
 	$attr=array('class'=>'edit_form white_bg');
    echo form_open('admin/register/',$attr);
	if(!empty($error))
 echo $error;
 if(!empty($success))echo $success;
	?>
    <div class="wit">
    <label>User Name </label>
    <input type="text" id="user_name" name="user_name" value="<?php echo set_value('user_name'); ?>"/>
    <?php echo form_error('user_name'); ?>
    </div>
    
    <div class="wit">
    <label>Group</label>
    <select name="group" id="group" >
      <option value="2">Restaurant Owner</option>
    </select>
    </div>
    
    <div class="wit">
    <label>Email </label>
    <input type="email"  id="email" name="email" value="<?php echo set_value('email'); ?>"/>
	<?php echo form_error('email'); ?>
    </div>
    
    <div class="wit">
    <label>Password</label>
    <input type="password" name="password" value="<?php echo set_value('password'); ?>" />
	<?php echo form_error('password'); ?>
    </div>
    
    <div class="wit">
    <label>Confirm Password</label>
    <input type="password" name="confirm_password" value="<?php echo set_value('confirm_password'); ?>" />
    <span id="confirm_password" class="registration_form"> </span>
    </div>
    
    <div class="login_button">
    <input type="submit" name="register" value="Register" class="login-btn" />
    </div>
    <?php
    echo form_close();
 ?>
  </div>
</div>
</div>