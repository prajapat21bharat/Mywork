<?php $site=site_url().'admin/demo/csv_upload';?> 



<?php /*?><?php
$allowedExts = array("csv","gif", "jpeg", "jpg", "png");  
$temp = explode(".", $_FILES["userfile"]["name"]); 
$extension = end($temp);
if (in_array($extension, $allowedExts))
  {
  if ($_FILES["userfile"]["error"] > 0)
    {
    echo "Return Code: " . $_FILES["userfile"]["error"] . "<br>";
    }
  else
    {
    echo "Upload: " . $_FILES["userfile"]["name"] . "<br>";
    echo "Type: " . $_FILES["userfile"]["type"] . "<br>";
    echo "Size: " . ($_FILES["userfile"]["size"] / 1024) . " kB<br>";
    echo "Temp file: " . $_FILES["userfile"]["tmp_name"] . "<br>";

    if (file_exists("upload/" . $_FILES["userfile"]["name"]))
      {
      echo $_FILES["userfile"]["name"] . " already exists. ";
      }
    else
      {
      move_uploaded_file($_FILES["userfile"]["tmp_name"],
      "uploads/" . $_FILES["userfile"]["name"]);
      echo "Stored in: " . "uploads/" . $_FILES["userfile"]["name"];
      }
    }
  }
else
  {
  echo "Invalid file";
  }
?> <?php */?>






<div class="container-fluid content-wrapper mob-right-part span10">
  <div class="hero-unit">
  <h3 class="title">Upload CSV File</h3>
    
  

<form class="edit_form inner_grey_bg" action="<?=$site;?>" method="post" enctype="multipart/form-data">
<h5 class="title">Select Csv file</h5>
  <input type="file" name="userfile" class="fileUpload" >
  <input id="px-submit" type="submit" class="login-btn" value="Upload" />

</form>
<div class="instruction">
 <!-- <span class="instruction_span_1">Please select Only CSV File</span>-->
   <span class="formate_span">
   <a href="<?php echo site_url().'admin/csvupload/download'; ?>" class="login-btn">File Format</a>
   </span>
</div>
<br />
<div class="csv_error">
   
   
   <?php if(!empty($error)){
	          echo $error;
	   }
	   
	   if(!empty($csv_error)){
		   echo '<span>Please upload again  Only Error Row Not all row</span>';
		  foreach($csv_error as $csv_error)
		  {
			  echo '<p>';
			    if(!empty($csv_error['row']))echo $csv_error['row'].' -  ';
			    if(!empty($csv_error['f_name']))echo $csv_error['f_name'].' , ';
			    if(!empty($csv_error['l_name']))echo $csv_error['l_name'].' , ';
				if(!empty($csv_error['city']))echo $csv_error['city'];		  
			  echo '</p>';
		  }
		  
		   
	   }
	   
	   ?>
       
       
</div>

  </div>
</div>

