<?php $site=site_url().'admin/sub_menu_item/'; ?>
<script type="text/javascript">

function restaurant_delete(id)
{
var r=confirm('Are Sure Delete This Menu');
if (r==true)
	{
	var form_data = {
		 sub_menu_id:id
		  };
    $.ajax({
       url:'<?php echo $site.'delete_sub_menu';?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		  $('#'+id).hide();
		  $('#msg').html('Success Fully Deleted');
       }
     });
}

}
$(document).ready(function(){
$('#pagination .active').html('<a href="<?php echo $site; ?>">1</a>');
$("#pagination a:last").remove();
	});
</script>

<div class="container">
  <div class="hero-unit"> <a href="<?php echo $site.'add_menu' ?>">Add Menu Item</a>
    <div id="msg"></div>
    <table width="100%" class="table table-striped table-bordered">
      <thead>
        <tr>
          <th width="">Menu Item Name</th>
          <th width="">Menu categories</th>
          <th width="">Menu </th>
          <th class="hidden-tablet hidden-phone" width="">Active</th>
          <th width="">Action</th>
        </tr>
      </thead>
      <?php foreach ($menu as $menu): ?>
      <tr id='<?php echo $menu->restaurant_sub_menu_item_id ; ?>'>
        <td><?php echo $menu->title; ?></td>
        <td><?php echo $menu->menu_item_name;?></td>
        <td><?php echo $menu->menu_name; ?></td>
        <td class="hidden-tablet hidden-phone" ><?php echo ($menu->active==1)? 'Yes': 'No'; ?></td>
        <td><a href="<?php echo $site.'edit_menu/'.$menu->restaurant_sub_menu_item_id; ?>"> <img src="<?php echo base_url().'uploadimages/site_image/edit.png';?>"/></a> | <a href="javascript:void(0)" onclick="restaurant_delete(<?php echo $menu->restaurant_sub_menu_item_id; ?>)"> <img src="<?php echo base_url().'uploadimages/site_image/delete.png';?>"/></a></td>
      </tr>
      <?php endforeach; ?>
    </table>
    <?php echo $links;?> </div>
</div>
