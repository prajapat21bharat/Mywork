<?php $site=site_url().'admin/sub_menu_item/'; ?>
<script type="text/javascript">
  $().ready(function() {
	  
	$("#select1").change(menu_item_val);
   
  });
  
  
function menu_item_val() {
				
				var form_data = {
							   menu_id:$("#select1").val()
							 };
							$.ajax({
							  url:'<?php echo $site.'get_menu_item';?>',
								data:form_data,    
								  datatype:'json',
									success:function(data){
										$("#select2").empty();
										
									var newdata=jQuery.parseJSON(data);
									 $.each(newdata,function(i,index){
									 htmlString="<option value='"+index['menu_item_id']+"'>"+index['menu_item_name']+"</option>"
								     $("#select2").append(htmlString);
									   });
								   }//End Success
							  }); //End Ajax
		}
  
 
  
  
 </script>

<div class="container">
  <div class="hero-unit">
    <h2>
      <?php if(!empty($Success))echo $Success; ?>
    </h2>
    <h3>Add New  Menu item</h3>
    <span id=menu_msg></span><br />
    <?php
	  foreach($submenu as $submenu){
		  	
	 echo  form_open_multipart($site.'edit_menu/'.$this->uri->segment(4))?>
    <h5>Select Menu Type</h5>
    <select id="select1" name="menu_id" >
      <option value="<?php echo $submenu->menu_id; ?>">
      <?=$submenu->menu_name;?>
      </option>
      <?php  foreach($menus as $menus){?>
      <option value="<?=$menus->menu_id;?>">
      <?=$menus->menu_name;?>
      </option>
      <?php }?>
    </select>
    <?php echo form_error('menu_type'); ?>
    <h5>Select Menu</h5>
    <select  id="select2" name="menu_item_id">
      <option value="<?php echo $submenu->menu_item_id; ?>">
      <?=$submenu->menu_item_name;?>
      </option>
    </select>
    <?php echo form_error('sub_menu'); ?>
    <h5>Title</h5>
    <input type="text" name="title" value="<?=$submenu->title;?>" />
    <?php echo form_error('title'); ?>
    <h5>Description</h5>
    <textarea name="menu_item_discription"><?=$submenu->menu_item_discription;?>
    </textarea>
    <h5>Price</h5>
    <input type="text" name="menu_item_price" value="<?=$submenu->menu_item_price;?>" />
    <?php echo form_error('price'); ?>
    <h5>Image</h5>
    <img src="<?=site_url().'uploadimages/menu_image/'.$submenu->menu_item_image;?>" height="150" width="150"/><br />
    <input type="file" name="userfile" value="" />
    <?php if(!empty($error))echo $error; ?>
    <h5>Active</h5>
    Yes
    <input type="radio" name="active" <? if($submenu->active=='1')echo 'checked="checked"';?> value="1" />
    No
    <input type="radio" name="active" <? if($submenu->active=='0')echo 'checked="checked"';?> value="0" />
    <br />
    <br />
    <input class="btn btn-primary btn-large" type="submit"  value="Submit" />
    </form>
    <?php }?>
  </div>
</div>
