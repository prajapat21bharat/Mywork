<?php $site=site_url().'admin/special_offers/'; ?>
<script type="text/javascript">

$(function() {
			$('#basicExample').timepicker();
		  });
 function add_photo()
{ 
	var id=$('#counter').val();
	photo='<input type="file" name="userfile'+id+'" value=""  /><br>';	
	  $('#counter').val(Number(id)+1)
	  $('#more_photo').append(photo);
	
}

function delete_image(id)
{
	var form_data = {
    photo_id: id
       };
		$.ajax({
			   url:'<?php echo $site.'delete_offer_gallery';?>',
			   data:form_data,    
			   datatype:'json',
			   success:function(data){
				   $('#'+id).empty();
				   
			   }
		});
}
 </script>

<div class="container-fluid content-wrapper mob-right-part span10">
  <div class="hero-unit"> 
  
    <h3 class="title">Special Offer Edit</h3>
    <span id=menu_msg></span>
    <?php 
  foreach($offer as $offers){
		  $attr=array('class'=>'edit_form white_bg');
 echo form_open_multipart($site.'edit_offer/'.$this->uri->segment(4),$attr)?>
  
         <div class="wit"><label>State</label>
        <select id="state_code" name="state_code" onchange="state()">
         <?php 
		 foreach($state as $state){
		 if($state->state_code===$offer[0]->state_code) {?>
             <option value="<?php echo $state->state_code;?>" selected="selected"><?php echo $state->state;?></option>
             <?php }
			 else{?>
            
            <option value="<?php echo $state->state_code?>"><?php echo $state->state?></option>
           <?php }}?>
       </select>
      </div>


    <div class="wit"> <label>City</label>
      <select id="city_code" name="city_code" class="select-city">
         <?php if($city){
		 foreach($city as $city){
		 if($city->city_id==$offer[0]->city_id) {?>
        <option value="<?php echo $city->city_id?>"  selected="selected"><?php echo $city->city?></option>				
		<?php }else{
			?>
			<option value="<?php echo $city->city_id?>"><?php echo $city->city?></option>		
			
		<?php	}
	?>
			
			<?php }}
		?>   </select>
    </div>

     <div class="wit"> <label>Restaurant</label>
        <select id="restaurant_id" name="restaurant_id" class="select-restaurant">
          <?php 
		 foreach($res as $res){
			 if($res->ID===$offer[0]->ID){
			  ?>
             <option value="<?php echo $res->ID;?>" selected="selected"><?php echo $res->restaurant_name;?></option>
	  <?php }
	  else{?>  <option value="<?php echo $res->ID;?>"><?php echo $res->restaurant_name;?></option>
		  
		  
		<?php  }
		 }
	  
	  ?>
        </select>
    </div>
  
    <div class="wit"> <label>Date</label>
    <span data-language="javascript" class="datepair">
      <input type="text" class="date start" name="start_date" value="<?php echo $offers->start_date; ?>">
      <input type="text" class="date end" value="<?php echo $offers->end_date; ?>" name="end_date">
     </span>
      <?php echo form_error('start_date'); ?>  <?php echo form_error('end_date'); ?></div>
   <div class="wit"> <label>Title</label>
    <input type="text" name="offer_title" value="<?php echo $offers->offer_title; ?>" />
    <?php echo form_error('offer_title'); ?></div>
   
   <div class="wit"> <label>Web Site</label>
    <input type="text" name="offer_website" value="<?php echo $offers->offer_website; ?>" />
    <?php echo form_error('offer_website'); ?></div>
   <div class="wit"> <label>Description</label>    
    <textarea name="offer_description" id="content" ><?php echo $offers->offer_description; ?>
    </textarea>
<?php echo display_ckeditor($ckeditor); ?> <br />
    <?php echo form_error('offer_description'); ?></div>
   <div class="wit"> <label>Event Image</label>
      <input type="file" name="userfile1"  />
    
    <div id="example1" class="showbiz-container"> 
     <div class="divide20"></div>
      <div id="sbiz9283" class="showbiz" data-left="#showbiz_left_1" data-right="#showbiz_right_1" data-play="#showbiz_play_1">
        <div style="height: 250;" class="overflowholder">
          <ul style="width: 1200; left: 0px; height: 250;">
            <?php

foreach($offers_photo as $photo)
{?>
            <li style="width: 180px;" class="sb-grey-skin" id="<?php echo $photo->offers_photo_id; ?>">
              <div class="mediaholder">
                <div class="mediaholder_innerwrap"> <img style="height:150px; width:100%;" alt="" src="<?=base_url().'uploadimages/city_offer_image/'.$photo->image?>" >
                  <div style="opacity: 0;" class="hovercover"> <a class="fancybox" rel="group" href="<?=base_url().'uploadimages/city_offer_image/'.$photo->image?>">
                    <div class="lupeicon notalone"><i class="sb-icon-search"></i></div>
                    </a> </div>
                </div>
              </div>
              <div class="detailholder">
                <h4 class="showbiz-title txt-center"><a href="javascript:void(0)"  onclick="delete_image(<?=$photo->offers_photo_id?>)">Delete</a></h4>
              </div>
            </li>
<?php } ?>
          </ul>
          <div class="sbclear"></div>
        </div>
        <!-- END OF OVERFLOWHOLDER -->
        <div class="sbclear"></div>
      </div>
    </div>
    
    <br />
 
    <?php if(!empty($error))echo $error; ?>
   <?php /*?> <input type="hidden" id='counter' value="2"  />
    <div class="more_photo" id="more_photo"></div>
    <br>
    <div class="add_photo btn btn-primary" id="add_photo" onclick="add_photo()">Add more Photo</div><?php */?>
    </div>
   <div class="wit"> <label>Active</label>
   <span class="radio-active">Yes</span>
    <input type="radio" name="active" <? if($offers->active=='1')echo 'checked="checked"';?> value="1" />
   <span class="radio-active"> No</span>
    <input type="radio" name="active" <? if($offers->active=='0')echo 'checked="checked"';?>  value="0" />
    </div>
    <div id="sub_btn">
    <input class="login-btn" type="submit"  value="Save" />
     <a href="<?php echo $site;?>"><input class="login-btn" type="button"  value="Cancel" /></a>
     </div>
    </form>
    <?php }?>
  </div>
</div>
<!--------------Date and Time ---------------->
		<link href="<?php echo base_url('assets/') ?>css/jquery.timepicker.css" rel="stylesheet" />
		<link href="<?php echo base_url('assets/') ?>/css/base.css" rel="stylesheet"/>
		<!--------------END Date and Time ---------------->

<script type="text/javascript" src="<?php echo base_url('assets/js/toltip.js') ?>"></script>
		<!--------------Date and Time ---------------->
		<script src="<?php echo base_url('assets/js/date_time.js') ?>"></script>
		<script type="text/javascript" src="<?php echo base_url('assets/js/jquery.timepicker.js') ?>"></script>
		<script type="text/javascript" src="<?php echo base_url('assets/js/base.js') ?>"></script>
		<!--------------END Date and Time ---------------->

 <script type="text/javascript">   
    function state(){
   var form_data ={state: $('#state_code').val()};

   $("#loder").html('<img  src="<?php echo base_url().'/ajax-loader.gif'; ?>"/>');
   $.ajax({
       url:'<?php echo site_url("admin/special_Offers/get_city"); ?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		    var newdata= jQuery.parseJSON(data);
		   $("#loder").empty();
		   $(".select-city").empty();
		   var i=0;
		   $.each(newdata,function(i,index){
			   if(i==0){
				  get_rest(index['city_id']);}
			   
                htmlString="<option value='"+index['city_id']+"'>"+index['city']+"</option>"
				$(".select-city").append(htmlString);
				var i=1;
           });
        }
    });
}
</script>
 <script type="text/javascript">   
     $(document).ready(function(){
	   $("#city_code").change(function() {
		   var city_id=$('#city_code').val();
		   get_rest(city_id);
	   });
	 });
	function get_rest(city_id){
   var form_data ={city:city_id };
   $.ajax({
       url:'<?php echo site_url("admin/special_Offers/get_rest"); ?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		   $("#restaurant_id").empty();
		    var newdata= jQuery.parseJSON(data);
		   $.each(newdata,function(i,index){
               htmlString="<option value='"+index['ID']+"'>"+index['restaurant_name']+"</option>"
				$("#restaurant_id").append(htmlString);
           });
        }
    });
 }
    
</script>

