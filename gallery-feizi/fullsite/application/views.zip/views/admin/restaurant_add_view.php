<?php $site=site_url().'admin/home/'; ?>
<script type="text/javascript" src="<?php echo base_url('assets/js/jquery.fancybox.js?v=2.1.5') ?>"></script>


<script type="text/javascript">

function state(){
	
 var form_data = {state: $('#state_id').val()};

$("#loder").show();
$.ajax({
       url:'<?php echo $site.'get_city';?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		   var newdata= jQuery.parseJSON(data);
		   $("#loder").hide();
		   $("#city").empty();
		   var i=0
		   $.each(newdata,function(i,index){
			    /***--This If use to find cluster--****/
				   if(i==0){ clusters(index['city_id']);}
				   i=1; /***--END find cluster--****/
			 htmlString="<option value='"+index['city_id']+"'>"+index['city']+"</option>"
				$("#city").append(htmlString);
           });
	 }
});
}

/***--This Fuction Use Get Cluster Accroding to city ID----****/

function clusters(city_id)
{ 
	var form_data = {state: $('#state_id').val(),
						city_id: city_id};
	$.ajax({
       url:'<?php echo $site.'get_cluster';?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		   if(data==0){ 
		       $("#cluster").show();
		       $("#cluster_select").hide();
			   $("#cluster_add").show();
			   $("#cluster_select_option").html('');
			 }else if(data==1){
				 $("#cluster").hide();
				 $("#cluster_select_option").html('');
				 $("#cluster_name").val('');
				 
			}else{
			   $("#cluster_add").hide() 
			   $("#cluster").show()
			   $("#cluster_select").show(); 
			   $("#cluster_name").val('');
			   $("#cluster_select_option").html('');	
			   var newdata= jQuery.parseJSON(data);
			    $.each(newdata,function(i,index){
					 htmlString="<option value='"+index['cluster_id']+"'>"+index['cluster_name']+"</option>"
				$("#cluster_select_option").append(htmlString);
               });
			   
			   
			   }
	   }
	});
	
	
}
/***--END GET CLUSTER--*****/
function more_cluster()
{
	 $("#cluster").show();
     $("#cluster_select").hide();
	 $("#cluster_add").show();
	 $("#cluster_select_option").html('')
}

function basic(){
	  
	  var type=$("#restaurant_type").val();
	  if(type=='Basic') {
		  $(".basic_hide").hide();
	  }else{
		   $(".basic_hide").show();
		  }
  }
$(document).ready(function() {
	
	 $('.fancybox').fancybox();
	 basic();
	 
	});

function add_owner(){
	
	parent.$.fancybox.open({href : "<?php echo site_url().'admin/register/popup';?>" , type: 'ajax',height: 'auto', width: 'auto',scrolling : 'auto'});
	
	}
</script>

<div id="disp"></div>
<div class="container-fluid content-wrapper mob-right-part span10">
<div class="hero-unit">
  <h3 class="title">Add Restaurants </h3>
  
  <?php 

	$att=array('class'=>'edit_form white_bg');
	echo form_open_multipart('admin/home/index',$att); ?>
  <div class="wit">
    <label>Restaurant Type</label>
    <input type="hidden" name="str" id="str" value=""/>
    <select onchange="basic()" id="restaurant_type" name="restaurant_type">
      <?php if(set_value('restaurant_type')!=''){ ?>
      <option value="<?php echo set_value('restaurant_type'); ?>"><?php echo set_value('restaurant_type'); ?></option>
      <?php }?>
      <option value="Basic">Basic</option>
      <option value="Standard">Standard</option>
      <option value="Premium">Premium</option>
    </select>
    <?php echo form_error('restaurant_type'); ?></div>
  <div class="wit">
 <label>Cuisines Type</label>
    <input type="text" name="restaurant_cuisines" value="<?php echo set_value('restaurant_cuisines'); ?>"  />
    <?php echo form_error('restaurant_cuisines'); ?></div>
  <div class="wit">
    <label>Owner name</label>
    <select name="owner_id">
      <option value="<?php echo set_value('owner_id'); ?>"> Select Resturant Owner</option>
      <?php
foreach($owner as $user)
echo '<option value="'.$user->user_id.'" >'.$user->user_name.'</option>';?>
    </select>
    
    <span class="add_owner"><a onclick="add_owner()"  href="javascript:void(0)" >Add Owner</a></span>
    
    <?php echo form_error('owner_id'); ?></div>
  <div class="wit">
    <label>Restaurant Name</label>
    <input type="text" name="restaurant_name" id="restaurant_name" value="<?php echo set_value('restaurant_name'); ?>"  />
    <?php echo form_error('restaurant_name'); ?> </div>
  <div class="wit">
    <label>Restaurant Logo</label>
    <input type="file" name="userfile1" value=""  />
    <?php if(!empty($error)) echo $error; ?>
  </div>
  <div class="wit basic_hide">
    <label>Website</label>
    <input type="text" name="restaurant_website" value="<?php echo set_value('restaurant_website'); ?>"  />
    <span>Don't use http:// in url</span> <?php echo form_error('restaurant_website'); ?></div>
  <div class="wit">
    <label>State</label>
    <select name="state_id" onchange="state()" id="state_id">
      <?php if($result!==0)
	    {  
	         if($state_city)
		  {
		        foreach($state_city as $state1)
			  {
			      if($state1->state_code ===$result[0]->state_code)
				    {?>
      <option value="<?php echo $state1->state_code?>" selected="selected"><?php echo $state1->state;?></option>
      <?php }
	             else{?>
      <option value="<?php echo $state1->state_code?>"><?php echo $state1->state;?></option>
      <?php
		             }
	          } 
	      }
	  }
 else{?>
      <option value="<?php echo set_value('state_id'); ?>">Select State</option>
      <? }?>
      <?php
foreach($state as $state)
echo '<option value="'.$state->state_code.'" >'.$state->state.'</option>';?>
    </select>
    <div id='loder' style="display:none;"><img  src="<?php echo base_url().'ajax-loader.gif'; ?>"/></div>
    <?php echo form_error('state_id'); ?></div>
  <div class="wit">
    <label>City</label>
    <select onchange="clusters($(this).val())" name="city_id" id="city">
      <?php if($result!==0)
	    {  
	         if($city_all)
		  {
		        foreach($city_all as $city1)
			  {
			      if($city1->city_id ===$result[0]->city_id)
				    {?>
      <option value="<?php echo $city1->city_id?>" selected="selected"><?php echo $city1->city;?></option>
      <?php }
	             else{?>
      <option value="<?php echo $city1->city_id?>"><?php echo $city1->city;?></option>
      <?php
		             }
	          } 
	      }
	  }
 else{?>
      <option value="<?php echo set_value('state_id'); ?>"></option>
      <? }?>
    </select>
    <?php echo form_error('city_id'); ?></div>
  <div id="cluster" style="display:none" class="wit">
    <label>Cluster Name</label>
    <div id="cluster_select" style="display:none">
      <select name="cluster_name_slect" id="cluster_select_option">
      </select>
      <span class="add_more_cluster" onclick="more_cluster()">Add New Cluster</span> </div>
    <div id="cluster_add" style="display:none">
      <textarea id="cluster_name"  name="cluster_name"><?php echo set_value('cluster_name'); ?></textarea>
      <?php echo form_error('cluster_name'); ?> </div>
  </div>
  <div class="wit">
    <label>Zip Code</label>
    <input type="text" name="zip_code" value="<?php echo set_value('zip_code'); ?>"  />
    <?php echo form_error('zip_code'); ?> </div>
  <div class="wit">
    <label>Address</label>
    <textarea id="address"  name="restaurant_address"><?php echo set_value('restaurant_address'); ?></textarea>
    <?php echo form_error('restaurant_address'); ?></div>
  <div class="wit basic_hide">
    <label>FaceBook Url</label>
    <input type="text" name="restaurant_facebook_url" value="<?php echo set_value('restaurant_facebook_url'); ?>"  />
    <span>Don't use http:// in url</span> <?php echo form_error('restaurant_facebook_url'); ?></div>
  <div class="wit basic_hide">
    <label>Twitter Url </label>
    <input type="text" name="restaurant_twitter_url" value="<?php echo set_value('restaurant_twitter_url'); ?>"  />
    <span>Don't use http:// in url</span> <?php echo form_error('restaurant_twitter_url'); ?> </div>
  <div class="wit basic_hide">
    <label>Mobile App Url</label>
    <input type="text" name="mobile_app_url" value="<?php echo set_value('mobile_app_url'); ?>"  />
    <span>Don't use http:// in url</span> <?php echo form_error('mobile_app_url'); ?> </div>
  <div class="wit">
    <label>Contact No</label>
    <input type="text" name="restaurant_phone" value="<?php echo set_value('restaurant_phone'); ?>"  />
    <?php echo form_error('restaurant_phone'); ?></div>
  <div class="wit">
    <label>Active</label>
    <span class="radio-active">Yes</span>
    <input type="radio" name="restaurant_is_active" checked="checked" value="1" />
    <span class="radio-active">No</span>
    <input type="radio" name="restaurant_is_active"  value="0" />
    <?php echo form_error('restaurant_is_active'); ?></div>
  <div class="wit">
    <label>Header Banner Image</label>
    <input type="file" multiple name="header_banner[]"  />
    <?php echo form_error('header_banner'); ?> </div>
  <div class="wit">
    <label>Gallery Image</label>
    <input type="file" multiple name="userfile[]"  />
    <?php echo form_error('userfile1'); ?>
    <div id="sub_btn">
      <input class="login-btn" type="submit" name='' value="Save" />
    </div>
  </div>  
</div>