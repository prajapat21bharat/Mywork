<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>A jQuery Countdown Timer | Tutorialzine Demo</title>
        
        <!-- Our CSS stylesheet file -->
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300" />
        <link rel="stylesheet" href="assets/css/styles.css" />
        <link rel="stylesheet" href="assets/countdown/jquery.countdown.css" />
        
        <!--[if lt IE 9]>
          <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
    </head>
    
    <body>
	<div id="countdown">
    <div style="font-size:21px;">
             <h3>We're ready to change the world!</h3>  
<p>But for now – we're focused on delivering the best social based food and restaurant website and application you've ever seen! Follow us on Twitter and Facebook (you don't have to like us until you've seen us) or just give us your mobile phone and/or email and we'll update you as we near the launch date with exclusive specials and deals and events and more.
</p>
	</div>
    <p id="note"></p>

    </div>
    	<form action="<?php echo site_url("demo/notify_mail"); ?>" method="post">
         <input type="text" class="email"  name="notify_email" placeholder="Input your e-mail address here..." required / >
         <input type="submit" class="submit" value="Notify Me!" />
	    </form>
		
   
        
        <!-- JavaScript includes -->
		<script src="http://code.jquery.com/jquery-1.7.1.min.js"></script>
		<script src="assets/countdown/jquery.countdown.js"></script>
		<script src="assets/js/script.js"></script>

    </body>
</html>