<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

 <link rel="stylesheet" href="<?php echo base_url().'assets/css/smoothness_jquery-ui.css'; ?>" />

<?php $this->load->view('layout/header'); ?>


<link rel="stylesheet" href="<?php echo base_url('assets/css/jquery.datepick.css') ?>">

<script type="text/javascript" src="<?php echo base_url('assets/js/jquery.datepick.js') ?>"></script>



<script type="text/javascript">

$(function() {

	$('#popupDatepicker').datepick();

	

});

</script>

</head>



<body>



<div class="hero-unit" id="profile">

<?php

echo form_open_multipart(site_url().'register/change_profile');

?>

 <input type="hidden" name="user_id" value="<?php  if($this->session->userdata('id')){echo $this->session->userdata('id');} ?>" />

  <label>First Name *:</label>

     <input type="text" id="firstName" name="first_name" value="<?php echo set_value('first_name'); ?>"/>

    

     <p><span id="txtFirstName"> <?php echo form_error('first_name'); ?></span></p>

   

    <label>Last Name </label>

    <input type="text"  id="lastName" name="last_name" value="<?php echo set_value('last_name'); ?>"/>

    

    <p><span id="txtLastName"> <?php echo form_error('last_name'); ?> </span></p>

  

  

    <label>Profile Image </label>

     <input type="file" name="userfile" value="" />

    		<?php if(!empty($error)) echo $error; ?>

    

    <p><span id="userfile"> <?php echo form_error('userfile'); ?> </span></p>

  

  

    <label>Gender </label>

   

     <input type="radio" name="gender" value="male"    <?php if(set_value('gender')=='male') echo 'checked="checked"';?> /> <span>Male</span>

     <input type="radio" name="gender" value="female" <?php if(set_value('gender')=='female') echo 'checked="checked"';?>  /> <span>Female</span>

  

    

    <label>Date of Birth </label>

    <input type="text" value="" name="date" id="popupDatepicker"/>

     <p><span id="txtAge"> <?php echo form_error('date'); ?> </span></p>

  

  

     <label>City*:</label>

  <input type="text" id="city" value="<?php echo set_value('city'); ?>" name="city"/>

  <p><span id="txtAddress"><?php echo form_error('city'); ?></span></p>

  

  

   <label>State*:</label>

  <input type="text" id="state" value="<?php echo set_value('state'); ?>" name="state"/>

  <p><span id="txtAddress"><?php echo form_error('state'); ?></span></p>

  

  

   <label>Zip code*:</label>

  <input type="text" id="zip" value="<?php echo set_value('zip'); ?>" name="zip"/>

  <p><span id="txtAddress"><?php echo form_error('zip'); ?></span></p>

 

   

    <label>Mobile Phone Verification </label>

    <input type="text" name="user_phone" value="<?php echo set_value('user_phone'); ?>"  />

    

    <p><span id="txtTelephone"><?php echo form_error('user_phone'); ?> </span></p>

 

<input type="submit" value="Register" name=" " class="login-btn "/>

<?php

echo  form_close();

?>

</div>



</body>

</html>

 