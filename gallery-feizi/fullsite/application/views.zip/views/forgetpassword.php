<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

<script type="text/javascript">
function forget_pass() {
    var email = $('#email').val();
        if(email==""){
          $("#emailerror").html("Please enter Email Address");
         }else{	
	       $.ajax({
			type: "POST",
			 url: "<?php echo site_url().'login/chk_update_pass'; ?>",
				data: { email:email}
					}).done(function( msg ) {
						if(msg==0){
						 $("#emailerror").html('Invalid Email Address');
	 					}else{
							 $(".msg").html("You'll receive an email in a few minutes containing a link that will allow you to reset your password. If you don't see the email in your inbox shortly, check your spam folder!");
						<?php /*?>parent.$.fancybox.open({href : "<?php echo site_url().'login/updatepassword/';?>"+msg , type: 'ajax',height: 800, width: 500,scrolling : 'no'});<?php */?>
						 }
					});
				 }
}

</script>
<div>
	<div class="forget_password">
    <h3>Forget Password </h3>
 <?php
  if(!empty($error)){ echo $error;
  }else{
  ?>
   <label>Email-address</label>
   <input type="email" name="email" id="email" value="<?php echo set_value('email'); ?>" />
   <p><span id="password"> <?php echo form_error('email'); ?> </span></p>
   <span id="emailerror"></span>
   <span class="msg"></span>
   <div class="login_button">
   <input type="submit" name="forget" value="Submit" class="login-btn " id="forget_pass" onclick="forget_pass()" /> 
   </div>
 <?php 
  }?>
 </div>
 </div>

