<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

<script type="text/javascript">

      

function login_check() {

   var name = $('#user_name').val();

   var pass = $('#password').val();



   if($('#reminder').is(':checked')){

	    var reminder = '1';

	   }else{

		   var reminder = '0';

		   }

        if(name=="" || pass==""){

          $("#disp").html("Please enter Username and Password");

         }else{	

	       $.ajax({

			type: "POST",

			 url: "<?php echo site_url("login/check_login"); ?>",

				data: { user_name:name,password:pass,reminder:reminder}

					}).done(function( msg ) {

						if(msg==1){

						 $("#disp").html('Invalid User Name and Password ');

	 					}else{

						location.reload();

						 }

					});

				 }

}

</script>



<div class="hero-unit login_form">

<?php if($this->uri->segment('3')){

	echo "<span class=success_msg>Password Successfully Updated</span>";

	}



?>

  <div id="show_form"> <span><img src="<?php echo base_url().'assets/images/logo_small.png';?>"/></span><a id="login_view" onclick="login_view()"   href="javascript:void(0)"><span>LOGIN TO APETIZR</span></a> </div>

  <div id="login_form_show">

    <ul>

      <li class="last" id='facebook_info'><a class="facebook" href="javascript:void(0)" onClick="FBlogin();"><img src="<?php echo base_url().'images/facebook.jpg';?>"/><span>LOGIN WITH FACEBOOK</span></a></li>

    </ul>

  </div>

  <div style="display:none;" id="hide_form" >

    <div id="disp"></div>

    <?php

     echo form_open();?>

    <div id="disp" class="error"></div>

    <label>User Name </label>

    <input type="text" id="user_name" name="user_name" value="<?php if(!empty($user_name)) echo $user_name;?>"/>

    <span id="user_name"> <?php echo form_error('user_name'); ?></span>

    <label>Password</label>

    <input type="password" id="password" name="password" value="<?php if(!empty($password)) echo $password;?>" />

    <span id="password"> <?php echo form_error('password'); ?> </span>

    <div>

      <label class="remember">Remember Me</label>

      <input type="checkbox" id="reminder" name="reminder" value="checked" />

      <span id="reminder"> <?php echo form_error('reminder'); ?> </span></div>

       <label><a href="<?php echo site_url();?>login/forgetpassword" class="fancybox fancybox.ajax" id="cant">Can`t Access My Account</a></label>

       <div class="login_button">

    <input type="button" onclick="login_check()" name="login" value="Login" class="login-btn " id="login"/>

    <input type="button" name="Login_back" id="login_back" onclick="login_backs()" class="login-btn " value="Back"></div>

      <?php echo form_close();

 	   ?>

        

       </div>

</div>

<script type="text/javascript">

function login_view(){

	

	$("#login_form_show").hide();

	$("#hide_form").show();

	}



function login_backs(){

	$("#hide_form").hide();

	$("#login_form_show").show();

}



$(document).keypress(function(event) {



    var keycode = (event.keyCode ? event.keyCode : event.which);

    if (keycode == '13') {

        $('#login').click();

    }

});



</script> 

<script src="http://connect.facebook.net/en_US/all.js"></script> 

<script>

//var FB_APPID = '{/literal}{$FB_APPID}{literal}';

$(document).ready(function() {

FB.init({

	    appId  : '535414506539291',

	    status : true, 

	    cookie : true, 

	    xfbml  : true

	  });



});



var accesstoken='';

var username='';

var name = '';

var id ='';

function FBlogin()  

{

	

	FB.login(function(response) {

	if (response.authResponse.accessToken) {

		$('#fbKey').val(response.authResponse.accessToken);

		accesstoken = response.authResponse.accessToken;

	}

	

	if (response.authResponse) {

		FB.api('/me?fields=cover,name,username,picture,first_name,last_name,gender,birthday,email',function(response) {

			id = response.message;

			username = response.username;

			name = response.name ;

			first_name=response.first_name;

			last_name=response.last_name;

			gender=response.gender;

			birthday=response.birthday;

			email=response.email;

	 

	    image=response.picture.data.url;

			

			$.ajax({

				type: "POST",

				 url: "<?php echo site_url("login/facebook_login"); ?>",

				data: { id:username,uimage:image,fname:name,firstname:first_name,lastname:last_name,gender:gender,birthday:birthday,email:email}

				}).done(function( msg ) {

					location.reload();

					

				});

			

			

			

			

			//parent.location='<?php echo site_url().'login/facebook_login?id='; ?>'+username+'&fname='+name+'&uimage='+image; 

		});

	}

	

 $("#facebook_info").addClass("facebook_login");



		FB.api('/me?fields=cover,name,picture', function(response) {

			var profHTML='';



      profHTML += "<img class=img_border align=\"left\" src=\"" + response.picture.data.url + "\"></a>";      

     

      profHTML += "<h2 class=myname_profile>" + response.name + "</a> </h2>";

	 // profHTML += "<div class='disconnect'><input type='button' onclick='disconnect_Facebook()' value='Disconnect' /></div>";

      $("#facebook_info").html(profHTML);

	

		});	

		

	}, {scope: 'email,user_birthday,offline_access,read_stream,publish_stream,publish_actions'});

}



   function postOnFB(body)

{



	FB.api('/me/feed', 'post', { message: body }, function(response) {

		

	  if (!response || response.error) {

	    

	  } else {

	   

	  }

	});

}



    function disconnect_Facebook()



    {     

parent.location='<?php echo base_url().'login/logout'; ?>'



$("#facebook_info").removeClass("facebook_login");

	$("#facebook_info").html('<a class="facebook" href="javascript:void(0)" onClick="FBlogin();" style="display:none;>Facebook</a>'); 

	FB.logout(function(response) { parent.location='<?php echo base_url().'login/logout'; ?>'});

	setTimeout(loadwindow,3000);

	

}



$(function(){

	

	FB.getLoginStatus(function(response) {

		

		if (response.status === 'connected') {

			

		

			

			FB.api('/me?fields=cover,name,picture', function(response) {

			var profHTML='';

			

   

      profHTML += "<img class=img_border align=\"left\" src=\"" + response.picture.data.url + "\"></a>";      

    

      profHTML += "<h2 class=myname_profile>" + response.name + "</a> </h2>";



      $("#facebook_info").html(profHTML);

	  $("#facebook_info").addClass("facebook_login");

	

		});	



	}

	}, true);

	});

</script>  

