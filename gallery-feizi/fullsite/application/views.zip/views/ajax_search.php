
    
	<script type="text/javascript">
       $(document).ready(function(){
	   $("#email").blur(function() {
	   var email = $('#email').val();
	   if(email=="")
	    {
        $("#emailerror").html("");
		}
    else
       {
	
	 $.ajax({
     type: "POST",
     url: "<?php echo site_url("register/email_chk"); ?>",
     data: { email:email}
     }).done(function( msg ) {
	 $("#emailerror").html(msg);
	 });
	return false;
   }
    });
    });
</script>


	<script type="text/javascript">
       $(document).ready(function(){
	   $("#user_name").blur(function() {
	   var name = $('#user_name').val();
	   if(name=="")
	    {
        $("#disp").html("");
		}
    else
       {
	
	 $.ajax({
     type: "POST",
     url: "<?php echo site_url("register/chk"); ?>",
     data: { user_name:name}
     }).done(function( msg ) {
	 $("#disp").html(msg);
	 });
	return false;
   }
    });
    });
</script>