<?php $site=site_url().'mobile_apps/'; ?>



<div class="container" id="Apps">

  <div class="hero-unit" id="dragable"> 



 <?php echo form_open('mobile_apps/#Apps')?>

    <div id="filter" class="filter"></div>

    <div class="rest_search"> 

    <div class="rest_fliter_type">

    <h5>State</h5>

     <select id="state_type" name="state_type" onchange="state()">

      <option value="">Select State</option>

       <?php 

	   if($item){

	    foreach($item as $item){

	   if($item->state_code==$state){?>

           <option value="<?php echo $item->state_code?>" selected="selected"><?php echo $item->state?></option>

       <?php } else{?>

       

      <option value="<?php echo $item->state_code?>"><?php echo $item->state?></option>

    <?php }}}?>

    </select>

    </div>

 <div id="loder"></div>

    <div class="rest_fliter_type cluster_search">

     <h5>City</h5>

       <select id="input_city" name="input_city" class="select-city">

    <?php if($city_all){

		//$city_all = array_diff($city_all, array($city));

		foreach($city_all as $city_m){

         if($city_m->city_id==$city)	{?>   

			<option value="<?php echo $city_m->city_id?>" selected="selected"><?php echo $city_m->city?></option>

		  <?

		 }else{ 

		    ?>

            <option value="<?php echo $city_m->city_id?>"><?php  echo $city_m->city?></option>

		<?  } }

		}

	?>

        </select>

    </div>

  

    <input class="login-btn" type="submit" value="Search" name="submit"/>

    <?php   echo form_close();?>

    </div>

    <div id="msg"></div>

    <div class="row-fluid resevent">

  <?php	

  if(isset($_REQUEST['submit'])){

		if(!empty($offer)){

		 foreach($offer as $offer){ 

             echo '<div id="image_box">'; 

				?>

                   <a class="fancybox fancybox.ajax" href="<?php echo site_url("mobile_apps/get_Apps/".$offer->ID)?>"><img src="<?php echo base_url().'uploadimages/files/'.$offer->restaurant_logo;?>"/></a>

                 <?php 

	          ?>

              <h4><a class="fancybox fancybox.ajax" href="<?php echo site_url("mobile_apps/get_Apps/".$offer->ID)?>"><?php echo $offer->restaurant_name; ?></a></h4>

          </div>

    <?php }

		}

		else{

			echo '<div class="error"><h2> Sorry, No results found for the entered Search option..</h2></div>';

			}

  }

			?>

</div>

    </div>

</div>

 <script type="text/javascript">   

    function state(){

   var form_data ={state: $('#state_type').val()};



   $("#loder").html('<img  src="<?php echo base_url().'/ajax-loader.gif'; ?>"/>');

   $.ajax({

       url:'<?php echo site_url("mobile_apps/get_city"); ?>',

       data:form_data,    

       datatype:'json',

       success:function(data){

		    var newdata= jQuery.parseJSON(data);

		   $("#loder").empty();

		   $("#input_city").empty();

		   $.each(newdata,function(i,index){

                htmlString="<option value='"+index['city_id']+"'>"+index['city']+"</option>"

				$("#input_city").append(htmlString);

           });

        }

    });

}

</script>