<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<?php $this->load->view('layout/header'); ?>
<link rel="stylesheet" href="<?php echo base_url().'assets/slider/index_data/jquery.css'; ?>" type="text/css" media="screen">
 <?php /*?><script type="text/javascript">



function pass() {
 var email = $('#password').val();
 var confirm_password = $('#confirm_password').val();
    if(email==""){
        $("#emailerror").html("Enter a password");
        return false;
     }else if(email.length<6){ 
	     $("#emailerror").html("Password should be atleast 6 character long!");
          return false;
     }else if(email.length>5){
          $("#emailerror").html("");
     }else if (email!== confirm_password) {
         $("#emailerror").html("Please make sure your passwords match!");
		 return false;
	 }else{	

	       $.ajax({

			type: "POST",

			 url: "<?php echo site_url('login/updatepassword/'.$this->uri->segment(3)); ?>",

				data: { password:email,confirm_password:confirm_password}

					}).done(function( msg ) {

						if(msg==1){

						// $("#success").html('Password successfully updated');

				parent.$.fancybox.open({href : "<?php echo site_url().'login/index/';?>"+msg , type: 'ajax',height: 800, width: 500,scrolling : 'no'});



						 

						 }

					});

				 }

}

</script><?php */?> 


     

       <div class="hero-unit forget_password">

    	<h3>Update Password</h3>

 <?php 



 if(!empty($success_msg)){
 ?> 
 <div class="msg">
 <?php
 echo $success_msg;?>
 </div>
 <?php
       }
 ?>  
  <form action="<?php echo site_url('login/updatepassword/'.$this->uri->segment(3)); ?>" method="post"> 
      
      <label>Password</label> 
      <input type="password" name="password" value=""  id="password"/> 
   <p><span id="password">   <?php echo form_error('password'); ?> </span></p>
     
      <label>Confirm Password</label> 
      <input type="password" name="confirm_password" value=""  id="confirm_password"/> 
    <p><span id="password">  <?php echo form_error('confirm_password'); ?></span></p> 
     
      <div class="login_button">
       <input type="submit" name="login" value="Update Password" class="login-btn " /> 
      </div>
      
  </form>

 </div>

