
<?php 
 $base_url= base_url().'assets/';
?>
<link rel="stylesheet" type="text/css" href="<?=$base_url.'css/bootstrap.css'?>" media="screen" />
<link rel="stylesheet" type="text/css" href="<?=$base_url.'css/bootstrap.min.css'?>" media="screen" />
<link rel="stylesheet" type="text/css" href="<?=$base_url.'js/bootstrap.js'?>" media="screen" />
<link rel="stylesheet" type="text/css" href="<?=$base_url.'css/custom.css'?>" media="screen" />
<body style="background:transparent !important;">
<div id="layout-content" class="menu_navigation">
<div class="row-fluid resevent about_us_rest">
<div id="menu_item" class="nav-collapse collapse clear_both">
 <?php  
foreach($aboutus as $about){
	echo $about->about;} ?>   
    </div>
</div>
  </div>

</body>
