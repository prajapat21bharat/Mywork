<?php 
 $base_url= base_url().'assets/';
?>
<link rel="stylesheet" type="text/css" href="<?=$base_url.'css/jquery.fancybox.css'?>" media="screen" />
<link rel="stylesheet" type="text/css" href="<?=$base_url.'css/bootstrap.css'?>" media="screen" />
<link rel="stylesheet" type="text/css" href="<?=$base_url.'css/bootstrap.min.css'?>" media="screen" />
<link rel="stylesheet" type="text/css" href="<?=$base_url.'js/bootstrap.js'?>" media="screen" />
<link rel="stylesheet" type="text/css" href="<?=$base_url.'css/custom.css'?>" media="screen" />
<link rel="stylesheet" type="text/css" href="<?=$base_url.'js/bootstrap.min.js'?>" media="screen" />
<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript" src="<?=$base_url.'js/jquery.fancybox.js?v=2.1.5'?>"></script>
<body style="background:transparent !important;">
<div class="row-fluid resevent" >
<div id="menu_item" class="nav-collapse collapse clear_both">

  <?php	
		if($event){
		 foreach($event as $events){ 
		 echo '<div class="single-event">'; 
          echo '<div id="image_box">'; 
	        foreach($photo as $photos){
				if($photos->event_id==$events->event_id){?>
                  
                      <img src="<?php echo site_url().'uploadimages/events/'.$photos->image;?>"/>
                 <?php }
	          }?>
          </div>
       <div class="event">
        <h4><?php echo $events->event_title; ?></h4>
         <p><?php echo $events->event_vanue; ?></p>
         <div class="time"> <span><?php echo $events->start_date ; ?></span> To <span><?php echo $events->end_date; ?></span> </div>
     </div>
     </div>
    <?php }
		}else{ echo '<div class="error"><h4>Sorry, there is no data for this restaurant listing.</h4></div>';}?>
        
</div>
</div>
</body>