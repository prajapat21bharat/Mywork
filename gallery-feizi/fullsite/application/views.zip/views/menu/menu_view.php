<?php $url=site_url().'widget_iframe/';
$base_url= base_url().'assets/';?>
<link rel="stylesheet" type="text/css" href="<?=$base_url.'css/jquery.fancybox.css'?>" media="screen" />
<link rel="stylesheet" type="text/css" href="<?=$base_url.'css/bootstrap.css'?>" media="screen" />
<link rel="stylesheet" type="text/css" href="<?=$base_url.'css/bootstrap.min.css'?>" media="screen" />
<link rel="stylesheet" type="text/css" href="<?=$base_url.'js/bootstrap.js'?>" media="screen" />
<link rel="stylesheet" type="text/css" href="<?=$base_url.'css/custom.css'?>" media="screen" />
<link rel="stylesheet" type="text/css" href="<?=$base_url.'js/bootstrap.min.js'?>" media="screen" />
<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript" src="<?=$base_url.'js/jquery.fancybox.js?v=2.1.5'?>"></script>
<script type="text/javascript">
$(document).ready(function() {
			$('.fancybox').fancybox();
		});
function menu_cat(id){
	var form_data = {
    menu_id: id
	}
	
	$.ajax({
       url:'<?=$url.'get_menu_cat';?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		   
		   var newdata= jQuery.parseJSON(data);
		   $("#"+id).empty();
		   $(".main_menu").removeClass('active');
		  $("#main_menu_"+id).addClass('active');
		   if(newdata!=''){
			   $.each(newdata,function(i,index){
					//alert(index['city']+'state code'+index['state_code']);
					htmlString="<li class='sub_menu'><a href='javascript:void(0)' onclick='menu_item("+index['menu_cate_id']+")'> "+index['menu_categorie_name']+"</a></li>"
					$("#"+id).append(htmlString);
			   });
			   
		   }else{
			   $("#menu_cat").append('No Data Found');
		   }
       }
});
}


function menu_item(id){
	$("#menu_item").html('<img  src="<?php echo base_url().'/ajax-loader.gif'; ?>"/>');
	var form_data = {
    menu_cate_id: id
	}
	
	$.ajax({
       url:'<?=$url.'get_menu_item';?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		   
		   var newdata= jQuery.parseJSON(data);
		   $("#menu_item").empty();
		   $(".main_menu >ul").html('');
		   if(newdata!=''){
				$.each(newdata,function(i,index){
					
						
					  htmlString ="<div class='menu_list'><div class='image'>";
					 
					 if(index['menu_item_image']!=''){
					    htmlString +="<img src='<?=base_url().'uploadimages/menu_image/'?>"+index['menu_item_image']+"' height='200' width='200'/>";
					 
					 }else{
						 htmlString +="<img src='<?=base_url().'uploadimages/files/'.$restaurant[0]->restaurant_logo?>' height='200' width='200'/>";
					    }
					 
					 htmlString +="</div><div class='title'>"+index['title']+" </div>";
					 
					 if(index['menu_item_price']!='0'){
					     htmlString +="<div class='price'>Price : "+index['menu_item_price']+"$ </div>";
					 }else{
						 htmlString +="<div class='price'></div>"; 
						 }
					 
					  htmlString +="<div class='description'><span class='title-des'></span> "+index['menu_item_discription']+"</div></div>";
					 
						
					$("#menu_item").append(htmlString);
					
			   });
		   
		   }else{
			   $("#menu_item").append('<div class="error">No Data Found</div>');
		   }
       }
});
}

</script>
<style>
#menu_item {
	margin-top:20px;
}
.image {
	clear:both;
}
.image img {
	margin-right:10px;
	float:left;
	margin-bottom:20px;
}
.main_menu {
	margin-left:30px;
	float:left;
}
.sub_menu {
	width:100px;
}
#menu_cat {
	left: 24px;
	position: relative;
	top: 19px;
	width:80%;
	clear:both;
	margin-bottom:53px;
	font-weight:bold;
}
#menu_cat li {
	list-style:none;
	display:inline;
	width:100%;
	margin:0 10px 12px;
	background-color:#ff6600;
	padding:7px 16px;
	width:145px;
}
#menu_cat li a {
	color:#333;
	font-size:14px;
	text-decoration:none;
	color:#fff;
}
#main-menu ul li {
	list-style:none;
}
#main-menu ul li a {
	text-decoration:none;
}
#main-menu {
	width:100%;
	overflow:hidden;
	margin-top:20px;
}
#menu_item {
	margin: 72px auto 0;
	width: 89%;
}
#layout-content #main-menu li.main_menu {
	width:10%;
	position:relative;
}
#layout-content #main-menu li.main_menu ul {
	display:none;
}
#layout-content #main-menu li:hover ul {
	display:block;
	width:190px;
	background:#fff;
	position:absolute;
	z-index:99;
	top:32px;
}
#layout-content #main-menu li ul li a {
	color: #205700;
	font-family: arial;
	font-size: 14px;
	line-height: 20px;
	margin-bottom: 0;
	padding: 0 10px;
	text-shadow: none;
	width: 100%;
}
 <?php  if(!empty($menu_color)) {
?>  #main-menu .btn-primary {
background-color:#<?php echo $menu_color[0]->menu_colour;
?>
}
#layout-content .title {
color:#<?php echo $menu_color[0]->menu_colour;
?>
}
#layout-content #main-menu li ul li:hover {
background-color:#<?php echo $menu_color[0]->sub_menu_colour;
?>
}
 <?php
}
else {
?>  #main-menu .btn-primary {
background-color:#FF6600
}
#layout-content .title {
	color:#FF6600
}
#layout-content #main-menu li ul li:hover {
	background-color:#333
}
<?php
}
?>  .title-des {
 float: left;
 margin-right: 10px;
}
#layout-content #main-menu li ul li:hover a, #layout-content #main-menu li ul li a:hover {
	color:#fff;
}
 @media only screen and (min-width: 320px) and (max-width: 1200px) {
 #main-menu ul li a {
min-width:145px;
display:inline-block;
}
}




	/* Submenus – optional .parent class indicates dropdowns */
@media only screen and (min-width: 0px) and (max-width: 767px) {
 .primary-nav > li:hover > a {
 background: rgba(0, 0, 0, .5);
 border-bottom-color: transparent;
}
 .primary-nav li.parent > a:after {
 content: "▼";
 color: rgba(255, 255, 255, .5);
 float: right;
}
 .primary-nav li.parent > a:hover {
 background: rgba(0, 0, 0, .75);
}
 .primary-nav li ul {
 display: none;
 background: rgba(0, 0, 0, .5);
 border-top: 0 none;
 padding: 0;
}
 .primary-nav li ul a {
 border: 0 none;
 font-size: 12px;
 padding: 10px 5%;
 font-weight: normal;
}
 .primary-nav li:hover ul {
 display: block;
 border-top: 0 none;
}
 #layout-content li {
 margin: 0 0 10px !important;
 padding: 0 5% !important;
 position: relative;
 width: 90% !important;
}
#layout-content li.sub_menu {
margin: 0 0 0 !important;
}
#layout-content #main-menu li.active ul, #layout-content #main-menu li:hover ul {
 background: none repeat scroll 0 0 #FFFFFF;
 display: block;
 overflow: hidden;
 position: relative;
 top: 0;
 width: 100%;
 z-index: 99;
}
#layout-content #main-menu li ul li {
width:100% !important;
padding:0 !important;
margin:0;
}
#layout-content #main-menu li ul li a {
 font-size: 14px;
 padding: 0 10px;
 width:100%;
 color:#2f660a;
 text-shadow:none;
}
#main-menu ul li a {
width:93%;
}
} /* End Mobile Styles */
</style>
<?php



	
	?>
<body style="background:transparent !important;">
<div id="layout-content" class="menu_navigation hero-unit">
  <div class="clear_both" id="main-menu">
    <ul>
      <?php 
	if($main_menu){
	foreach($main_menu as $main_menu){ ?>
      <li class="main_menu" id="main_menu_<?=$main_menu->menu_id?>"><a href="javascript:void(0)" onClick="menu_cat('<?=$main_menu->menu_id?>')" class="btn btn-primary">
        <?=$main_menu->menu_name?>
        <span class="caret"> </a>
        <ul id="<?=$main_menu->menu_id?>">
        </ul>
      </li>
      <?php }
	}else{echo "<span>Sorry, there is no data for this restaurant listing.<span>";}?>
    </ul>
  </div>
  <p class="clear_both"></p>
  <div class="nav-collapse collapse clear_both" id="menu_cat">
    <ul id="main_cat_nav">
    </ul>
  </div>
  <p class="clear_both"></p>
  <div class="nav-collapse collapse clear_both" id="menu_item">
    <?php 
	if(!empty($item)){foreach($item as $item){?>
    <div class='menu_list'>
      <div class='image'>
        <?php if(!empty($item->menu_item_image)){?>
        <img src='<?=base_url().'uploadimages/menu_image/'.$item->menu_item_image?>' height='200' width='200'/>
        <?php } 
		
		else{ ?>
        <img src='<?=base_url().'uploadimages/files/'.$restaurant[0]->restaurant_logo?>' height='200' width='200'/>
        <?php }?>
      </div>
      <?php //  } ?>
      <div class='title'>
        <?=$item->title?>
      </div>
      <?php if($item->menu_item_price>0){?>
      <div class='price'>Price :
        <?=$item->menu_item_price?>
        $ </div>
      <?php }?>
      <div class='description'>
        <?=$item->menu_item_discription?>
      </div>
    </div>
    <?php }} ?>
  </div>
</div>
</body>
