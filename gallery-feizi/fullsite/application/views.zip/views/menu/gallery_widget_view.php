<?php 
$base_url= base_url().'assets/';?>
<link rel="stylesheet" type="text/css" href="<?=$base_url.'css/jquery.fancybox.css'?>" media="screen" />
<link rel="stylesheet" type="text/css" href="<?=$base_url.'css/bootstrap.css'?>" media="screen" />
<link rel="stylesheet" type="text/css" href="<?=$base_url.'css/bootstrap.min.css'?>" media="screen" />
<link rel="stylesheet" type="text/css" href="<?=$base_url.'js/bootstrap.js'?>" media="screen" />
<link rel="stylesheet" type="text/css" href="<?=$base_url.'css/custom.css'?>" media="screen" />
<link rel="stylesheet" type="text/css" href="<?=$base_url.'js/bootstrap.min.js'?>" media="screen" />
<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript" src="<?=$base_url.'js/jquery.fancybox.js?v=2.1.5'?>"></script>
<body style="background:transparent !important;">
<div class="row-fluid resevent">
<div id="menu_item" class="nav-collapse collapse clear_both">
  <?php	
  
		if($gallery){
		 foreach($gallery as $offers){ ?>
          <div id="image_box">
		 
                   
                    <img src="<?php echo site_url().'uploadimages/files/'.$offers->image;?>" height="200" width="300" />
                 <?php
				 echo '</div>';
				  }
	         // }?>
          </div>
    
    <?php //}
		}else{ echo '<div class="error"><h4>Sorry, there is no data for this restaurant listing.</h4></div>';}?>
</div>
</div>
</body>