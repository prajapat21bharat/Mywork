<link href="<?php echo base_url('assets/css/flages.css') ?>" rel="stylesheet">
<div class="user-city-list">
  <div class="first-country country odd">
    <div class="clearfix country country-1">
      <div class="f32 country_id_list"> <a href="javascript:void(0)" class="flag <?php echo strtolower($this->session->userdata('country_code'));?>" onClick="getall_state()"><?php echo $this->session->userdata('country_name');?></a> </div>
      <div class="left country_city_list country-1">
        <?php foreach($top_result as $top){ ?>
        <a href="<?php echo site_url()."search?state=$top->state&city=$top->city&country_code=$top->country_code&country_name=$top->country_id&/";?>"><?php echo $top->city;?></a>
        <?php }?>
      </div>
    </div>
  </div>
  <?php foreach($countery as $countery){ ?>
  <div class="clearfix country even">
    <div class="f32 country_id_list"> <a href="javascript:void(0)" class="flag <?php echo strtolower($countery->country_code);?>"><?php echo strtoupper($countery->country_id);?></a></div>
    <div class="left country_city_list country-30">
      <?php foreach($state as $state){ 
	 if($state->country_code==$countery->country_code){?>
      <a href="<?php echo site_url()."search?state=$state->state&city=$state->city&country_code=$state->country_code&country_name=$state->country_id&/";?>"><?php echo $state->city;?></a>
      <?php
	 }
	 }?>
    </div>
  </div>
  <?php   } ?>
</div>
