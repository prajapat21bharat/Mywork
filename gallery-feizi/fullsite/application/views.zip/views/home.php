<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$site=site_url()."restaurant/index/";
 ?>
<script>
/*function state(){
	
 var form_data = {
    state: $('#input_ststes').val()
   
 };

$("#loder").html('<img  src="<?php echo base_url().'/ajax-loader.gif'; ?>"/>');
$.ajax({
       url:'<?php echo site_url().'home/get_city';?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		   
		  
		  //alert(data);
		   var newdata= jQuery.parseJSON(data);
		   $("#loder").empty();
		   $("#input_city").empty();
		   $.each(newdata,function(i,index){
                //alert(index['city']+'state code'+index['state_code']);
				htmlString="<option value='"+index['city_id']+"'>"+index['city']+"</option>"
				$("#input_city").append(htmlString);
           });
       }
});
}

function resturent_result()
{
	var form_data = {
    city_id: $('#input_city').val()
   
 };
 
$("#restaurant_result").html('<div><img src="<?php echo base_url().'/loader.gif'; ?>"/></div>');

$.ajax({
       url:'<?php echo site_url().'home/getRestaurant';?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		//var newdata= jQuery.parseJSON(data);
		$("#restaurant_result").empty();
		  if(data!='')
		  {
			  
		      $("#restaurant_result").append(data);
		   }else
		   {
			    $("#restaurant_result").html('<div class="error"><h4>Currently restaurant has no details for selected option</h4></div>');
		   }
	 }
});
	
	
}

function seach_page(start_val){
	//alert('<?php $this->session->userdata('search_val') ?> '+ start_val)
	
 var form_data = {start:start_val};
 
$("#restaurant_result").html('<div><img src="<?php echo base_url().'/loader.gif'; ?>"/></div>');
$.ajax({
       url:'<?php echo site_url().'home/search_name_pagination';?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		 $("#restaurant_result").empty();
		  if(data!='')
		  {
			$("#restaurant_result").append(data);
		  }
	   }
     });
}

*/
</script>
<div id="restaurant_text">
  <div class="row-fluid">
    <div class="featured-rest">
      <?php
  	if(isset($retaurants)){?> <h6>Featured Restaurants</h6><?php }?>
    </div>
  </div>
</div>

<div id="restaurant_result">
  <?php
  	if(isset($retaurants))
	{$i=0;	
	foreach($retaurants as $data){
		
		if($i==0){
			echo '<div class="row-fluid">';
			}
			echo '<div class="row-field one_feature_rest span4"><div class="view-media"><a href="'.site_url().$data->slug.'"><img src="'.site_url().'uploadimages/files/'.$data->restaurant_logo.'" height="250" width="250" /></a></div>';
			echo '<div class="view-name"><a href="'.site_url().$data->slug.'">'.$data->restaurant_name.'</a><p class="address">'.$data->city.' , '.$data->state.'</p></div></div>';
			
		$i++;
		if($i==3){echo '</div>';$i=0;}
		
	    }
		if((count($retaurants)% 3)!=0)echo '</div>';
	}else{
			echo '<div class="error"><h4>Currently restaurant has no details for selected option</h4></div>';
		}
 	if(!empty($links)){echo $links;}
   ?>
</div>
