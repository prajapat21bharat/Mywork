<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<script type="application/javascript">

function registerSubmit(){
	
	//Ajax For Post Values
		$.ajax({
		type: "POST",
		url: '<?php echo base_url();?>register/registration',
		data:$('#registration').serialize(),
		async: false,
		success: function(msg) {
			
		document.getElementById('error-massege').innerHTML=msg;
               
                   var Select = $('#single').val(); 
                    
		  		if(msg==1){
                              
				document.getElementById('registration').style.display='none';
			    parent.location='<?php echo base_url().'register/change_profile/1/'; ?>';     
			    document.getElementById('error-massege').innerHTML='';
					}
					
		}

		});


return false;

}



</script>

<div class="hero-unit forget_password" id="signup_form" style="background-color:#F9F9F9;">
  <h3>Sign Up </h3>
  <div id='error-massege'></div>
  <?php
 	 $js = 'onsubmit="return false;" id=registration';
	  
    echo form_open('register/registration',$js );
	/*if(!empty($error))
 echo $error;*/
	?>
  <label>User Name </label>
  <!-- <span id="disp" ></span>-->
  <input type="text" id="user_name" name="user_name" value="<?php echo set_value('user_name'); ?>" />
  <div class="error_msg"><span id="txtFirstName"> <?php echo form_error('user_name'); ?></span></div>
  <label>Email </label>
  <!--<span id="emailerror" ></span>-->
  <input type="email"  id="email" name="email" value="<?php echo set_value('email'); ?>"/>
  <div class="error_msg"><span id="txtLastName"> <?php echo form_error('email'); ?> </span></div>
  <label>Password</label>
  <input type="password" name="password" id="password" value="<?php echo set_value('password'); ?>" onkeyup="Passlength(); return false;" />
  <!-- <span id="confirmMessage1" class="confirmMessage1"></span> -->
  
  <div class="error_msg"><span id="password"> <?php echo form_error('password'); ?> </span></div>
  <label>Confirm Password</label>
  <input type="password" name="confirm_password" id="confirm_password" value="<?php echo set_value('confirm_password'); ?>"  onkeyup="checkPass(); return false;"/>
  <!-- <span id="confirmMessage" class="confirmMessage"></span> -->
  
  <p><span id="confirm_password"> <?php echo form_error('confirm_password'); ?> </span></p>
  <div class="login_button">
    <input type="button" name="register" value="Signup" class="login-btn "  onclick="registerSubmit();"/>
  </div>
  <?php
    echo form_close();
	$this->load->view('ajax_search');
 ?>
</div>
<script type="text/javascript">
function checkPass()
{   var pass1 = document.getElementById('password');
    var pass2 = document.getElementById('confirm_password');
    var message = document.getElementById('confirmMessage');
    var length = pass1.value.length;
    var goodColor = "#66cc66";
    var badColor = "#ff6666";
	
     if(pass1.value == pass2.value)
	      {
             pass2.style.backgroundColor = goodColor;
             message.style.color = goodColor;
           //  message.innerHTML = "Passwords Match!"
           }
	else
	   {
        
            pass2.style.backgroundColor = badColor;
            message.style.color = badColor;
            // message.innerHTML = "Passwords Do Not Match!"
       }
}  
</script> 
<script>
function Passlength()
{   var pass1 = document.getElementById('password');
     var message1 = document.getElementById('confirmMessage1');
     var pass1length = pass1.value.length;
	 var goodColor = "#66cc66";
    var badColor = "#ff6666";
	if(pass1length<6)
	{
		    // pass1.style.backgroundColor = badColor;
             message1.style.color = badColor;
             message1.innerHTML = "Password should be atleast 6 character long!"
		
		}
		else
	   {
        
            
             message1.innerHTML = ""
       }
}
</script> 
