<?php $site=site_url().'owner/about/'; ?>
<?php /*?><base href="<?php echo substr($_SERVER['SCRIPT_NAME'], 0, strrpos($_SERVER['SCRIPT_NAME'], "/")+1); ?>" />
<link href="css/ui-lightness/jquery-ui-1.8.14.custom.css" rel="stylesheet" type="text/css" />
<link href="css/fileUploader.css" rel="stylesheet" type="text/css" />
<script src="assets/js/jquery-1.6.2.min.js" type="text/javascript"></script>
<script src="assets/js/jquery-ui-1.8.14.custom.min.js" type="text/javascript"></script>
<script src="assets/js/jquery.fileUploader.js" type="text/javascript"></script>
<script type="text/javascript">
		jQuery(function($){
			$('.fileUpload').fileUploader({
				allowedExtension: 'jpg|jpeg|gif|png|zip|avi',
				afterEachUpload: function(data, status, formContainer){
					$jsonData = $.parseJSON( $(data).find('#upload_data').text() );
				}
			});
		});
	</script>

<a class="btn btn-primary" href="<?php echo site_url().'owner/home/edit_retaurant/'.$this->session->userdata('restaurant_id');?>">Back</a><br />
<br />
<form action="<?=$site;?>supload" method="post" enctype="multipart/form-data">
  <input type="file" name="userfile" class="fileUpload" multiple>
  <button id="px-submit" type="submit">Upload</button>
  <button id="px-clear" type="reset">Clear</button>
</form>
<br />
</br><?php */?>

<div class="container-fluid main-container">
<div class="row-fluid">
<div class="span12">
<?php include('edit_resturant_header.php') ?> 
<div class="container-fluid content-wrapper cluster_container mob-right-part span10">
  <div class="hero-unit"> 
    <h3 class="title">About Us</h3>
    <div class="back_color white_bg">
<?php echo form_open($site.'values') ?>
<textarea name="content" id="content" ><? if(!empty($s)) foreach($s as $s){ echo $s->about;}?>
</textarea>
<?php echo display_ckeditor($ckeditor); ?> <br />
<div class="login_button">
<input class="login-btn" type="submit" name="submit" value="Submit" />
</div>
</form></div>
</div></div>
</div>
</div>
</div>