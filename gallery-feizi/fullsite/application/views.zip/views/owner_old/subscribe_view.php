<?php $site=site_url().'owner/subscribe/'; ?>
<?php
if(!empty($no_sms[0]->no_of_sms))
{
	$value=$no_sms[0]->no_of_sms-$no_sms[0]->sent_sms;
}else{
	$value=0;
	}
?>
<script>

function subscribe_msg(){
 <?php if($value >= $subscribe){ ?>
	if(jQuery('#sand_msg').val()!=''){
		jQuery('#success_msg').html('<img src="<?php echo base_url().'ajax-loader.gif' ?>" />');
		
	if(jQuery('#latter_date').val()==''){
      var form_data = {msg:jQuery('#sand_msg').val(),
		                href:jQuery('#href').val(),
						no_sms:'<?php echo $no_sms[0]->sent_sms ;?>'};
     jQuery.ajax({
       url:'<?php echo $site.'sms';?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		  jQuery('#success_msg').html('Message has been Sent Successfully');
		  jQuery('#sand_msg').val('');
		  jQuery('#href').val('');
		  jQuery('#latter_date').val('');
		  jQuery("#myModal").modal('hide');
		  location.reload(); 
       }
     });
	}else{
		var form_data = {msg:jQuery('#sand_msg').val(),
		                href:jQuery('#href').val(),
						date_time:jQuery('#latter_date').val()};
		jQuery.ajax({
       url:'<?php echo $site.'corn_msg';?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		  jQuery('#success_msg').html('Queue SMS for sending later  Successfully  Add');
		 jQuery('#sand_msg').val('');
		  jQuery('#href').val('');
		  jQuery('#latter_date').val('');
		  jQuery('#queue_latter').prop('checked', false);
		  $("#date_div").hide();
		  jQuery("#myModal").modal('hide');
       }
     });
		
		
		
		}
	}else{jQuery('#success_msg').html('Please Enter Some Words');}
 <?php  }else{ ?> jQuery('#success_msg').html('Insufficient SMS'); <? }?>
}



function show_model(){
	$("#myModal").modal('show');
	}

$(function(){
	$("#queue_latter").click(function(){
		if ($('#queue_latter').is(':checked')) {
			$("#date_div").show();
		}else{
			$("#date_div").hide();
		}
	});
	
	$("#confirm").click(function(){
		$("#confirm_box").modal('show');
	});
	
});


function confirm_msg(){
	if(jQuery('#confirm_msg').val()!=''){
var form_data = {
		 msg:jQuery('#confirm_msg').val()
		  };
   jQuery.ajax({
       url:'<?php echo $site.'confirm_sms';?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		   if(data==1){jQuery('#success_msg_con').html('Message Successfully  Updated');
		   }else{jQuery('#success_msg_con').html('Message Successfully  Inserted')}
		   $("#confirm_box").modal('hide');
       }
     });

	}else{jQuery('#success_msg_con').html('Please Enter Some Words');}
	
	
	}
	
	
function medel_close(){
	$('#myModal').modal('hide');
	}
	
</script>
<script>
(function($) {
    $.fn.extend( {
        limiter: function(limit, elem) {
            $(this).on("keyup focus", function() {
                setCount(this, elem);
            });
            function setCount(src, elem) {
                var chars = src.value.length;
                if (chars > limit) {
                    src.value = src.value.substr(0, limit);
                    chars = limit;
                }
                elem.html( limit - chars );
            }
            setCount($(this)[0], elem);
        }
    });
})(jQuery);

$(document).ready( function() {
	var elem = $("#chars");
	$("#confirm_msg").limiter(130, elem);
	var elem = $("#sand_chars");
	$("#sand_msg").limiter(130, elem);
	
	
});



  
</script>
<style>
.bootstrap-datetimepicker-widget {
	z-index:9999 !important
}
</style>

<div class="container-fluid main-container subscribe">
<div class="row-fluid">
<div class="span12">
  <?php $this->load->view('owner/edit_resturant_header.php') ?>
  <div class="container-fluid content-wrapper cluster_container mob-right-part span10">
    <div class="hero-unit">
      <h3 class="title">Subscribers</h3>
      <div class="back_color white_bg">
        <div class="count_subscribe"><span class="count_label">Total No of Subscribers</span> <span class="count">: &nbsp;<?php echo $subscribe?></span></div>
        <div class="count_subscribe"><span class="count_label">Total No of SMS</span>
          <span class="count">: &nbsp;<?php if(!empty($no_sms[0]->no_of_sms)) echo $no_sms[0]->no_of_sms;else{ echo 0;}?></span>
        </div>
        <div class="count_subscribe"><span class="count_label">Total No of Sent SMS</span>
        <span class="count">: &nbsp;<?php if(!empty($no_sms[0]->sent_sms)) echo $no_sms[0]->sent_sms;else{ echo 0;}?></span>
        </div>
        <div class="count_subscribe"><span class="count_label">Remaining SMS</span> <span class="count">: &nbsp;<?php echo $value;?></span></div>
        <div class="csv_download lables" ><a class="login-btn" href="<?php echo $site.'csvsubscribers' ?>">Download csv file</a> <span class="lable_input">Get an excel compatable file of all subscribers.</span> </div>
        <div class="send_sms_sub lables" > <a class="login-btn" href="javascript:void(0)" onclick='show_model()'>Send SMS to Subscribers </a><span class="send_sms_sub lable_input">Send an SMS message to all of your subscribers.</span> </div>
        <div class="send_sms_sub lables" > <a class="login-btn" href="javascript:void(0)" id="confirm">Confirm Message </a> <span class="send_sms_sub lable_input">Configure Subscription Confirmation Message.</span></div>
        <table width="100%" class="table table-striped table-bordered table-radmin">
          <thead>
            <tr>
              <th width="">S.NO.</th>
              <th width="">Massage</th>
              <th width="">Hyperlink</th>
              <th width="">Send SMS</th>
              <th width="">Date</th>
              <th width="">Click</th>
            </tr>
          </thead>
          <?php
	  $i=1;
	  if(!empty($subscribe_sms)){
	   foreach ($subscribe_sms as $subscribe_sms){ ?>
          <tr>
            <td><?php echo $i;?></td>
            <td><?php echo $subscribe_sms->massage ?></td>
            <td><?php echo $subscribe_sms->href ?></td>
            <td><a href="<?php echo $site.'msg_user/'.$subscribe_sms->id;?>"><?php echo $subscribe_sms->no_of_send_msg?></a></td>
            <td><?php echo $subscribe_sms->date; ?></td>
            <td><?php echo $subscribe_sms->click; ?></td>
          </tr>
          <?php
	  $i=$i+1; } }?>
        </table>
      </div>
      <div class="modal fade" style="display:none" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal">x</button>
              <h4 class="modal-title" id="favriots_model">Send SMS Blast to Subscribers</h4>
            </div>
            <div class="modal-body">
              <div id="success_msg"></div>
              <div class="">
                <label>Message</label>
                <textarea name="msg_box" id="sand_msg"></textarea>
                <span class="char_remain">Characters remaining: <span id="sand_chars">130</span></span>
                <label>Hyperlink</label>
                <span class="href_http">http://</span>
                <input type="text" id="href" />
                </div>
                
                <div class="ques_message">                
                    <label class="ques_sms">Queue SMS for sending later</label>
                    <input type="checkbox" id="queue_latter" />
                </div>

                <div id="date_div" style="display:none">
                <label>SMS Delivery Time (Central Time)</label>
                <div id="datetimepicker" class="input-append date">
                <input type="text" id="latter_date"/>
                <span class="add-on"> <i data-time-icon="icon-time" data-date-icon="icon-calendar"></i> </span> </div>
                </div>
                <div class="login_button">
                <input type="button" class="login-btn" onclick="subscribe_msg()" value="Submit" />
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /.modal-content --> 
      </div>
      <!-- /.modal-dialog --> 
    </div>
    <div class="modal fade" style="display:none"  id="confirm_box" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">x</button>
            <h4 class="modal-title" id="favriots_model">Configure Subscriber Confirmation Message</h4>
          </div>
          <div class="modal-body">
            <div id="success_msg_con"></div>
            <div class="">
              <label>Message</label>
              <textarea name="msg_box" id="confirm_msg"><?php if(!empty($confirm_msg)){echo $confirm_msg[0]->confirm_msg; }?>
</textarea>
              <span class="char_remain">Characters remaining: <span id="chars">130</span></span> 
              
              <div class="login_button">
              <input type="button" class="login-btn" onclick="confirm_msg()" value="Submit" />
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- /.modal-content --> 
    </div>
  </div>
</div>
<script type="text/javascript" src="<?php echo site_url();?>assets/js/bootstrap-datetimepicker.min.js"></script> 
<script type="text/javascript" src="<?php echo site_url();?>assets/js/bootstrap-datetimepicker.ptr.min.js"></script> 
<script type="text/javascript">
      $('#datetimepicker').datetimepicker({
        format: 'dd/MM/yyyy hh:mm',
        language: 'pt-BR',
		pick12HourFormat: true,
		//pickSeconds: false,
      });
    </script> 
