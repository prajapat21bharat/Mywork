<?php $site=site_url().'owner/'; ?>
<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script>
<script type="text/javascript">

function state(){
	
 var form_data = {
    state: $('#state_id').val()
   
 };

$("#loder").show();
$.ajax({
       url:'<?php echo $site.'home/get_city';?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		   
		  
		   var newdata= jQuery.parseJSON(data);
		   $("#loder").hide();
		   $("#city").empty();
		   $.each(newdata,function(i,index){
                //alert(index['city']+'state code'+index['state_code']);
				htmlString="<option value='"+index['city_id']+"'>"+index['city']+"</option>"
				$("#city").append(htmlString);
           });
		   
       }
});
}


function add_photo()
{ 
	var id=$('#counter').val();
	photo='<input type="file" name="userfile'+id+'" value=""  /><br>';	
	  $('#counter').val(Number(id)+1)
	  $('#more_photo').append(photo);
	
}

function delete_image(id)
{
	var r=confirm('Are you Sure Delete This Image');
if (r==true)
	{
	var form_data = {
    photo_id: id
       };
		$.ajax({
			   url:'<?php echo $site.'home/delete_restaurant_gallery';?>',
			   data:form_data,    
			   datatype:'json',
			   success:function(data){
				   $('#'+id).empty();
				   
			   }
		});
	}
}

</script>
<div class="container-fluid main-container">
<div class="row-fluid">
<div class="span12">
<?php $this->load->view('owner/edit_resturant_header.php') ?> 
<div class="container-fluid content-wrapper cluster_container mob-right-part span10">
  <div class="hero-unit">
   <h3 class="title"><?php echo $this->session->userdata('restaurant_name'); ?></h3>
  <?php 
 $attributes = array('class' => 'edit_form white_bg');
 echo form_open_multipart('owner/home/edit_retaurant/'.$this->session->userdata('restaurant_id'),$attributes); ?>
    <div class="wit"><label>Restaurant Name</label>
    <input type="text" name="restaurant_name" value="<?php echo $restaurant[0]->restaurant_name?>"  />
    <?php echo form_error('restaurant_name'); ?></div>
   <div class="wit"> <label>Restaurant Logo</label>
    <input type="file" name="userfile1" value=""  />
    <img src="<?php echo base_url().'uploadimages/files/'.$restaurant[0]->restaurant_logo; ?>" width="100" height="100" />
    <?php if(!empty($error)) echo $error; ?></div>
    
   <div class="wit"> <label>Cuisines Type</label>    
   <input type="text" name="restaurant_cuisines" value="<?php echo $restaurant[0]->restaurant_cuisines; ?>"  />
    <?php echo form_error('restaurant_cuisines'); ?>
   </div>
    
    
    <div class="wit"> <label>Website</label>
    <input type="text" name="restaurant_website" value="<?php echo $restaurant[0]->restaurant_website; ?>"  /><span>Don't use http:// in url</span>
    <?php echo form_error('restaurant_website'); ?></div>
   
    
   <div class="wit"> <label>State</label>
    <select name="state_id" onchange="state()" id="state_id">
      <option value="<?php echo $restaurant[0]->state_id; ?>"><?php echo $restaurant[0]->state; ?></option>
      <?php
foreach($state as $state)
echo '<option value="'.$state->state_code.'" >'.$state->state.'</option>';?>
    </select>
    <div id='loder' style="display:none;"><img  src="<?php echo base_url().'ajax-loader.gif'; ?>"/></div>
    <?php echo form_error('state_id'); ?></div>
   <div class="wit"> <label>City</label>
    <select name="city_id" id="city">
      <option value="<?php echo $restaurant[0]->city_id; ?>"><?php echo $restaurant[0]->city; ?></option>
    </select>
    <?php echo form_error('city_id'); ?></div>
   <div class="wit"> <label>Zip Code</label>
    <input type="text" name="zip_code" value="<?php echo $restaurant[0]->zip_code; ?>"  />
    <?php echo form_error('zip_code'); ?>
    
    <input type="hidden"  name="country_id" value="USA"  /></div>
   <div class="wit"> <label>Address</label>
    
    <textarea id="address"  name="restaurant_address" ><?php echo $restaurant[0]->restaurant_address; ?></textarea>
    
  
    <?php echo form_error('restaurant_address'); ?></div>
   <div class="wit"> <label>FaceBook Url</label>
    <input type="text" name="restaurant_facebook_url" value="<?php echo $restaurant[0]->restaurant_facebook_url; ?>"  /><span>Don't use http:// in url</span>
    <?php echo form_error('restaurant_facebook_url'); ?></div>
   <div class="wit"> <label>Twitter Url </label>
    <input type="text" name="restaurant_twitter_url" value="<?php echo $restaurant[0]->restaurant_twitter_url; ?>"  /><span>Don't use http:// in url</span></div>
    <div class="wit"> <label>Mobile App Url</label>
    <input type="text" name="mobile_app_url" value="<?php echo $restaurant[0]->mobile_app_url; ?>"  /><span>Don't use http:// in url</span>
    <?php echo form_error('mobile_app_url'); ?> 
    
    <?php echo form_error('restaurant_twitter_url'); ?></div>
    <div class="wit"> <label>Contact No</label>
    <input type="text" name="restaurant_phone" value="<?php echo $restaurant[0]->restaurant_phone; ?>"  />
    <?php echo form_error('restaurant_phone'); ?></div>
 
   
    <div class="wit">
    <label>Active</label>
    <span class="radio-active">Yes</span>
    <input type="radio" name="restaurant_is_active" value="1" <?php if($restaurant[0]->restaurant_is_active==1){?>checked="checked"; <? }?> />
   <span class="radio-active">No</span>
    <input type="radio" name="restaurant_is_active" value="0" <?php if($restaurant[0]->restaurant_is_active==0){?>checked="checked"; <? }?> />
    <?php echo form_error('restaurant_is_active'); ?>
    </div>
     <div class="wit">
    <label>Gallery Image</label>
     <input type="file" multiple name="userfile[]"  />
    <?php echo form_error('userfile1'); ?>
    <div id="example1" class="showbiz-container"> 
     
   <?php
if($restaurant_photo)
{?>
   <div class="showbiz-navigation center sb-nav-grey owner"> 
   <a id="showbiz_left_1" class="sb-navigation-left owner_prev"><i class="sb-icon-left-open"></i></a> 
   <a id="showbiz_right_1" class="sb-navigation-right owner_next"><i class="sb-icon-right-open"></i></a>
          <div class="sbclear"></div>
        </div>
        
        <?php }?>
      <!-- END OF THE NAVIGATION -->
      
      <div class="divide20"></div>
      <div id="sbiz9283" class="showbiz" data-left="#showbiz_left_1" data-right="#showbiz_right_1" data-play="#showbiz_play_1">
        <div style="height: 250;" class="overflowholder">
          <ul style="width: 1200; left: 0px; height: 250;">
            <?php
foreach($restaurant_photo as $photo)
{?>
            <li style="width: 180px;" class="sb-grey-skin" id="<?php echo $photo->photo_id; ?>">
              <div class="mediaholder">
                <div class="mediaholder_innerwrap"> <img style="height:150px; width:100%;" alt="" src="<?php echo base_url().'thumimage/'.$photo->thumbimage; ?>" >
                  <div style="opacity: 0;" class="hovercover"> <a class="fancybox" rel="group" href="<?php echo base_url().'/uploadimages/files/'.$photo->image; ?>">
                    <div class="lupeicon notalone"><i class="sb-icon-search"></i></div>
                    </a> </div>
                </div>
              </div>
              <div class="detailholder">
                <h4 class="showbiz-title txt-center delete_btn"><a class="login-btn" href="javascript:void(0)"  onclick="delete_image(<?php echo $photo->photo_id; ?>)">Delete</a></h4>
              </div>
            </li>
<?php } ?>
          </ul>
          <div class="sbclear"></div>
        </div>
        <!-- END OF OVERFLOWHOLDER -->
        <div class="sbclear"></div>
      </div>
    </div>
   
 
    </div>
    <div id="sub_btn">
      <input class="login-btn" type="submit" name='' value="Save" />
      </div>
    </div>

</div>
 
</div>
</div>
</div>