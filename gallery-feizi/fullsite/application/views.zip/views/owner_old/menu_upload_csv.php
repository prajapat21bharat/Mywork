<?php $site=site_url().'owner/menu_item/'; ?>

<div class="container-fluid main-container">
<div class="row-fluid">
<div class="span12">
<?php $this->load->view('owner/edit_resturant_header.php') ?>
<div class="container-fluid content-wrapper cluster_container mob-right-part span10">
  <div class="hero-unit">
    <h3 class="title">Upload Menu</h3>
    <div class="white_bg">
      <div id="msg"></div>
      <form class="edit_form inner_grey_bg" action="<?php echo $site.'menu_upload';?>" method="post" enctype="multipart/form-data">
        <h5 class="title">Select Csv file</h5>
        <input type="file" name="userfile" class="fileUpload" >
        <input id="px-submit" type="submit" class="login-btn" value="Upload" />
      </form>
      <div class="instruction"> <span class="formate_span"> <a class="login-btn" href="<?php echo $site.'download'; ?>">File Format</a> </span> </div>
      <div class="csv_error">
        <?php if(!empty($error)){
	          echo $error; }
	   
	   if(!empty($csv_error)){
		   echo '<span>Please upload again  Only Error Row Not all row</span>';
		  foreach($csv_error as $csv_error){
			  echo '<p>';
			 if(!empty($csv_error['row']))echo $csv_error['row'].' -  ';
			    if(!empty($csv_error['error']))echo $csv_error['error'];
				 echo '</p>';	  
		 }
		 
		}		
		?>
      </div>
    </div>
  </div>
</div>
