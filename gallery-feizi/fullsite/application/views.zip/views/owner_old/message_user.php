<?php $site=site_url().'owner/'; ?>

<div class="container-fluid main-container">
<div class="row-fluid">
<div class="span12">
 <?php $this->load->view('owner/edit_resturant_header.php') ?>
<div class="container-fluid content-wrapper cluster_container mob-right-part span10">

  <div class="hero-unit">
 
    <h3 class="title">SMS Receiver Subscriber</h3>
    <div class="back_color white_bg">
    <a class="add_restaurant_btn" href="<?php echo site_url();?>/owner/subscribe/">Back</a>
      <table width="100%" class="table table-striped table-bordered table-radmin">
        <thead>
          <tr>
            <th width="">Name</th>
            <th width="">Email</th>
            <th width="">Contact No.</th>
          </tr>
        </thead>
        <?php
	  $i=1;
	  if(!empty($message_user)){
	   foreach ($message_user as $message_user){ ?>
        <tr>
          <td><?php echo $message_user->first_name.' '. $message_user->last_name?></td>
          <td><?php echo $message_user->email ?></td>
          <td><?php echo $message_user->user_phone ?></td>
        </tr>
        <?php
	  $i=$i+1; } }?>
      </table>
    </div>
  </div>
</div>
