<?php $site=site_url().'owner/menu_item/'; ?>
<script type="text/javascript">
  $().ready(function() {
	  
	$("#select1").change(menu_item_val);
   
  });
  
  
function menu_item_val() {
				
				var form_data = {
							   menu_id:$("#select1").val()
							 };
							$.ajax({
							  url:'<?php echo $site.'get_menu_item';?>',
								data:form_data,    
								  datatype:'json',
									success:function(data){
										$("#select2").empty();
										
									var newdata=jQuery.parseJSON(data);
									 $.each(newdata,function(i,index){
									 htmlString="<option value='"+index['menu_cate_id']+"'>"+index['menu_categorie_name']+"</option>"
								     $("#select2").append(htmlString);
									   });
								   }//End Success
							  }); //End Ajax
		}
  
 
  function menu_type_add()
  {
	  if($("#menu_type_value").val())
	  {
		//alert($("#menu_type_value").val());
		var menu_val=$("#menu_type_value").val();
	var form_data = {
		   menu_name:menu_val
		 };
		 $.ajax({
          url:'<?php echo $site.'add_menu_type';?>',
            data:form_data,    
              datatype:'json',
                success:function(data){
				$('#menu_add').val("");
		         $('#select1').append('<option value='+data+' selected="selected">'+menu_val+'</option>');
				 $('#add_menu_type').html('Added successfully')
				 
			   }//End Success
	      }); //End Ajax 
	  }
  }
  
  
  function menu_name_add()
  {
	  
	  var menu_name=$("#add_menu_name").val();
	  var menu_type=$("#select1").val();
	  if(menu_type){
	  if($("#add_menu_name").val())
	  {
		//alert($("#menu_type_value").val());
		
	var form_data = {
		   menu_cate_name:menu_name,
		   menu_id:menu_type
		 };
		 $.ajax({
          url:'<?php echo $site.'add_menu_categories';?>',
            data:form_data,    
              datatype:'json',
                success:function(data){
				$('#menu_add').val("");
		         $('#select2').append('<option value='+data+' selected="selected">'+menu_name+'</option>');
				 $('#add_menu').html('Added successfully')
				 
			   }//End Success
	      }); //End Ajax 
	  }	  
	  }else
	  {
		  alert('Please select Menu type');
	  }
  }
  
  
  
 
  function menu_type(){
	  
	  $('#add_menu_type').html('<input id="menu_type_value" placeholder="Enter Menu Type Name" type="text" name="menu_type"/><input type="button" class="login-btn" onclick="menu_type_add()" value="Submit">');
	  }
  
  function add_menu(){
	  
	  $('#add_menu').html('<input id="add_menu_name" placeholder="Enter Menu Name" type="text" name="menu_type"/><input class="login-btn" type="button" onclick="menu_name_add()" value="Submit">');
	  }
  
 </script>

<div class="container-fluid main-container">
<div class="row-fluid">
<div class="span12">
 <?php $this->load->view('owner/edit_resturant_header.php') ?>
<div class="container-fluid content-wrapper cluster_container mob-right-part span10">
  <div class="hero-unit">    
    <h3 class="title">Update  Menu item</h3>
     <h2>
      <?php if(!empty($Success))echo $Success; ?>
    </h2>
    <span id=menu_msg></span>
    <?php
	  foreach($submenu as $submenu){
		  	$attr=array('class'=>'edit_form white_bg');
	 echo  form_open_multipart($site.'edit_menu/'.$this->uri->segment(4),$attr)?> 
    <div class="wit"> <label>Select Menu Type</label>
    <select id="select1" name="menu_id" >
      <option value="<?php echo $submenu->menu_id; ?>">
      <?=$submenu->menu_name;?>
      </option>
      <?php  foreach($menus as $menus){?>
      <option value="<?=$menus->menu_id;?>">
      <?=$menus->menu_name;?>
      </option>
      <?php }?>
    </select>
    <span class="pointer" onclick="menu_type()">Add Menu Type</span>
    <?php echo form_error('menu_type'); ?></div>
    <div id="add_menu_type" class="add-new-menu"></div>
    <div class="wit"><label>Select Menu</label>
    <select  id="select2" name="menu_categories_id">
      <option value="<?php echo $submenu->menu_categories_id; ?>">
      <?=$submenu->menu_categorie_name;?>
      </option>
    </select>
    <span class="pointer" onclick="add_menu()">Add Menu</span>
    <div id="add_menu" class="add-new-menu"></div>
    <?php echo form_error('menu_categories_id'); ?></div>
   <div class="wit"> <label>Title</label>
    <input type="text" name="title" value="<?=$submenu->title;?>" />
    <?php echo form_error('title'); ?></div>
    <div class="wit"><label>Description</label>
    
   
    <textarea name="menu_item_discription" id="content" ><?php echo $submenu->menu_item_discription; ?>
    </textarea>
<?php echo display_ckeditor($ckeditor); ?></div> 

   <div class="wit"> <label>Price</label>
    <input type="text" name="menu_item_price" value="<?=$submenu->menu_item_price;?>" /><span class="price_rs">$</span>
    <?php echo form_error('price'); ?>
    </div>
    
   <div class="wit"> <label>Image</label>
    
    <input type="file" name="userfile" value="" />
    <img src="<?=site_url().'uploadimages/menu_image/'.$submenu->menu_item_image;?>" height="150" width="150"/>
    <?php if(!empty($error))echo $error; ?>
    </div>
    
    
   
    <div class="wit"><label>Active</label>
    <span class="radio-active">Yes</span>
    <input type="radio" name="active" <? if($submenu->active=='1')echo 'checked="checked"';?> value="1" />
   <span class="radio-active"> No</span>
    <input type="radio" name="active" <? if($submenu->active=='0')echo 'checked="checked"';?> value="0" />
    </div>
    
    <div class="wit">
    
    <div id="sub_btn">
    <input class="login-btn" type="submit"  value="Submit" />
    <a href="<?php echo $site;?>"><input class="login-btn" type="button"  value="Cancel" /></a>
    </div>
    
    </div>
    
    </form>
    <?php }?>
    </div>
  
</div>
</div>
</div>
</div>