<?php $site=site_url().'owner/offers/'; ?>
<script type="text/javascript">

function menu_item_delete(id)
{
var r=confirm('Are Sure Delete This Offer');
if (r==true)
	{
	var form_data = {
		 offer_id:id
		  };
    $.ajax({
       url:'<?php echo $site.'delete_offer';?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		  $('#'+id).hide();
		  $('#msg').html('Success Fully Deleted');
       }
     });
}

}

function active(value,offer_id)
{

var form_data = {
		 active:value,
		 offer_id:offer_id
		  };
    $.ajax({
       url:'<?php echo $site.'active_inactive';?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		   
		   if(data!='1')
		   {
			   
            $('#actve_deactive_'+offer_id).html("<a title='Enable' onclick='active(1,"+offer_id+")' href='javascript:void(0)'><img src='<?php echo base_url().'assets/img/btn-red1.png'?>'/></a>");
			   
		   }else{
			       $('#actve_deactive_'+offer_id).html("<a title='Enable' onclick='active(0,"+offer_id+")' href='javascript:void(0)'><img src='<?php echo base_url().'assets/img/btn-green.png'?>'/></a>");
		   }
		  
		
       }
     });


}


$(document).ready(function(){
$('#pagination .active').html('<a href="<?php echo $site; ?>">1</a>');
$("#pagination a:last").remove();
	});
</script>

<div class="container-fluid main-container">
<div class="row-fluid">
<div class="span12">
 <?php $this->load->view('owner/edit_resturant_header.php') ?>
<div class="container-fluid content-wrapper cluster_container mob-right-part span10">

  <div class="hero-unit">
 
    <h3 class="title">Offers List </h3>
    <div id="msg"></div>
    
    <div class="back_color white_bg">
    <h5><a class="add_restaurant_btn" href="<?php echo $site.'add_offer'; ?>">Add Offers</a></h5>
   <?php if(!empty($offers)){ ?>
    
    <table width="100%" class="table table-striped table-bordered table-radmin">
      <thead>
        <tr>
          <th width="">Title</th>
          <th width="">Restaurant</th>
          <th width="">Start</th>
          <th width="">End</th>
          <th width="">Action</th>
        </tr>
      </thead>
      <?php foreach ($offers as $offers): ?>
      <tr id='<?php echo $offers->offer_id ; ?>'>
        <td> <a href="<?php echo $site.'edit_offer/'.$offers->offer_id; ?>"><?php echo $offers->offer_title; ?></a></td>
        <td><?php echo $offers->restaurant_name; ?></td>
        <td><?php echo $offers->start_date.' '.$offers->start_time; ?></td>
        <td><?php echo $offers->end_date.' '.$offers->end_time; ?></td>
        <td>
        <?php if($offers->active==1){
			$active="\"Enable\"";
			$dactive="\"Disable\"";
			
			
			  echo "<span onmouseover='tooltip.show($dactive);' onmouseout='tooltip.hide();'  id='actve_deactive_$offers->offer_id'><a title='Disable' onclick='active(0,$offers->offer_id)' href='javascript:void(0)'><img src='".base_url()."assets/img/btn-green.png'  /></a></span>";
			 
		}else{
			echo  "<span onmouseover='tooltip.show($active);' onmouseout='tooltip.hide();' id='actve_deactive_$offers->offer_id'><a title='Enable'  onclick='active(1,$offers->offer_id)' href='javascript:void(0)'><img src='".base_url()."assets/img/btn-red1.png' /></a></span>"; 
             } ?>
        |
        <a onmouseover='tooltip.show("Edit");' onmouseout='tooltip.hide();' href="<?php echo $site.'edit_offer/'.$offers->offer_id; ?>"> <img src="<?php echo base_url().'uploadimages/site_image/edit.png';?>"/></a> | <a href="javascript:void(0)" onmouseover='tooltip.show("Delete");' onmouseout='tooltip.hide();' onclick="menu_item_delete(<?php echo $offers->offer_id; ?>)"> <img src="<?php echo base_url().'uploadimages/site_image/delete.png';?>"/></a></td>
      </tr>
      <?php endforeach; ?>
 </table>
 
    <?php }else{
		echo '<div class="error"><h4>No Data Found</h4></div>';
		} echo $links;?> 
        </div></div>
</div>
</div>
</div>
</div>