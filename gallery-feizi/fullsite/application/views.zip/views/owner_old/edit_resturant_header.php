
<?php  $sagment=$this->uri->segment(3);
  $sagment2=$this->uri->segment(2);
$sagment3=$this->uri->segment(4);
?>

<div class="sidebar-nav mob-left-part span2">
    <ul class="nav nav-stacked left-menu">
        <li><a class="<? if($sagment=='review'){echo 'active';}?>" href="<?php echo site_url().'owner/home/review/'.$this->session->userdata('restaurant_id'); ?>" title="Preview">
        <span class="box preview"></span>
        <span class="hidden-tablet hidden-phone">Preview</span></a></li>
        <li><a class="<? if($sagment=='edit_retaurant'){echo 'active';}?>" href="<?php echo site_url().'owner/home/edit_retaurant/'.$this->session->userdata('restaurant_id'); ?>" title="Restaurant Info">
        <span class="box restaurant_info"></span>
        <span class="hidden-tablet hidden-phone">Restaurant Info</span></a>
        </li>
        <li><a class="<? if($sagment2=='header_banner'){echo 'active';}?>" href="<?php echo site_url().'owner/header_banner'; ?>" title="Header Banner">
        <span class="box head_banner"></span>
        <span class="hidden-tablet hidden-phone">Header Banner</span>
        </a>
        </li>
        <li><a class="<? if($sagment2=='about'){echo 'active';}?>" href="<?php echo site_url().'owner/about'; ?>" title="About Restaurant">
        <span class="box about_restaur"></span>
        <span class="hidden-tablet hidden-phone">About Restaurant</span>
        </a></li>
        
        <?php 
        
        if($restaurant[0]->restaurant_type!='Basic') 
        {
        ?> 
        <li><a class="<? if($sagment2=='menu_item'){echo 'active';}?>" href="<?php echo site_url().'owner/menu_item/index/';?>" title="Menu Item">
        <span class="box menu_items"></span>
        <span class="hidden-tablet hidden-phone">Menu Item</span></a></li>
        <li><a class="<? if($sagment2=='event'){echo 'active';}?>" href="<?php echo site_url().'owner/event/' ?>" title="Event">
        <span class="box events"></span>
        <span class="hidden-tablet hidden-phone">Event</span>
        </a></li>
        <li><a class="<? if($sagment2=='offers'){echo 'active';}?> " href="<?php echo site_url().'owner/offers/' ?>" title="Special Offers">
        <span class="box spe_offers"></span>
        <span class="hidden-tablet hidden-phone">Special Offers</span>
        </a></li>
        <li><a class="<? if($sagment2=='reservation'){echo 'active';}?> " href="<?php echo site_url().'owner/reservation/' ?>" title="Reservations">
        <span class="box reservations"></span>
        <span class="hidden-tablet hidden-phone">Reservations</span>
        </a></li>
        <li><a class="<? if($sagment2=='iframe'){echo 'active';}?> " href="<?php echo site_url().'owner/iframe/' ?>" title="Widgets">
        <span class="box widgets"></span>
        <span class="hidden-tablet hidden-phone">Widgets</span>
        </a></li>
        <li><a class="<? if($sagment2=='subscribe'){echo 'active';}?> " href="<?php echo site_url().'owner/subscribe/' ?>" title="Subscribers">
        <span class="box subscribers"></span>
        <span class="hidden-tablet hidden-phone">Subscribers</span>
        </a></li>
        <li><a class="<? if($sagment2=='analytics'){echo 'active';}?> " href="<?php echo site_url().'owner/analytics/' ?>" title="Analytics">
        <span class="box analytics"></span>
        <span class="hidden-tablet hidden-phone">Analytics</span>
        </a></li>
        <?php }
        else { ?>
        <li><a class="<? if($sagment2=='menu_item'){echo 'active';}?> btn-disable" href="javascript:void(0)" title="Menu Item">
        <span class="box"></span>
        <span class="hidden-tablet hidden-phone">Menu Item</span>
        </a></li>
        <li><a class="<? if($sagment2=='event'){echo 'active';}?> btn-disable" href="javascript:void(0)" title="Event">
        <span class="box"></span>
        <span class="hidden-tablet hidden-phone">Event</span>
        </a></li>
        <li><a class="<? if($sagment2=='offers'){echo 'active';}?> btn-disable" href="javascript:void(0)" title="Special Offers">
        <span class="box"></span>
        <span class="hidden-tablet hidden-phone">Special Offers</span>
        </a></li>
        <li><a class="<? if($sagment2=='reservation'){echo 'active';}?> btn-disable" href="javascript:void(0)" title="Reservations">
        <span class="box"></span>
        <span class="hidden-tablet hidden-phone">Reservations</span>
        </a></li>
        <li><a class="<? if($sagment2=='iframe'){echo 'active';}?> btn-disable" href="javascript:void(0)" title="Widgets">
        <span class="box"></span>
        <span class="hidden-tablet hidden-phone">Widgets</span>
        </a></li>
        <li><a class="<? if($sagment2=='subscribe'){echo 'active';}?> btn-disable" href="javascript:void(0)" title="Subscribe">
        <span class="box"></span>
        <span class="hidden-tablet hidden-phone">Subscribe</span>
        </a></li>
        <li><a class="<? if($sagment2=='subscribe'){echo 'active';}?> btn-disable" href="javascript:void(0)" title="Analytics">
        <span class="box"></span>
        <span class="hidden-tablet hidden-phone">Analytics</span>
        </a></li>
    </ul>
	<?php  }

 ?>
 
  
 </div>