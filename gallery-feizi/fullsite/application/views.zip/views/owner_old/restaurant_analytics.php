
<div class="container-fluid main-container">
<div class="row-fluid">
<div class="span12">
<?php $this->load->view('owner/edit_resturant_header.php') ?>
<div class="container-fluid content-wrapper cluster_container mob-right-part span10">
  <div class="hero-unit">
    <h3 class="title">Restaurant Analytics</h3>
    <div class="back_color white_bg">
      <iframe src="http://103.21.53.250/apetizr//analytics/index.php?module=Widgetize&action=iframe&moduleToWidgetize=Dashboard&actionToWidgetize=index&idSite=<?php echo $this->session->userdata('restaurant_id'); ?>&period=week&date=yesterday" frameborder="0" marginheight="0" marginwidth="0" width="100%" height="1400px"></iframe>
    </div>
  </div>
</div>
