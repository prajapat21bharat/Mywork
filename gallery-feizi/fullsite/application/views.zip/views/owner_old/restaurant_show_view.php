<?php $site=site_url().'owner/home/'; ?>
<script type="text/javascript">

function restaurant_delete(id)
{
var r=confirm('Are Sure Delete This Restaurant');
if (r==true)
	{
	var form_data = {
		 restaurant:id
		  };
    $.ajax({
       url:'<?php echo $site.'delete_retaurant';?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		  $('#'+id).hide();
		  $('#msg').html('Success Fully Deleted');
       }
     });
}

}

function active(value,rest_id)
{

var form_data = {
		 active:value,
		 rest_id:rest_id
		  };
    $.ajax({
       url:'<?php echo $site.'active_inactive';?>',
       data:form_data,    
       datatype:'json',
       success:function(data){
		   
		   if(data!='1')
		   {
			   
            $('#actve_deactive_'+rest_id).html("<a title='Enable' onclick='active(1,"+rest_id+")' href='javascript:void(0)'><img src='<?php echo base_url().'assets/img/btn-red1.png'?>'/></a>");
			   
		   }else{
			       $('#actve_deactive_'+rest_id).html("<a title='Enable' onclick='active(0,"+rest_id+")' href='javascript:void(0)'><img src='<?php echo base_url().'assets/img/btn-green.png'?>'/></a>");
		   }
		  
		
       }
     });


}

$(function(){	
$('#pagination .active').html('<a href="<?php echo $base_url; ?>/0">1</a>');
$("#pagination a:last").remove();
var val_loc=window.location;

var arr = String(val_loc).split("/");
var size=arr.length-1;

if(arr[size])
{
	var par_page='<?php echo $per_page; ?>';
	var page=Math.ceil(arr[size]/par_page)+1;
	$("#pagination >li.active").removeClass("active");
	$("#pagination li:nth-child("+page+") a ").addClass("active");

}
});
</script>
<div class="container-fluid main-container">
<div class="row-fluid">
<div class="span12">
<div class="container-fluid content-wrapper owner_wrapper">
  <div class="hero-unit">
    <div id="msg"></div>
    <h3 class="title">Restaurants</h3>
     <div class="">
    <table width="100%" class="table table-striped table-bordered table-radmin">
      <thead>
        <tr>
          <th width="">Name</th>
          <th class="hidden-tablet hidden-phone" width="">Address</th>
          <th width="">Action</th>
        </tr>
      </thead>
      <?php 
	  if(!empty($records)){
	  foreach ($records as $restaurant){?>
      <tr id='<?php echo $restaurant->ID; ?>'>
        <td><a href="<?php echo $site.'review/'.$restaurant->ID; ?>"><?php echo $restaurant->restaurant_name; ?></a></td>
        <td class="hidden-tablet hidden-phone"><?php echo $restaurant->restaurant_address; ?></td>
          </td>
        <td>
		
		<?php if($restaurant->restaurant_is_active==1){
			
		
			  echo "<span id='actve_deactive_$restaurant->ID'><a title='Disable' onclick='active(0,$restaurant->ID)' href='javascript:void(0)'><img src='".base_url()."assets/img/btn-green.png'  /></a></span>";
			 
		}else{
			echo  "<span id='actve_deactive_$restaurant->ID'><a title='Enable'  onclick='active(1,$restaurant->ID)' href='javascript:void(0)'><img src='".base_url()."assets/img/btn-red1.png' /></a></span>"; 
             } ?>
        |
        <a title="Edit"  href="<?php echo $site.'review/'.$restaurant->ID; ?>"><img  src="<?php echo base_url().'uploadimages/site_image/edit.png';?>" />
        </a>
        
         
        
        
        </td>
      </tr>
      <?php } }else echo '<span>NO Data</span>'; ?>
    </table>
    <?php echo $links;?> </div>
    </div>
</div>
</div>
</div>
</div>
