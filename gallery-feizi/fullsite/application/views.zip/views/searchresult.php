<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');?>

<div id="restaurant_text">
  <div class="row-fluid">
    <div class="featured-rest">
     <?php if($retaurantsArray!='not Found'){	?> <h6>Featured Restaurant</h6><?php }?>
    </div>
  </div>
</div>
<div id="restaurant_result">
  <?php
  $site=site_url()."restaurant/index/";
			$i=0;	
if($retaurantsArray!='not Found'){	
	foreach($retaurantsArray as $retaurants){
	
		if($i==0){
			echo '<div class="row-fluid">';
			}
			echo '<div class="row-field one_feature_rest span4"><div class="view-media"><a href="'.site_url().$retaurants->slug.'"><img src="'.site_url().'uploadimages/files/'.$retaurants->restaurant_logo.'" height="250" width="250" /></a></div>';
			echo '<div class="view-name"><a href="'.site_url().$retaurants->slug.'">'.$retaurants->restaurant_name.'</a><p class="address">'.$retaurants->city.' , '.$retaurants->state.'</p></div></div>';
			
		$i++;
		if($i==3){echo '</div>';$i=0;}
		
	    }
		if((count($retaurants)% 3)!=0)echo '</div>';
		}else{
			
			
			echo '<div class="error"><h4> Sorry, No results found for the entered Search option..</h4></div>';
			
		}
		
	if(!empty($links)){echo $links;}
 	?>
</div>

<script>
$(function(){	
$('#pagination .active').html('<a href="<?php echo $pagination_links.'/'; ?>">1</a>');
$("#pagination a:last").remove();
var val_loc=window.location;

var arr = String(val_loc).split("/");
var size=arr.length-1;

if(arr[size])
{
	var page=Math.ceil(arr[size]/6)+1;
	$("#pagination >li.active").removeClass("active");
	$("#pagination li:nth-child("+page+") a ").addClass("active");

}
});
</script>