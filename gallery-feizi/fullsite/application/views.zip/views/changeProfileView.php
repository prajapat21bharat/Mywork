<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" />
<?php $this->load->view('layout/header'); ?>
<link rel="stylesheet" href="<?php echo base_url('assets/css/jquery.datepick.css') ?>">


<script type="text/javascript" src="<?php echo base_url('assets/js/jquery.datepick.js') ?>"></script>

<script type="text/javascript">
$(function() {
	$('#dat').datepick();
	$('#inlineDatepicker').datepick({onSelect: showDate});
});


</script>
<div class="hero-unit" id="profile">
<!--<h3 style="color:black">Edit Profile page</h3>-->
  <?php
 if(!empty($success)){
    echo $success;
	       }
 echo form_open_multipart(site_url().'register/change_profile');

 // if(!empty($success)) echo $success;
?>

  <input type="hidden" name="user_id" value="<?php if($user_info){echo $user_info[0]->user_id;} ?>" />
  <label>First Name *:</label>
  <input type="text" id="firstName" name="first_name" value="<?php if($user_info){echo $user_info[0]->first_name;} ?>"/>
  <p><span id="txtFirstName"> <?php echo form_error('first_name'); ?></span></p>
  <label>Last Name *:</label>
  <input type="text"  id="lastName" name="last_name" value="<?php if($user_info){echo $user_info[0]->last_name;} ?>"/>
  <p><span id="txtLastName"> <?php echo form_error('last_name'); ?> </span></p>
  <label>Profile Image :</label>
  <a class="fancybox" href="javascript:void(0) <?php //if($user_info){ echo site_url()."uploadimages/user/".$user_info[0]->userfile; }?>"><img src="<?php if($user_info){echo site_url()."uploadimages/user/".$user_info[0]->userfile; }?>" height="100px" width="100px"/></a>
  <input type="file" name="userfile" value="" />
  <?php if(!empty($error)) echo $error; ?>
  <p><span id="userfile"> <?php if($user_info){echo form_error('userfile');} ?> </span></p>
  <label>Gender :</label>
  <tr>
    <td><input type="radio" name="gender" value="Male"    <?php if($user_info){if($user_info[0]->gender=='Male'){ echo 'checked="checked"';}}?> />
      <span>Male</span>
    <td><input type="radio" name="gender" value="Female" <?php if($user_info){if($user_info[0]->gender=='Female'){ echo 'checked="checked"';}}?> />
      <span>Female</span>
  </tr>
  <label>Date of Birth *:</label>
  <input type="text"  value="<?php if($user_info){echo $user_info[0]->date; }?>" name="date"/>
  <p><span id="txtAge"> <?php echo form_error('date'); ?> </span></p>
  <label>City*:</label>
  <input type="text" id="city" value="<?php if($user_info){echo $user_info[0]->city; }?>" name="city"/>
  <p><span id="txtAddress"><?php if($user_info){echo form_error('city');} ?></span></p>
   <label>State*:</label>
  <input type="text" id="state" value="<?php if($user_info){echo $user_info[0]->states; }?>" name="state"/>
  <p><span id="txtAddress"><?php if($user_info){echo form_error('state');} ?></span></p>
   <label>Zip code*:</label>
  <input type="text" id="zip" value="<?php if($user_info){echo $user_info[0]->zip; }?>" name="zip"/>
  <p><span id="txtAddress"><?php if($user_info){echo form_error('zip');} ?></span></p>
  <label>Mobile Number for notifications *:</label>
  <input type="text" name="user_phone" value="<?php if($user_info){ echo $user_info[0]->user_phone;} ?>"  />
  <p><span id="txtTelephone"><?php if($user_info){echo form_error('user_phone'); }?> </span></p>
  <input type="submit" value="Save" name=" " class="login-btn " />   <a href="<?php echo base_url()?>register/user_info" id="profileBack" class="login-btn"> Back</a>
  <?php 
echo  form_close();
?>
</div>
</body>
</html>