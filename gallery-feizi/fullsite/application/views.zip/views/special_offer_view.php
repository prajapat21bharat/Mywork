<?php $site=site_url().'special_offer/'; ?>

<div class="container" id="Offer">

  <div class="hero-unit" id="dragable"> 





    <div id="filter" class="filter"></div>

    <div class="rest_search"> 

    <div class="rest_fliter_type">

     <?php echo form_open('special_offer/#Offer')?>

    <h5>State</h5>

     <select id="state_type" name="state_type" onchange="state()">

      <option value="">Select State</option>

       <?php 

	   if($item){

	    foreach($item as $item){

	   if($item->state_code==$state){?>

           <option value="<?php echo $item->state_code?>" selected="selected"><?php echo $item->state?></option>

       <?php } else{?>

       

      <option value="<?php echo $item->state_code?>"><?php echo $item->state?></option>

    <?php }}}?>

    </select>

    </div>

 <div id="loder"></div>

    <div class="rest_fliter_type cluster_search">

     <h5>City</h5>

     

      <select id="input_city" name="input_city" class="select-city">

    <?php if($city_all){

		//$city_all = array_diff($city_all, array($city));

		foreach($city_all as $city_m){

         if($city_m->city_id==$city)	{?>   

			<option value="<?php echo $city_m->city_id?>" selected="selected"><?php echo $city_m->city?></option>

		  <?

		 }else{ 

		    ?>

            <option value="<?php echo $city_m->city_id?>"><?php  echo $city_m->city?></option>

		<?  } }

		}

	?>

        </select>

    </div>

  

    <input class="login-btn" type="submit"   value="Search" name="submit"/>

    <?php   echo form_close();?>

    </div>

    <div id="msg"></div>

  <?php	

    if(isset($_REQUEST['submit'])){



		if(!empty($offer)){

		 foreach($offer as $offer){

			  ?>

		 <div class="row-fluid resevent">

             <h4 id="image_box"><a href="<?php echo site_url($offer->slug)?>"><?php echo $offer->restaurant_name; ?></a></h4>

         <?php  echo '<div id="image_box">'; 

				if($offer->image){?>

                  <img src="<?php echo base_url().'uploadimages/city_offer_image/'.$offer->image;?>"/>

                 <?php }

				 else{?>

				 <img src="<?php echo base_url().'uploadimages/files/'.$offer->restaurant_logo;?>"/>

				 

				 <?php }

	          ?>

          </div>

       <div class="event">

         <h4><?php echo $offer->offer_title; ?></h4>

         <p><?php echo $offer->offer_description; ?></p>

         <p> <span><?php echo $offer->start_date; ?></span> To <span><?php echo $offer->end_date; ?></span> </p>

     </div></div>

    <?php }

		}

		else{

			echo '<div class="error"><h2> Sorry, No results found for the entered Search option..</h2></div>';

			}

	}

			?>

   </div>

</div>

 <script type="text/javascript">   

    function state(){

   var form_data ={state: $('#state_type').val()};

   $("#loder").html('<img  src="<?php echo base_url().'/ajax-loader.gif'; ?>"/>');

   $.ajax({

       url:'<?php echo site_url("special_offer/get_city"); ?>',

       data:form_data,    

       datatype:'json',

       success:function(data){

		    var newdata= jQuery.parseJSON(data);

		   $("#loder").empty();

		   $("#input_city").empty();

		   $.each(newdata,function(i,index){

                htmlString="<option value='"+index['city_id']+"'>"+index['city']+"</option>"

				$("#input_city").append(htmlString);

           });

        }

    });

}

</script>