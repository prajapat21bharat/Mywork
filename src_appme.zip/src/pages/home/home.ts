import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
	categories=[
		{title:"Funny",id:1},
		{title:"Love",id:2},
		{title:"Festival",id:3},
		{title:"Friendship",id:4},
		{title:"Jokes",id:5},
		{title:"Riddle",id:6},
	];
	
	  
	constructor(public navCtrl: NavController) {
	}

	

}
