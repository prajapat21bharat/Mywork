import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { LoopconditionPage } from './loopcondition';

@NgModule({
  declarations: [
    LoopconditionPage,
  ],
  imports: [
    IonicPageModule.forChild(LoopconditionPage),
  ],
})
export class LoopconditionPageModule {}
