import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

/**
 * Generated class for the LoopconditionPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-loopcondition',
  templateUrl: 'loopcondition.html',
})
export class LoopconditionPage {
	details=[];
	showVisible: boolean;
  constructor(public navCtrl: NavController, public navParams: NavParams) {
	this.showVisible=false;
  	this.details = [{"name":"John Doe", "age":"20", "city":"Indore"},
					{"name":"Monu Rai", "age":"28", "city":"Gurgaon"},
					{"name":"Vijay Sharma", "age":"25", "city":"jaipur"}];
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad LoopconditionPage');
  }
  
  openPage(page,index) {
	console.log(page,index);
		//	this.rootPage = index != 3 ? page : AnotherPage;
		// AnotherPage can also be a method like this.anotherPage(136379);
	}

}
