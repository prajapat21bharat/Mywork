import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Storage } from '@ionic/storage';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  constructor(public navCtrl: NavController, private storage: Storage) {

  }
  
  setData(){
	this.storage.set('name', 'Max');
	console.log("Set Data Clicked");
  }
  
  getData(){
	  this.storage.get('name').then((val) => {
		console.log('Your age is', val);
	  });
	console.log("Get Data Clicked");
  }

}
